const TOOLS = [
  // ── CITATIONS ──────────────────────────────────────────────────────────
  {
    id: 'chicago-citation-generator',
    cat: 'citation',
    ico: '📜',
    name: 'Chicago Citation Generator',
    short: 'Chicago 17th Edition',
    tagline: 'Generate perfect Chicago citations in seconds — Notes-Bibliography & Author-Date',
    desc: 'Generate accurate Chicago 17th Edition citations for books, journals, websites, and more. Supports both Notes-Bibliography and Author-Date systems.',
    metaTitle: 'Chicago Citation Generator Free — 17th Edition NB & Author-Date | ProScholersTools',
    metaDesc: 'Free Chicago citation generator. Create perfect Chicago 17th Edition citations (Notes-Bibliography & Author-Date) for books, journals, websites. Instant & accurate.',
    keyword: 'chicago citation generator free',
    color: '#8b1a1a',
    styles: ['Notes-Bibliography (NB)', 'Author-Date (AD)', 'Full Bibliography Entry', 'Footnote Format'],
    sources: ['Book', 'Journal Article', 'Website', 'Newspaper', 'Film/Video', 'Interview', 'Government Document', 'Thesis/Dissertation'],
    relatedTools: ['apa-citation-generator', 'mla-citation-generator', 'footnote-formatter', 'bibliography-builder'],
    faqs: [
      { q: 'Is Chicago citation format free to use?', a: 'Yes, 100% free. No account required. Generate unlimited Chicago citations using your own API key or our 5 free daily uses.' },
      { q: 'What is the difference between Notes-Bibliography and Author-Date?', a: 'Notes-Bibliography (NB) is used in humanities — citations appear in footnotes/endnotes. Author-Date is used in sciences — citations appear parenthetically in text.' },
      { q: 'Which edition does this generator use?', a: 'This generator uses the Chicago Manual of Style 17th Edition (2017), the most current edition.' },
    ],
    prompt: `Generate a complete Chicago 17th Edition citation.
System: {style}
Source type: {src}
Source details: {input}

Provide ALL of the following:
1. FOOTNOTE FORMAT (first citation — full)
2. FOOTNOTE FORMAT (subsequent — shortened)
3. BIBLIOGRAPHY ENTRY
4. AUTHOR-DATE IN-TEXT CITATION
5. REFERENCE LIST ENTRY (Author-Date)

Use exact Chicago 17th Ed. punctuation, italics notation with [italics], and hanging indent notation.`
  },
  {
    id: 'apa-citation-generator',
    cat: 'citation',
    ico: '🔬',
    name: 'APA Citation Generator',
    short: 'APA 7th Edition',
    tagline: 'Instant APA 7th Edition citations — free, accurate, formatted correctly',
    desc: 'Generate APA 7th Edition citations for academic papers, research, and psychology. Supports all source types including DOIs, URLs, and social media.',
    metaTitle: 'APA Citation Generator Free — 7th Edition | ProScholersTools',
    metaDesc: 'Free APA 7th Edition citation generator. Generate perfect APA citations for books, journals, websites, and more. Instant, accurate, and formatted correctly.',
    keyword: 'apa citation generator free',
    color: '#1a5c8b',
    styles: ['Journal Article', 'Book', 'Book Chapter', 'Website', 'YouTube Video', 'Social Media Post', 'Government Report', 'Dissertation'],
    sources: ['Book', 'Journal Article', 'Website', 'YouTube/Video', 'Social Media', 'Government Document', 'Thesis', 'Conference Paper'],
    relatedTools: ['chicago-citation-generator', 'mla-citation-generator', 'bibliography-builder', 'abstract-generator'],
    faqs: [
      { q: 'What is APA 7th edition?', a: 'The 7th edition of the APA Publication Manual (2020) is the current standard for academic writing in psychology, education, and social sciences.' },
      { q: 'How do I cite a website with no author in APA?', a: 'Use the title of the page in place of the author. Italicize the title if it is standalone (e.g., a report), or use regular formatting if part of a larger site.' },
    ],
    prompt: `Generate a complete APA 7th Edition citation.
Source type: {src}
Additional context: {style}
Source details: {input}

Provide:
1. REFERENCE LIST ENTRY (hanging indent format)
2. IN-TEXT CITATION (parenthetical)
3. IN-TEXT CITATION (narrative, author in sentence)
4. DOI/URL formatting notes if applicable
5. Common mistakes to avoid for this source type

Follow APA 7th Edition exactly — use & for multiple authors, et al. after 20+ authors.`
  },
  {
    id: 'mla-citation-generator',
    cat: 'citation',
    ico: '✒️',
    name: 'MLA Citation Generator',
    short: 'MLA 9th Edition',
    tagline: 'Perfect MLA 9th Edition citations — Works Cited & in-text instantly',
    desc: 'Generate MLA 9th Edition citations for literature, humanities, and arts research. Includes Works Cited entries and in-text parenthetical citations.',
    metaTitle: 'MLA Citation Generator Free — 9th Edition | ProScholersTools',
    metaDesc: 'Free MLA 9th Edition citation generator. Create perfect MLA citations for books, websites, articles, films. Instant Works Cited entries and in-text citations.',
    keyword: 'mla citation generator free',
    color: '#2d7a4f',
    styles: ['MLA 9th Edition', 'MLA 8th Edition'],
    sources: ['Book', 'Journal Article', 'Website', 'Film/Video', 'Poem/Short Story', 'Newspaper', 'Interview', 'Social Media'],
    relatedTools: ['chicago-citation-generator', 'apa-citation-generator', 'footnote-formatter', 'bibliography-builder'],
    faqs: [
      { q: 'What changed in MLA 9th edition?', a: 'MLA 9th (2021) introduced the "container" concept for nested sources, clearer URL guidelines, updated guidance on accessibility, and revised capitalization rules.' },
    ],
    prompt: `Generate a complete MLA 9th Edition citation.
Source type: {src}
Additional context: {style}
Source details: {input}

Provide:
1. WORKS CITED ENTRY (hanging indent format)
2. IN-TEXT PARENTHETICAL CITATION
3. SIGNAL PHRASE FORMAT (narrative citation)
4. ANNOTATED BIBLIOGRAPHY VERSION (3-sentence annotation)

Use MLA 9th Edition exactly — italicize titles of containers, use "and" not &.`
  },
  {
    id: 'footnote-formatter',
    cat: 'citation',
    ico: '🔢',
    name: 'Footnote Formatter',
    short: 'Footnotes & Endnotes',
    tagline: 'Format footnotes and endnotes perfectly for Chicago, MLA, Turabian & Bluebook',
    desc: 'Generate properly formatted footnotes and endnotes for Chicago, MLA, Turabian, and Bluebook styles. First citations, shortened subsequent citations, and ibid usage.',
    metaTitle: 'Footnote Formatter — Chicago, MLA, Turabian, Bluebook | ProScholersTools',
    metaDesc: 'Free footnote and endnote formatter. Perfect footnotes for Chicago, MLA, Turabian, and Bluebook styles. First citation, shortened, and ibid formats included.',
    keyword: 'footnote formatter chicago mla',
    color: '#7a3d1a',
    styles: ['Chicago 17th NB', 'MLA 9th', 'Turabian 9th', 'Bluebook 21st'],
    sources: ['Book', 'Journal Article', 'Website', 'Legal Case', 'Statute', 'Newspaper', 'Interview'],
    relatedTools: ['chicago-citation-generator', 'mla-citation-generator', 'bibliography-builder', 'legal-case-brief'],
    faqs: [
      { q: 'When should I use ibid in footnotes?', a: 'Use "ibid." when citing the exact same source as the immediately preceding footnote. If the page number differs, write "ibid., [page]". Turabian recommends ibid; Chicago 17th allows but does not require it.' },
    ],
    prompt: `Format professional footnotes/endnotes.
Style: {style}
Source type: {src}
Source details: {input}

Provide:
1. FIRST FOOTNOTE (full citation)
2. SUBSEQUENT FOOTNOTE (shortened)
3. IBID. USAGE EXAMPLE
4. BIBLIOGRAPHY/WORKS CITED ENTRY (corresponding)
5. FORMATTING NOTES for this style`
  },
  {
    id: 'bibliography-builder',
    cat: 'citation',
    ico: '📚',
    name: 'Bibliography Builder',
    short: 'Full Bibliography',
    tagline: 'Build a complete bibliography or reference list from multiple sources',
    desc: 'Build complete bibliographies and reference lists for Chicago, APA, MLA, and Turabian. Organize and format multiple sources correctly with proper alphabetization.',
    metaTitle: 'Bibliography Builder Free — Chicago, APA, MLA | ProScholersTools',
    metaDesc: 'Free bibliography builder. Create complete bibliographies and reference lists for Chicago, APA, MLA, and Turabian. Multiple sources, alphabetized, formatted correctly.',
    keyword: 'bibliography builder free online',
    color: '#4a1a7a',
    styles: ['Chicago 17th', 'APA 7th', 'MLA 9th', 'Turabian 9th'],
    sources: ['Multiple Sources (list each)', 'Books Only', 'Mixed Sources'],
    relatedTools: ['chicago-citation-generator', 'apa-citation-generator', 'mla-citation-generator', 'footnote-formatter'],
    faqs: [
          {
                "q": "What is the difference between a bibliography and a Works Cited page?",
                "a": "A bibliography lists all sources consulted, whether cited or not. A Works Cited page (MLA) or References list (APA) includes only sources actually cited in your paper. Chicago uses 'Bibliography' but means sources cited — not a comprehensive reading list."
          },
          {
                "q": "Should bibliography entries be in alphabetical order?",
                "a": "Yes. All major citation styles require entries sorted alphabetically by the first author's last name. If there is no author, sort by the first significant word of the title."
          },
          {
                "q": "How do I format a hanging indent?",
                "a": "In Word: select all entries → Paragraph → Special: Hanging, By: 0.5 inches. In Google Docs: Format → Align & Indent → Indentation options → Hanging: 0.5 inch."
          }
    ],
    prompt: `Build a complete formatted bibliography.
Style: {style}
Source types: {src}
Sources (list each on new line): {input}

Provide:
1. COMPLETE BIBLIOGRAPHY — alphabetized, hanging indent
2. ANNOTATION for each entry (2-sentence summary)
3. FORMATTING CHECKLIST to verify accuracy`
  },

  // ── RESEARCH ──────────────────────────────────────────────────────────
  {
    id: 'thesis-statement-generator',
    cat: 'research',
    ico: '🎯',
    name: 'Thesis Statement Generator',
    short: 'Thesis Builder',
    tagline: 'Generate strong, arguable thesis statements for any academic paper',
    desc: 'Create powerful, specific thesis statements for essays, research papers, and dissertations. Generates argumentative, analytical, and expository thesis options.',
    metaTitle: 'Thesis Statement Generator Free — AI Academic | ProScholersTools',
    metaDesc: 'Free AI thesis statement generator. Create strong, arguable thesis statements for essays, research papers, dissertations. Argumentative, analytical, and expository options.',
    keyword: 'thesis statement generator free',
    color: '#8b1a1a',
    styles: ['Argumentative', 'Analytical', 'Expository', 'Compare & Contrast', 'Cause & Effect', 'Dissertation (3-part)'],
    sources: ['Essay Topic', 'Research Question', 'Broad Subject Area'],
    relatedTools: ['research-question-generator', 'essay-outline-generator', 'literature-review-writer', 'dissertation-chapter-planner'],
    faqs: [
      { q: 'What makes a strong thesis statement?', a: 'A strong thesis is specific (not broad), arguable (someone could disagree), supportable with evidence, and previews the structure of your paper.' },
    ],
    prompt: `Generate thesis statements for an academic paper.
Paper type: {style}
Topic/subject: {input}

Provide:
1. PRIMARY THESIS (strongest option)
2. ALTERNATIVE THESIS A
3. ALTERNATIVE THESIS B
4. WEAK THESIS to avoid (with explanation of why it is weak)
5. HOW TO EXPAND this thesis into a paper outline`
  },
  {
    id: 'research-question-generator',
    cat: 'research',
    ico: '❓',
    name: 'Research Question Generator',
    short: 'Research Questions',
    tagline: 'Transform broad topics into focused, researchable research questions',
    desc: 'Convert broad topics into focused, answerable research questions. Generates primary questions, sub-questions, and hypotheses for quantitative and qualitative research.',
    metaTitle: 'Research Question Generator Free — AI Academic | ProScholersTools',
    metaDesc: 'Free research question generator. Turn broad topics into focused, answerable research questions. Primary questions, sub-questions, hypotheses for any field.',
    keyword: 'research question generator ai',
    color: '#1a5c8b',
    styles: ['Qualitative', 'Quantitative', 'Mixed Methods', 'Systematic Review', 'Exploratory'],
    sources: ['Broad Topic', 'Existing Literature Gap', 'Practical Problem'],
    relatedTools: ['thesis-statement-generator', 'literature-review-writer', 'research-proposal-builder', 'abstract-generator'],
    faqs: [
          {
                "q": "How narrow should a research question be?",
                "a": "Narrow enough to answer thoroughly within your study's scope, but broad enough to be significant. For a 5,000-word paper, answerable with 3-5 sources of evidence. For a dissertation, broader questions with sub-questions are appropriate."
          },
          {
                "q": "What is the difference between a research question and a hypothesis?",
                "a": "A research question is open-ended: 'What factors influence student engagement?' A hypothesis is testable and predictive: 'Students receiving weekly feedback will show 20% higher engagement scores.'"
          },
          {
                "q": "Can I change my research question after starting?",
                "a": "In quantitative research this is problematic and must be disclosed. In qualitative research, questions frequently evolve — this is expected and should be reported transparently in your methodology."
          }
    ],
    prompt: `Generate focused research questions.
Research approach: {style}
Topic/field: {input}

Provide:
1. PRIMARY RESEARCH QUESTION (main question)
2. SUB-QUESTIONS (3-5 supporting questions)
3. HYPOTHESIS (testable prediction)
4. VARIABLES (independent, dependent, confounding)
5. METHODOLOGY SUGGESTION
6. POTENTIAL GAPS this research would fill`
  },
  {
    id: 'literature-review-writer',
    cat: 'research',
    ico: '📖',
    name: 'Literature Review Writer',
    short: 'Lit Review',
    tagline: 'Generate structured literature review sections for your research',
    desc: 'Generate comprehensive literature review sections. Synthesizes themes, identifies gaps, and structures arguments for systematic, narrative, and scoping reviews.',
    metaTitle: 'Literature Review Writer Free — AI Research Tool | ProScholersTools',
    metaDesc: 'Free AI literature review writer. Generate structured literature review sections, synthesize themes, identify research gaps. Systematic, narrative, and scoping reviews.',
    keyword: 'literature review writer ai free',
    color: '#2d7a4f',
    styles: ['Thematic Synthesis', 'Chronological', 'Methodological', 'Theoretical Framework', 'Systematic Review'],
    sources: ['Topic + Key Papers', 'Research Area', 'Existing Notes'],
    relatedTools: ['research-question-generator', 'abstract-generator', 'research-proposal-builder', 'critical-analysis-tool'],
    faqs: [
          {
                "q": "How many sources does a literature review need?",
                "a": "Undergraduate essay (2,000 words): 10-20 sources. Masters thesis chapter: 40-60 sources. PhD literature review: 80-150+. Quality matters more than quantity — deep engagement with fewer sources outperforms superficial mention of many."
          },
          {
                "q": "Should I include sources I disagree with?",
                "a": "Yes — essential. A review including only supporting evidence is advocacy, not scholarship. Engaging critically with contradictory evidence demonstrates rigor and actually strengthens your argument."
          },
          {
                "q": "What is the difference between a narrative and a systematic review?",
                "a": "A narrative review is a thematic synthesis using the author's judgment to select sources. A systematic review follows a pre-registered protocol with explicit criteria and aims to include all relevant evidence — required in medical and evidence-based policy contexts."
          }
    ],
    prompt: `Write a literature review section.
Structure: {style}
Research topic and key sources: {input}

Provide:
1. INTRODUCTION paragraph (scope and purpose)
2. THEMATIC SECTIONS (3-4 synthesized themes)
3. RESEARCH GAPS identified
4. THEORETICAL FRAMEWORK summary
5. TRANSITION TO METHODOLOGY
6. SUGGESTED CITATIONS NEEDED`
  },
  {
    id: 'abstract-generator',
    cat: 'research',
    ico: '📋',
    name: 'Abstract Generator',
    short: 'Academic Abstract',
    tagline: 'Generate professional academic abstracts — IMRAD, structured, and humanities',
    desc: 'Generate professional academic abstracts for research papers, dissertations, and conference submissions. Supports IMRAD, structured, and humanities abstract formats.',
    metaTitle: 'Abstract Generator Free — Academic Research | ProScholersTools',
    metaDesc: 'Free academic abstract generator. Create professional IMRAD, structured, and humanities abstracts for research papers, dissertations, and conference submissions.',
    keyword: 'academic abstract generator free',
    color: '#7a3d1a',
    styles: ['IMRAD (Sciences)', 'Structured (Medical)', 'Humanities', 'Conference Submission', 'Dissertation Abstract'],
    sources: ['Full Paper Text', 'Paper Outline', 'Research Summary'],
    relatedTools: ['literature-review-writer', 'research-proposal-builder', 'research-summary-generator', 'thesis-statement-generator'],
    faqs: [
          {
                "q": "Should an abstract include citations?",
                "a": "No. Abstracts must function as completely self-contained documents readable without the full paper or its reference list. Never include citations, references, or footnotes in an abstract."
          },
          {
                "q": "What is the ideal abstract length?",
                "a": "Most journals: 150-250 words. Conference abstracts: 250-500 words. Dissertation chapter abstracts: 300-500 words. Structured medical abstracts: up to 400 words. Always check submission guidelines."
          },
          {
                "q": "What is a structured vs unstructured abstract?",
                "a": "Structured uses labeled headings: Background, Objective, Methods, Results, Conclusions — required by most medical journals. Unstructured is a continuous paragraph without headings, common in humanities. Both contain the same information."
          }
    ],
    prompt: `Generate a professional academic abstract.
Format: {style}
Paper content/outline: {input}

Provide:
1. ABSTRACT (200-300 words, formatted for {style})
2. KEYWORDS (6-8 relevant terms)
3. SHORT VERSION (150 words for tight limits)
4. CHECKLIST — elements included vs missing`
  },
  {
    id: 'research-proposal-builder',
    cat: 'research',
    ico: '📝',
    name: 'Research Proposal Builder',
    short: 'Research Proposal',
    tagline: 'Build a complete research proposal with all required sections',
    desc: 'Build comprehensive research proposals for grants, dissertations, and funding applications. Includes background, methodology, timeline, budget justification, and expected outcomes.',
    metaTitle: 'Research Proposal Builder Free — AI Academic | ProScholersTools',
    metaDesc: 'Free research proposal builder. Create complete research proposals with background, methodology, timeline, and budget. For grants, dissertations, and funding applications.',
    keyword: 'research proposal builder free',
    color: '#4a1a7a',
    styles: ['PhD Dissertation Proposal', 'Grant Application', 'Undergraduate Research', 'Policy Research', 'Scientific Study'],
    sources: ['Research Topic', 'Existing Proposal Draft'],
    relatedTools: ['thesis-statement-generator', 'research-question-generator', 'literature-review-writer', 'dissertation-chapter-planner'],
    faqs: [
          {
                "q": "How long should a research proposal be?",
                "a": "PhD proposals: 2,000-5,000 words. Masters proposals: 1,000-2,000 words. Grant applications: 5-15 pages. Undergraduate proposals: 500-1,500 words. Always check your institution or funder requirements."
          },
          {
                "q": "What makes a research proposal get rejected?",
                "a": "Most common reasons: (1) research question too vague or already answered; (2) methodology mismatched to the question; (3) unrealistic timeline or budget; (4) insufficient literature engagement; (5) unclear statement of research gap or significance."
          },
          {
                "q": "Do I need ethics approval before submitting?",
                "a": "Typically no — ethics approval is needed before data collection, not before submitting the proposal. However, many funders require you to describe your ethics approach and may require simultaneous ethics submission for sensitive research."
          }
    ],
    prompt: `Write a structured research proposal.
Type: {style}
Research topic and context: {input}

Provide full proposal with:
1. TITLE & ABSTRACT
2. BACKGROUND & SIGNIFICANCE
3. RESEARCH QUESTIONS/OBJECTIVES
4. LITERATURE REVIEW (brief)
5. METHODOLOGY
6. TIMELINE (Gantt-style milestones)
7. BUDGET JUSTIFICATION (if applicable)
8. EXPECTED OUTCOMES & IMPACT
9. LIMITATIONS & ETHICAL CONSIDERATIONS`
  },
  {
    id: 'dissertation-chapter-planner',
    cat: 'research',
    ico: '🎓',
    name: 'Dissertation Chapter Planner',
    short: 'Dissertation Planner',
    tagline: 'Plan and outline every chapter of your dissertation with AI guidance',
    desc: 'Plan and structure your entire dissertation chapter by chapter. Generates detailed outlines, section breakdowns, and writing guidance for each chapter.',
    metaTitle: 'Dissertation Chapter Planner — AI Writing Tool | ProScholersTools',
    metaDesc: 'Free dissertation chapter planner. AI-powered outlines for every chapter — introduction, literature review, methodology, findings, discussion, conclusion.',
    keyword: 'dissertation chapter planner ai',
    color: '#1a5c3a',
    styles: ['STEM Dissertation', 'Humanities Dissertation', 'Social Sciences', 'Professional Doctorate (DBA/EdD)', 'Masters Thesis'],
    sources: ['Dissertation Topic', 'Research Questions', 'Completed Draft'],
    relatedTools: ['thesis-statement-generator', 'research-proposal-builder', 'literature-review-writer', 'abstract-generator'],
    faqs: [
          {
                "q": "How long should each dissertation chapter be?",
                "a": "For an 80,000-word PhD dissertation — Introduction: 5,000-8,000 words; Literature Review: 15,000-20,000; Methodology: 10,000-15,000; Results: 15,000-20,000; Discussion and Conclusion: 12,000-18,000. These are guidelines — your supervisor and research design determine actual allocation."
          },
          {
                "q": "Should I write chapters in order?",
                "a": "Most experienced researchers recommend writing Methodology first (clarifies exactly what you are doing), then Literature Review (scope becomes clear once methodology is set), and writing Introduction and Conclusion last."
          },
          {
                "q": "What is the difference between results and discussion chapters?",
                "a": "Results presents what you found — data, patterns, themes — without interpretation. Discussion interprets what results mean, connects them to literature, addresses limitations, and states implications. Some dissertations combine these; follow your supervisor's guidance."
          }
    ],
    prompt: `Create a detailed dissertation chapter plan.
Dissertation type: {style}
Topic and research area: {input}

Provide for EACH of 5 chapters:
1. CHAPTER TITLE & PURPOSE
2. SECTION BREAKDOWN (detailed subsections)
3. WORD COUNT TARGET
4. KEY ARGUMENTS to make
5. SOURCES NEEDED
6. COMMON PITFALLS to avoid

End with overall TIMELINE and WRITING STRATEGY.`
  },
  {
    id: 'critical-analysis-tool',
    cat: 'research',
    ico: '🔍',
    name: 'Critical Analysis Tool',
    short: 'Critical Analysis',
    tagline: 'Perform deep critical analysis of texts, arguments, and academic work',
    desc: 'Conduct thorough critical analysis of academic texts, arguments, policies, and media. Identifies assumptions, logical fallacies, rhetorical strategies, and research limitations.',
    metaTitle: 'Critical Analysis Tool Free — AI Academic | ProScholersTools',
    metaDesc: 'Free critical analysis tool. Analyze academic texts, arguments, and research papers. Identify assumptions, logical fallacies, rhetorical strategies, and limitations.',
    keyword: 'critical analysis tool ai free',
    color: '#8b1a1a',
    styles: ['Academic Text', 'Policy Document', 'Research Paper', 'Media/News Article', 'Business Report'],
    sources: ['Text to Analyze', 'Article Summary', 'Research Paper'],
    relatedTools: ['literature-review-writer', 'peer-review-assistant', 'research-summary-generator', 'academic-paraphrasing'],
    faqs: [
          {
                "q": "What is the difference between summary and critical analysis?",
                "a": "Summary describes what a text says. Critical analysis evaluates how it says it, whether evidence supports conclusions, what assumptions underlie the argument, and what the strengths and limitations are. Summary is descriptive; analysis is evaluative."
          },
          {
                "q": "Can a critical analysis be positive?",
                "a": "Yes. 'Critical' means rigorous evaluation, not negative criticism. A critical analysis may conclude an argument is well-reasoned — as long as you explain specifically why. Rigorous positive evaluation is as academically valuable as rigorous critique."
          },
          {
                "q": "Which analytical frameworks are most common?",
                "a": "Toulmin Model (argument analysis); Rhetorical Analysis (ethos, pathos, logos); SWOT (organizational or policy analysis); Feminist/Marxist/Postcolonial theory (cultural texts); PICO (medical evidence); Logical Fallacy identification (any argument). The right framework depends on your discipline and text type."
          }
    ],
    prompt: `Perform a thorough critical analysis.
Document type: {style}
Text to analyze: {input}

Analyze:
1. MAIN ARGUMENT & THESIS — clearly stated?
2. EVIDENCE QUALITY — primary sources? peer-reviewed?
3. LOGICAL STRUCTURE — reasoning valid?
4. ASSUMPTIONS — stated vs. unstated?
5. LOGICAL FALLACIES — identify any present
6. RHETORICAL STRATEGIES — ethos, pathos, logos
7. BIAS & PERSPECTIVE — whose view is centered?
8. LIMITATIONS & GAPS
9. OVERALL STRENGTH RATING (1-10) with justification`
  },
  {
    id: 'research-summary-generator',
    cat: 'research',
    ico: '📄',
    name: 'Research Summary Generator',
    short: 'Research Summary',
    tagline: 'Summarize complex research papers and studies clearly and accurately',
    desc: 'Transform dense research papers into clear, structured summaries. Extracts key findings, methodology, implications, and limitations for academic and general audiences.',
    metaTitle: 'Research Summary Generator Free — AI Tool | ProScholersTools',
    metaDesc: 'Free research summary generator. Summarize complex research papers, extract key findings, methodology, and implications. Academic and plain-language versions.',
    keyword: 'research paper summary generator',
    color: '#1a5c8b',
    styles: ['Academic Summary', 'Executive Summary', 'Plain Language Summary', 'Systematic Review Summary', 'Policy Brief'],
    sources: ['Full Paper', 'Abstract + Key Sections', 'Paper URL'],
    relatedTools: ['critical-analysis-tool', 'literature-review-writer', 'abstract-generator', 'peer-review-assistant'],
    faqs: [
          {
                "q": "What is the difference between an abstract and a research summary?",
                "a": "An abstract is a standardized technical document attached to a research paper, written for specialists. A research summary is written for a broader audience, may simplify technical language, focus on practical implications, and can be published independently as a brief."
          },
          {
                "q": "How technical should a research summary be?",
                "a": "Match technical level to audience. For academics: maintain disciplinary terminology. For policymakers: replace jargon with plain language, focus on practical implications. For general public: avoid all unexplained acronyms and statistical language, lead with \"what this means for you.\""
          },
          {
                "q": "What must every research summary include?",
                "a": "(1) What question did this research address? (2) How was it conducted? (3) What were the key findings? (4) What do findings mean for practitioners, policymakers, or the field? A summary missing any of these four elements is incomplete."
          }
    ],
    prompt: `Generate a clear research summary.
Summary type: {style}
Research paper content: {input}

Provide:
1. ONE-SENTENCE SUMMARY (tweet-length)
2. STRUCTURED SUMMARY:
   - Research Question
   - Methodology
   - Key Findings (3-5 bullet points)
   - Implications
   - Limitations
3. PLAIN LANGUAGE VERSION (for non-specialists)
4. CRITICAL NOTES (what the paper does/doesn't prove)`
  },

  // ── WRITING ──────────────────────────────────────────────────────────
  {
    id: 'academic-paraphrasing',
    cat: 'writing',
    ico: '🔄',
    name: 'Academic Paraphrasing Tool',
    short: 'Paraphrasing',
    tagline: 'Rephrase academic content while preserving meaning and scholarly tone',
    desc: 'Paraphrase academic text while maintaining scholarly language, preserving meaning, and improving clarity. Multiple paraphrase options from formal to simplified.',
    metaTitle: 'Academic Paraphrasing Tool Free — AI Rewriter | ProScholersTools',
    metaDesc: 'Free academic paraphrasing tool. Rephrase academic content while preserving meaning. Formal, simplified, and discipline-specific paraphrase options.',
    keyword: 'academic paraphrasing tool free',
    color: '#2d7a4f',
    styles: ['Formal Academic', 'Simplified', 'Discipline-Specific (Sciences)', 'Discipline-Specific (Humanities)', 'Plain Language'],
    sources: ['Direct Quote', 'Passage from Paper', 'Complex Sentence'],
    relatedTools: ['plagiarism-rewriter', 'academic-vocabulary-enhancer', 'essay-outline-generator', 'peer-review-assistant'],
    faqs: [
      { q: 'Is paraphrasing considered plagiarism?', a: 'No, if done properly. Paraphrasing means restating in your own words AND citing the original source. Changing only a few words is insufficient — the structure and vocabulary must be substantially different.' },
    ],
    prompt: `Paraphrase the following academic text professionally.
Style: {style}
Source type: {src}
Text to paraphrase: {input}

Provide:
1. PARAPHRASE VERSION 1 (closest to original meaning)
2. PARAPHRASE VERSION 2 (more restructured)
3. SIMPLIFIED VERSION (accessible language)
4. IN-TEXT CITATION NOTE (how to cite after paraphrasing)
5. WHAT TO AVOID — phrases still too close to original`
  },
  {
    id: 'plagiarism-rewriter',
    cat: 'writing',
    ico: '🛡️',
    name: 'Plagiarism Rewriter',
    short: 'Plagiarism Rewriter',
    tagline: 'Rewrite content to avoid plagiarism while keeping academic quality',
    desc: 'Restructure and rewrite academic content to ensure originality while maintaining scholarly quality and argument integrity. Produces multiple unique versions.',
    metaTitle: 'Plagiarism Rewriter Free — Academic AI Tool | ProScholersTools',
    metaDesc: 'Free plagiarism rewriter. Rewrite academic content to ensure originality while maintaining scholarly quality. Multiple unique versions with citation guidance.',
    keyword: 'plagiarism rewriter free academic',
    color: '#7a3d1a',
    styles: ['Heavy Restructure', 'Moderate Rewrite', 'Style Change', 'Perspective Shift'],
    sources: ['Paragraph', 'Essay Section', 'Multiple Sentences'],
    relatedTools: ['academic-paraphrasing', 'academic-vocabulary-enhancer', 'peer-review-assistant', 'essay-outline-generator'],
    faqs: [
          {
                "q": "Will rewriting make plagiarised text acceptable?",
                "a": "Only if the idea is properly cited AND substantially rewritten. Rewriting without a citation is still plagiarism. The goal is to genuinely understand the idea and express it in your own voice, followed by proper citation."
          },
          {
                "q": "Why do plagiarism checkers flag properly cited passages?",
                "a": "Detection tools measure textual similarity, not citation correctness. Even a properly cited direct quote will be flagged. Ensure direct quotes are marked with quotation marks and paraphrased passages are genuinely rewritten, not just slightly altered."
          },
          {
                "q": "What percentage similarity is acceptable?",
                "a": "No universal threshold — institutional policies vary. Most universities consider below 10-15% acceptable, but context matters. A literature review with many citations might legitimately show 20%+. 5% similarity from a single source without citation is more problematic than 20% spread across properly cited sources."
          }
    ],
    prompt: `Rewrite for academic originality.
Rewrite level: {style}
Original text: {input}

Provide:
1. REWRITTEN VERSION A (completely restructured)
2. REWRITTEN VERSION B (different sentence order + vocabulary)
3. SIMILARITY ASSESSMENT — what still needs changing
4. CITATION REMINDER — what still needs citation
5. ORIGINALITY TIPS for this type of content`
  },
  {
    id: 'academic-email-writer',
    cat: 'writing',
    ico: '📧',
    name: 'Academic Email Writer',
    short: 'Academic Emails',
    tagline: 'Write professional academic emails to professors, supervisors, and institutions',
    desc: 'Compose professional academic emails for any situation — contacting professors, requesting extensions, applying for programs, and communicating with supervisors.',
    metaTitle: 'Academic Email Writer Free — AI Professional Emails | ProScholersTools',
    metaDesc: 'Free academic email writer. Write professional emails to professors, request extensions, apply for programs. Formal academic tone, all situations covered.',
    keyword: 'academic email writer free ai',
    color: '#4a1a7a',
    styles: ['Email to Professor', 'Extension Request', 'Research Inquiry', 'Grad School Application', 'Conference Networking'],
    sources: ['Email Purpose', 'Situation Details'],
    relatedTools: ['essay-outline-generator', 'academic-paraphrasing', 'peer-review-assistant', 'abstract-generator'],
    faqs: [
          {
                "q": "How should I address a professor in an email?",
                "a": "Use 'Dear Professor [Last Name]' or 'Dear Dr. [Last Name]' for academics with doctoral degrees. Avoid 'Hey,' 'Hi [First Name],' or 'Dear Sir/Madam' unless explicitly invited to use first names. When in doubt, be more formal."
          },
          {
                "q": "How long should an academic email be?",
                "a": "As short as possible while providing all necessary context. One paragraph for simple requests; two to three paragraphs maximum for complex situations. If more than three paragraphs are needed, request a meeting instead."
          },
          {
                "q": "What should an extension request email include?",
                "a": "(1) Which assignment and original deadline; (2) The specific reason — honest but brief; (3) Your requested new deadline; (4) Confirmation you understand the stakes. Avoid over-explaining or excessive apologizing."
          }
    ],
    prompt: `Write a professional academic email.
Email type: {style}
Situation and recipient: {input}

Provide:
1. SUBJECT LINE (concise, professional)
2. FULL EMAIL (appropriate length for type)
3. FORMAL VARIANT (most conservative tone)
4. DIRECT VARIANT (slightly more casual but professional)
5. FOLLOW-UP EMAIL template if no response in 1 week`
  },
  {
    id: 'essay-outline-generator',
    cat: 'writing',
    ico: '📐',
    name: 'Essay Outline Generator',
    short: 'Essay Outline',
    tagline: 'Generate detailed essay outlines for any type of academic writing',
    desc: 'Create comprehensive essay outlines with thesis, topic sentences, evidence slots, and transitions. Supports argumentative, analytical, compare-contrast, and research essays.',
    metaTitle: 'Essay Outline Generator Free — AI Academic | ProScholersTools',
    metaDesc: 'Free essay outline generator. Create detailed outlines for argumentative, analytical, and research essays. Thesis, topic sentences, evidence slots, transitions included.',
    keyword: 'essay outline generator free',
    color: '#8b1a1a',
    styles: ['Argumentative Essay', 'Analytical Essay', 'Compare & Contrast', 'Research Paper', 'Persuasive Essay', '5-Paragraph Essay'],
    sources: ['Essay Topic', 'Thesis Statement', 'Assignment Prompt'],
    relatedTools: ['thesis-statement-generator', 'academic-paraphrasing', 'research-summary-generator', 'literature-review-writer'],
    faqs: [
          {
                "q": "How detailed should an essay outline be?",
                "a": "For a 1,000-word essay: 3-level outline (sections, paragraphs, key points). For a 5,000-word essay: include all body paragraphs, topic sentences, and evidence slots. For a dissertation chapter: include sub-sections, argument flow, and key sources per section."
          },
          {
                "q": "Should I write an outline before or after researching?",
                "a": "Write a preliminary outline before researching (to identify knowledge gaps), revise during research (as new angles emerge), and finalize before writing (to ensure structural coherence). Most experienced writers use 3 outline versions."
          },
          {
                "q": "What is the difference between a topic outline and a sentence outline?",
                "a": "A topic outline uses short phrases — quick structure planning. A sentence outline writes complete sentences for each point — much more work, but ensures each point can develop into a full paragraph. For complex academic papers, the sentence outline is worth the effort."
          }
    ],
    prompt: `Create a detailed essay outline.
Essay type: {style}
Topic/prompt: {input}

Provide:
I. INTRODUCTION
   - Hook (3 options)
   - Background context
   - Thesis statement

II-IV. BODY PARAGRAPHS (for each):
   - Topic sentence
   - Evidence/example slots
   - Analysis guidance
   - Transition to next paragraph

V. CONCLUSION
   - Restatement strategy
   - Broader implications
   - Closing statement

WRITING TIPS specific to this essay type`
  },
  {
    id: 'academic-vocabulary-enhancer',
    cat: 'writing',
    ico: '📖',
    name: 'Academic Vocabulary Enhancer',
    short: 'Vocabulary Enhancer',
    tagline: 'Elevate your academic writing with discipline-specific vocabulary',
    desc: 'Improve academic writing by replacing informal language with scholarly vocabulary. Provides discipline-specific terminology and transition phrases for stronger papers.',
    metaTitle: 'Academic Vocabulary Enhancer Free — AI Writing | ProScholersTools',
    metaDesc: 'Free academic vocabulary enhancer. Replace informal language with scholarly terms. Discipline-specific vocabulary, transition phrases, stronger academic writing.',
    keyword: 'academic vocabulary enhancer free',
    color: '#1a5c8b',
    styles: ['General Academic', 'Sciences & STEM', 'Humanities & Arts', 'Social Sciences', 'Law & Policy'],
    sources: ['Paragraph to Improve', 'Sentence List', 'Draft Section'],
    relatedTools: ['academic-paraphrasing', 'plagiarism-rewriter', 'peer-review-assistant', 'essay-outline-generator'],
    faqs: [
          {
                "q": "Is more complex vocabulary always better in academic writing?",
                "a": "No. The goal is precision, not impressiveness. 'The study examined' is perfectly good academic writing — wordier is not better. Use formal vocabulary where it conveys meaning more precisely, not to demonstrate sophistication."
          },
          {
                "q": "What transitions are most useful in academic writing?",
                "a": "Addition: furthermore, moreover, additionally. Contrast: however, nevertheless, conversely. Causation: consequently, therefore, thus. Concession: although, despite, notwithstanding. Emphasis: significantly, notably, crucially. Overuse any transition and it loses its function."
          },
          {
                "q": "What are the most common informal vocabulary mistakes?",
                "a": "Replace: 'a lot of' → numerous, substantial. 'Things' → name the specific thing. 'Very/really' → remove or use a stronger word. 'Show' → demonstrate, indicate, reveal. 'Get' → obtain, receive, achieve. 'Due to the fact that' → because."
          }
    ],
    prompt: `Enhance academic vocabulary and language.
Discipline: {style}
Text to improve: {input}

Provide:
1. ENHANCED VERSION (formal academic language throughout)
2. WORD UPGRADES LIST — original → improved (10+ swaps)
3. TRANSITION PHRASES added and why
4. HEDGING LANGUAGE suggestions (for claims)
5. DISCIPLINE-SPECIFIC TERMS to incorporate
6. READABILITY SCORE comparison estimate`
  },
  {
    id: 'peer-review-assistant',
    cat: 'writing',
    ico: '🔬',
    name: 'Peer Review Assistant',
    short: 'Peer Review',
    tagline: 'Generate structured peer review feedback for academic papers',
    desc: 'Generate structured, constructive peer review feedback for academic papers. Evaluates methodology, argument clarity, evidence quality, and scholarly contribution.',
    metaTitle: 'Peer Review Assistant Free — Academic Feedback AI | ProScholersTools',
    metaDesc: 'Free peer review assistant. Generate structured academic peer review feedback. Evaluate methodology, arguments, evidence quality, and scholarly contribution.',
    keyword: 'peer review assistant ai free',
    color: '#2d7a4f',
    styles: ['Double-Blind Review', 'Open Review', 'Thesis Review', 'Conference Paper', 'Grant Review'],
    sources: ['Full Paper', 'Paper Abstract + Sections', 'Manuscript Draft'],
    relatedTools: ['critical-analysis-tool', 'research-summary-generator', 'academic-paraphrasing', 'literature-review-writer'],
    faqs: [
          {
                "q": "What makes peer review feedback useful?",
                "a": "Specific, evidence-based, and constructive. Specify problems with reference to particular passages: 'The causal claim on page 7 is not supported by the correlational data in Figure 3.' Avoid vague ('argument is weak') or personal ('author clearly does not understand the field') feedback."
          },
          {
                "q": "How long should a peer review be?",
                "a": "Journal peer reviews: 400-1,000 words. Shorter than 300 words is usually insufficient to justify a recommendation. Longer than 2,000 risks overwhelming the author. Conference reviews: 200-500 words. Class assignments: follow instructor specifications."
          },
          {
                "q": "What is the difference between major and minor revision?",
                "a": "Major revision: fundamental issues affecting validity, contribution, or logic requiring substantial reworking. Minor revision: paper is essentially sound but needs specific, enumerable improvements. Rejection: paper is not suitable for the journal regardless of revision."
          }
    ],
    prompt: `Generate structured peer review feedback.
Review type: {style}
Paper/manuscript content: {input}

Provide:
SUMMARY EVALUATION
1. MAJOR STRENGTHS (3-5 points)
2. MAJOR WEAKNESSES (3-5 points)

DETAILED FEEDBACK:
3. METHODOLOGY — sound?
4. LITERATURE — comprehensive?
5. ARGUMENT CLARITY — coherent?
6. EVIDENCE QUALITY — sufficient?
7. WRITING & STRUCTURE
8. ETHICAL CONSIDERATIONS

RECOMMENDATION: Accept / Minor Revision / Major Revision / Reject
SPECIFIC LINE EDITS (5-7 examples with suggested changes)`
  },

  // ── LEGAL ──────────────────────────────────────────────────────────
  {
    id: 'legal-case-brief',
    cat: 'legal',
    ico: '⚖️',
    name: 'Legal Case Brief Generator',
    short: 'Case Brief (IRAC)',
    tagline: 'Generate professional legal case briefs using IRAC, CREAC, and IRAAC',
    desc: 'Generate comprehensive legal case briefs using IRAC, CREAC, and IRAAC frameworks. Perfect for law students, paralegals, and legal research.',
    metaTitle: 'Legal Case Brief Generator — IRAC, CREAC, IRAAC | ProScholersTools',
    metaDesc: 'Free legal case brief generator. Create professional IRAC, CREAC, and IRAAC case briefs for law students and legal research. Instant, structured, comprehensive.',
    keyword: 'legal case brief generator irac free',
    color: '#1a1a4a',
    styles: ['IRAC', 'CREAC', 'IRAAC', 'Predictive Memo', 'Case Synthesis'],
    sources: ['Case Name + Citation', 'Case Summary', 'Facts of Case'],
    relatedTools: ['legal-case-analyzer', 'legal-memorandum-writer', 'footnote-formatter', 'bibliography-builder'],
    faqs: [
      { q: 'What is the IRAC method?', a: 'IRAC stands for Issue, Rule, Application, Conclusion. It is the standard framework for legal analysis — identify the legal issue, state the applicable rule of law, apply the rule to the facts, then state your conclusion.' },
    ],
    prompt: `Generate a comprehensive legal case brief.
Framework: {style}
Case citation and facts: {input}

Provide:
1. CASE CITATION (proper Bluebook format)
2. PARTIES & PROCEDURAL HISTORY
3. FACTS (relevant, concise)
4. ISSUE(S) PRESENTED
5. RULE(S) OF LAW
6. ANALYSIS/APPLICATION
7. HOLDING
8. RATIONALE
9. CONCURRENCES/DISSENTS (if applicable)
10. SIGNIFICANCE & BROADER IMPLICATIONS`
  },
  {
    id: 'legal-case-analyzer',
    cat: 'legal',
    ico: '🔎',
    name: 'Legal Case Analyzer',
    short: 'Case Analyzer',
    tagline: 'Deep legal analysis of cases — arguments, precedents, and implications',
    desc: 'Perform deep legal analysis of court cases. Analyzes arguments, identifies precedents, assesses holdings, and evaluates legal implications across jurisdictions.',
    metaTitle: 'Legal Case Analyzer — AI Legal Research Tool | ProScholersTools',
    metaDesc: 'Free legal case analyzer. Deep analysis of court cases — arguments, precedents, holdings, and legal implications. For law students and legal professionals.',
    keyword: 'legal case analyzer ai free',
    color: '#1a2a4a',
    styles: ['Constitutional Law', 'Contract Law', 'Tort Law', 'Criminal Law', 'Administrative Law', 'International Law'],
    sources: ['Case Name + Citation', 'Case Excerpt', 'Fact Pattern'],
    relatedTools: ['legal-case-brief', 'legal-memorandum-writer', 'critical-analysis-tool', 'footnote-formatter'],
    faqs: [
          {
                "q": "What is the difference between holding and dicta?",
                "a": "The holding is the legal rule the court needed to decide the case — it is binding precedent. Dicta are statements the court made but didn't need to reach its decision — persuasive but not binding. Identifying which is which is one of the most important skills in legal analysis."
          },
          {
                "q": "How do I identify the key legal rule in a case?",
                "a": "Find it in the majority opinion's reasoning section — where the court explains why it ruled as it did. Look for 'we hold that,' 'the rule is,' or 'we therefore conclude.' Strip away case-specific facts to find the generalizable legal principle."
          },
          {
                "q": "What is stare decisis?",
                "a": "The doctrine that courts follow prior decisions on the same legal question. When analyzing a case, determine: (1) which court issued it — is it binding in your jurisdiction? (2) Has it been affirmed, distinguished, or overruled by later cases? Technically sound analysis of an overruled case has limited value."
          }
    ],
    prompt: `Perform in-depth legal case analysis.
Area of law: {style}
Case details: {input}

Provide:
1. CASE OVERVIEW (2-3 sentences)
2. LEGAL ISSUES IDENTIFIED
3. COURT'S REASONING — strengths and weaknesses
4. PRECEDENTS RELIED ON vs. DISTINGUISHED
5. POLICY IMPLICATIONS
6. CRITIQUE of the decision
7. HOW THIS CASE WOULD APPLY to a hypothetical scenario
8. RELATED CASES to consider`
  },
  {
    id: 'legal-memorandum-writer',
    cat: 'legal',
    ico: '📋',
    name: 'Legal Memorandum Writer',
    short: 'Legal Memo',
    tagline: 'Draft professional legal memoranda — office memos, demand letters, legal opinions',
    desc: 'Draft professional legal memoranda for law firms, courts, and clients. Supports office legal memos, demand letters, legal opinion letters, and court brief memos.',
    metaTitle: 'Legal Memorandum Writer — AI Legal Documents | ProScholersTools',
    metaDesc: 'Free legal memorandum writer. Draft professional office memos, demand letters, legal opinion letters, and court brief memos. Bluebook citations included.',
    keyword: 'legal memorandum writer ai free',
    color: '#2a1a4a',
    styles: ['Office Legal Memo (Predictive)', 'Demand Letter', 'Legal Opinion Letter', 'Court Brief Memo', 'Settlement Memo'],
    sources: ['Legal Issue + Facts', 'Client Situation', 'Case Summary'],
    relatedTools: ['legal-case-brief', 'legal-case-analyzer', 'footnote-formatter', 'academic-email-writer'],
    faqs: [
      { q: 'What is the standard format for a legal memorandum?', a: 'A legal memorandum typically includes: HEADER (To/From/Date/Re), QUESTION PRESENTED, SHORT ANSWER, FACTS, DISCUSSION (IRAC), and CONCLUSION. Demand letters and opinion letters have different structures.' },
    ],
    prompt: `Draft a professional legal memorandum.
Memo type: {style}
Legal issue and facts: {input}

Provide complete memo with:
HEADER: TO / FROM / DATE / RE / ATTORNEY-CLIENT PRIVILEGE

1. QUESTION PRESENTED
2. SHORT ANSWER
3. FACTS (legally relevant only)
4. DISCUSSION:
   - Issue identification
   - Rule statement (with Bluebook citations)
   - Application to facts
   - Counter-arguments addressed
5. CONCLUSION & RECOMMENDATION
6. CAVEAT / LIMITATIONS of this analysis`
  },
  {
    id: 'case-study-analyzer',
    cat: 'legal',
    ico: '📊',
    name: 'Case Study Analyzer',
    short: 'Case Study',
    tagline: 'Comprehensive analysis of business, legal, and academic case studies',
    desc: 'Analyze complex case studies across business, law, medicine, and social sciences. Identifies problems, evaluates solutions, and produces structured analytical reports.',
    metaTitle: 'Case Study Analyzer Free — AI Analysis Tool | ProScholersTools',
    metaDesc: 'Free case study analyzer. Comprehensive analysis of business, legal, medical, and academic case studies. Problem identification, evaluation, recommendations.',
    keyword: 'case study analyzer ai free',
    color: '#1a3a5a',
    styles: ['Business Strategy', 'Legal', 'Medical/Clinical', 'Social Sciences', 'Education'],
    sources: ['Case Study Text', 'Case Summary + Questions', 'Scenario Description'],
    relatedTools: ['legal-case-brief', 'critical-analysis-tool', 'research-summary-generator', 'peer-review-assistant'],
    faqs: [
          {
                "q": "What is the most common mistake in case study analysis?",
                "a": "Describing the situation instead of analyzing it. Strong case study analysis spends at most 20% describing the situation and 80% analyzing, applying frameworks, and recommending. A case study is not a report on what happened — it is a structured analysis of why it happened and what should follow."
          },
          {
                "q": "Which analytical framework should I use?",
                "a": "Porter's Five Forces for industry competitiveness; SWOT for strategic position; PESTLE for macro-environment; McKinsey 7S for organizational alignment; Value Chain for operational efficiency. Many strong analyses combine multiple frameworks — SWOT to identify issues, Porter's to understand competitive dynamics, then strategic recommendations."
          },
          {
                "q": "How long should recommendations be?",
                "a": "Recommendations should be the most detailed section — typically 30-40% of the total analysis. Each recommendation should state: (1) what to do; (2) why (tied to a specific finding); (3) how to implement; (4) what success looks like."
          }
    ],
    prompt: `Analyze this case study comprehensively.
Case type: {style}
Case study content: {input}

Provide:
1. SITUATION SUMMARY
2. KEY PROBLEMS IDENTIFIED (prioritized)
3. STAKEHOLDER ANALYSIS
4. ROOT CAUSE ANALYSIS
5. ALTERNATIVE SOLUTIONS (3 options with pros/cons)
6. RECOMMENDED SOLUTION with justification
7. IMPLEMENTATION PLAN
8. METRICS FOR SUCCESS
9. LESSONS LEARNED`
  },

  // ── TEACHER ──────────────────────────────────────────────────────────
  {
    id: 'lesson-plan-generator',
    cat: 'teacher',
    ico: '📐',
    name: 'Lesson Plan Generator',
    short: 'Lesson Plans',
    tagline: 'Generate complete, standards-aligned lesson plans for any grade and subject',
    desc: 'Create complete lesson plans with objectives, activities, differentiation strategies, and assessments. Standards-aligned for K-12 and university teaching.',
    metaTitle: 'Lesson Plan Generator Free — AI Teacher Tool | ProScholersTools',
    metaDesc: 'Free AI lesson plan generator. Create complete, standards-aligned lesson plans for K-12 and university. Objectives, activities, differentiation, assessment included.',
    keyword: 'lesson plan generator ai free',
    color: '#1a5a8b',
    styles: ['Elementary (K-5)', 'Middle School (6-8)', 'High School (9-12)', 'University/College', 'ESL/EFL'],
    sources: ['Subject + Topic + Duration', 'Curriculum Standard', 'Learning Objectives'],
    relatedTools: ['rubric-builder', 'exam-question-generator', 'student-feedback-generator', 'study-plan-creator'],
    faqs: [
          {
                "q": "What is the difference between a learning objective and a learning activity?",
                "a": "A learning objective states what students will know or be able to DO by the end of the lesson — a measurable outcome. A learning activity is what students do during class to achieve the objective. 'Students will debate WWI causes' is an activity. 'Students will evaluate three historical interpretations using primary source evidence' is an objective."
          },
          {
                "q": "How much time should each lesson component receive?",
                "a": "For a 60-minute lesson: Opening/hook (5 min), objective review (3 min), direct instruction (15 min), guided practice (15 min), independent/collaborative activity (15 min), exit ticket (5 min), closure (2 min). Adjust based on content complexity and student needs."
          },
          {
                "q": "How do I differentiate for diverse learners?",
                "a": "Use Universal Design for Learning (UDL): multiple means of representation (visual, audio, text), engagement (individual, pair, group), and expression (written, verbal, visual). Strategies include tiered assignments (same content, different complexity), flexible grouping, and choice boards."
          }
    ],
    prompt: `Create a comprehensive lesson plan.
Grade level: {style}
Subject, topic, and duration: {input}

Provide complete lesson plan:
1. LESSON TITLE & OVERVIEW
2. LEARNING OBJECTIVES (SMART, measurable, Bloom's levels)
3. STANDARDS ALIGNMENT (Common Core / curriculum link)
4. MATERIALS & RESOURCES
5. LESSON STRUCTURE:
   - Warm-Up / Hook (5 min)
   - Direct Instruction
   - Guided Practice (teacher-led)
   - Independent Practice (student work)
   - Closure / Exit Ticket
6. DIFFERENTIATION (advanced / struggling students)
7. FORMATIVE ASSESSMENT METHOD
8. HOMEWORK (if applicable)
9. TEACHER REFLECTION PROMPTS`
  },
  {
    id: 'rubric-builder',
    cat: 'teacher',
    ico: '📏',
    name: 'Rubric & Assessment Builder',
    short: 'Rubric Builder',
    tagline: 'Build professional grading rubrics for any assignment or assessment',
    desc: 'Create detailed grading rubrics for essays, projects, presentations, and lab reports. Generates analytic, holistic, and single-point rubrics with clear performance descriptors.',
    metaTitle: 'Rubric Builder Free — AI Teacher Assessment Tool | ProScholersTools',
    metaDesc: 'Free rubric builder. Create analytic, holistic, and single-point rubrics for essays, projects, presentations. Clear performance descriptors and point values.',
    keyword: 'rubric builder free teacher',
    color: '#2d7a4f',
    styles: ['Analytic Rubric (4-point)', 'Holistic Rubric', 'Single-Point Rubric', 'Checklist', 'Primary Trait'],
    sources: ['Assignment Description', 'Learning Objectives', 'Assessment Type'],
    relatedTools: ['lesson-plan-generator', 'exam-question-generator', 'student-feedback-generator', 'study-plan-creator'],
    faqs: [
          {
                "q": "How many criteria should a rubric have?",
                "a": "For most assignments: 4-6 criteria is ideal. Fewer than 3 is too broad; more than 8 becomes unmanageable to assess consistently and overwhelming for students to process as feedback. Each criterion should represent a distinct, assessable component."
          },
          {
                "q": "What is the difference between analytic and holistic rubrics?",
                "a": "An analytic rubric evaluates each criterion separately on a scale — more time-consuming but provides detailed diagnostic feedback. A holistic rubric gives one overall score based on overall performance description — faster to apply, better for standardized assessments."
          },
          {
                "q": "Should I share rubrics before students complete assignments?",
                "a": "Yes — research consistently shows students who receive rubrics before assignments produce higher-quality work. Rubrics communicate your expectations, not \"give away answers.\" Pre-assignment rubric discussion also significantly reduces grade disputes."
          }
    ],
    prompt: `Create a professional grading rubric.
Rubric type: {style}
Assignment and grade level: {input}

Provide:
1. RUBRIC TITLE & PURPOSE
2. GRADING SCALE (4-3-2-1 or Excellent/Proficient/Developing/Beginning)
3. CRITERIA TABLE (4-6 criteria) with:
   - Each criterion clearly defined
   - Performance descriptor for each level
   - Point values
4. TOTAL POINTS CALCULATION
5. TEACHER NOTES (what to look for)
6. STUDENT-FACING VERSION (simplified language)`
  },
  {
    id: 'study-plan-creator',
    cat: 'teacher',
    ico: '📅',
    name: 'Student Study Plan Creator',
    short: 'Study Plans',
    tagline: 'Create personalized study plans for students — weekly, exam prep, semester',
    desc: 'Generate personalized study plans for students at all levels. Creates weekly schedules, exam preparation plans, and semester-long study strategies with time management guidance.',
    metaTitle: 'Study Plan Creator Free — AI Student Planner | ProScholersTools',
    metaDesc: 'Free study plan creator. Generate weekly, exam prep, and semester study plans for students. Time management, subject prioritization, and review strategies.',
    keyword: 'study plan creator ai free',
    color: '#b8860b',
    styles: ['Weekly Schedule', '2-Week Exam Prep', 'Semester Plan', 'Rapid Revision (48h)'],
    sources: ['Subjects + Deadlines', 'Exam Dates + Topics', 'Student Profile'],
    relatedTools: ['lesson-plan-generator', 'rubric-builder', 'exam-question-generator', 'student-feedback-generator'],
    faqs: [
          {
                "q": "How many hours per day should I study?",
                "a": "Research suggests 3-5 hours of focused, intentional study daily is optimal — beyond this, cognitive fatigue causes rapidly diminishing returns. Quality beats quantity: 3 hours of focused study outperforms 7 hours of distracted, multitasking study."
          },
          {
                "q": "What is spaced repetition?",
                "a": "A technique that schedules review sessions at increasing intervals as material becomes more familiar — new material: review after 1 day, then 3 days, then 1 week, then 2 weeks. The most evidence-backed method for long-term memory retention, especially effective for factual content and vocabulary."
          },
          {
                "q": "How should I prioritize when overwhelmed?",
                "a": "Use the 'eat the frog' principle: tackle the hardest subject first, when cognitive resources are freshest. Prioritize by: (1) exam date proximity; (2) grade weight; (3) current knowledge gaps. Study subjects daily — 45 minutes of maths every day far outperforms 5 hours the night before an exam."
          }
    ],
    prompt: `Create a detailed student study plan.
Plan type: {style}
Student details, subjects, and deadlines: {input}

Provide:
1. STUDY SCHEDULE (day-by-day or week-by-week breakdown)
2. SUBJECT PRIORITIZATION RATIONALE
3. DAILY TIME BLOCKS (with break structure — Pomodoro or spaced)
4. REVIEW MILESTONES
5. ACTIVE RECALL TECHNIQUES for each subject
6. SELF-ASSESSMENT CHECKPOINTS
7. CONTINGENCY PLAN (if behind schedule)
8. MOTIVATION & WELLBEING TIPS`
  },
  {
    id: 'student-feedback-generator',
    cat: 'teacher',
    ico: '💬',
    name: 'Student Feedback Generator',
    short: 'Student Feedback',
    tagline: 'Generate constructive, personalized feedback for student work',
    desc: 'Generate detailed, constructive feedback for student essays, presentations, lab reports, and projects. Personalized, growth-focused, and aligned with learning objectives.',
    metaTitle: 'Student Feedback Generator Free — AI Teacher Tool | ProScholersTools',
    metaDesc: 'Free student feedback generator. Create constructive, personalized feedback for essays, presentations, and projects. Growth-focused, detailed, and standards-aligned.',
    keyword: 'student feedback generator teacher ai',
    color: '#6b3fa0',
    styles: ['Essay Feedback', 'Presentation Feedback', 'Lab Report', 'Creative Project', 'Report Card Comment'],
    sources: ['Student Work Description', 'Assignment + Student Response', 'Submission Summary'],
    relatedTools: ['rubric-builder', 'lesson-plan-generator', 'exam-question-generator', 'peer-review-assistant'],
    faqs: [
          {
                "q": "How do I give constructive feedback on a very poor assignment?",
                "a": "Start by identifying anything genuinely done well. Focus on 2-3 most impactful issues rather than cataloguing every error. Provide specific guidance on how to improve, not just what is wrong. Use language attributing weakness to the work, not the student: 'The argument would be strengthened by...' not 'You failed to...'"
          },
          {
                "q": "How much written feedback should I provide?",
                "a": "Formative feedback (before final submission): detailed maximizes improvement. Summative feedback (after grading): 100-300 words covering key strengths and improvement areas is standard. Research shows students rarely read more than 300 words of end-of-assignment feedback."
          },
          {
                "q": "Should feedback focus more on strengths or weaknesses?",
                "a": "Both are necessary. For formative feedback: lead with strengths, then substantial improvement guidance. For summative: balanced evaluation of both. For struggling students: more encouragement and specific, achievable next steps. Never give only positive feedback on work needing substantial improvement — this is a disservice."
          }
    ],
    prompt: `Generate constructive student feedback.
Assignment type: {style}
Student work details and performance: {input}

Provide:
1. OPENING COMMENT (positive, specific strength)
2. DETAILED FEEDBACK by criterion:
   - What was done well (with specific evidence)
   - What needs improvement (specific, actionable)
3. TOP 3 ACTIONABLE IMPROVEMENTS
4. NEXT STEPS for student growth
5. SHORT REPORT CARD COMMENT (2-3 sentences, formal tone)
6. GRADE JUSTIFICATION NOTE (for teacher records)`
  },
  {
    id: 'exam-question-generator',
    cat: 'teacher',
    ico: '❓',
    name: 'Exam Question Generator',
    short: 'Exam Questions',
    tagline: 'Generate exam questions at every Bloom\'s taxonomy level with answer keys',
    desc: 'Generate complete sets of exam questions including MCQ, short answer, and essay questions. Includes answer keys and Bloom\'s taxonomy level mapping.',
    metaTitle: 'Exam Question Generator Free — AI Teacher Tool | ProScholersTools',
    metaDesc: 'Free exam question generator. Create MCQ, short answer, and essay questions with answer keys. Bloom\'s taxonomy levels mapped. Any subject, any grade.',
    keyword: 'exam question generator ai teacher free',
    color: '#a0204a',
    styles: ['Multiple Choice (MCQ)', 'Short Answer', 'Essay Questions', 'Mixed Format Exam', 'True/False + Justification'],
    sources: ['Topic + Grade Level', 'Learning Objectives', 'Textbook Chapter'],
    relatedTools: ['rubric-builder', 'lesson-plan-generator', 'study-plan-creator', 'student-feedback-generator'],
    faqs: [
          {
                "q": "How do I write MCQs that test higher-order thinking?",
                "a": "Present scenarios, data, or case studies requiring analysis: 'A researcher observes Y pattern. Which interpretation is most consistent with theory X?' vs 'What is the definition of X?' Higher-order questions require students to apply or analyze rather than simply recall."
          },
          {
                "q": "How many questions should an exam have?",
                "a": "General guide for a 2-hour exam: allow 1-1.5 minutes per MCQ and 15-20 minutes per short-answer. For a 60-minute exam: 30-40 MCQs, or 20 MCQs + 2 short answers, or 3-4 essay questions. Overly long exams measure test-taking speed more than knowledge."
          },
          {
                "q": "What makes a bad exam question?",
                "a": "Common flaws: (1) Ambiguous stems with multiple defensible answers; (2) 'Trick' questions testing meta-knowledge not content; (3) Double-barreled questions testing two things; (4) Absolute terms like 'always,' 'never,' 'all,' 'none' — usually false and students learn to avoid them; (5) Grammatical clues revealing the answer."
          }
    ],
    prompt: `Generate a complete set of exam questions.
Question type: {style}
Topic, grade level, and difficulty: {input}

Provide:
1. EXAM HEADER (title, instructions, time limit, total marks)
2. QUESTIONS (10-15 questions appropriate for type):
   - Bloom's taxonomy level for each
   - Point value for each
3. ANSWER KEY (complete, with explanation for each)
4. MARKING RUBRIC for open-ended questions
5. DIFFERENTIATION — easier and harder variants of 2 questions`
  },
  // ── FINANCE ────────────────────────────────────────────────────────────
  {
    id: 'loan-calculator',
    cat: 'finance',
    ico: '💰',
    name: 'Loan Calculator',
    short: 'Personal & Business Loans',
    tagline: 'Free loan calculator — monthly payment, total interest, full amortization schedule',
    desc: 'Calculate exact monthly payments, total interest paid, and full amortization schedule for personal loans, auto loans, and business loans. Enter loan amount, interest rate, and term.',
    metaTitle: 'Loan Calculator Free — Monthly Payment & Amortization Schedule',
    metaDesc: 'Free loan calculator. Calculate monthly payments, total interest, and amortization schedule for personal loans, auto loans, and business loans. Instant results.',
    keyword: 'loan calculator monthly payment',
    color: '#1a7a4a',
    styles: ['Personal Loan', 'Auto Loan', 'Business Loan', 'Student Loan', 'Home Equity Loan'],
    sources: [],
    inputLabel: 'Loan Details',
    inputPlaceholder: 'Enter: Loan amount, interest rate (APR %), loan term (months or years). Example: $25,000 loan at 8.5% APR for 5 years.',
    relatedTools: ['mortgage-calculator', 'debt-consolidation-calculator', 'compound-interest-calculator', 'apr-calculator'],
    faqs: [
      { q: 'How is a monthly loan payment calculated?', a: 'Monthly payment = P × [r(1+r)^n] / [(1+r)^n - 1], where P is principal, r is monthly interest rate (APR ÷ 12), and n is total number of months. For a $25,000 loan at 8.5% APR over 60 months: monthly payment ≈ $513.' },
      { q: 'What is a good interest rate for a personal loan?', a: 'In 2026, excellent credit (750+) typically qualifies for 7–12% APR on personal loans. Good credit (700–749) sees 12–18% APR. Fair credit (650–699) sees 18–28% APR. Rates above 36% APR are considered predatory.' },
      { q: 'What is the difference between APR and interest rate?', a: 'The interest rate is the base cost of borrowing. APR (Annual Percentage Rate) includes the interest rate PLUS all fees (origination fees, closing costs). Always compare APR — not just the stated rate — when comparing loans.' },
    ],
    prompt: `You are a precise financial calculator. Calculate the loan details below and provide a complete analysis.

Loan type: {style}
Loan details: {input}

Extract: loan amount ($), APR (%), and term (months). If years given, multiply by 12.

Calculate and show ALL of the following:

## LOAN SUMMARY
- Loan Amount: $X
- Annual Interest Rate (APR): X%
- Monthly Interest Rate: X%
- Loan Term: X months (X years)

## MONTHLY PAYMENT
Monthly Payment = **$X.XX**
Formula used: P × [r(1+r)^n] / [(1+r)^n – 1]

## TOTAL COST BREAKDOWN
- Total Amount Paid: $X
- Total Interest Paid: $X
- Interest as % of Principal: X%

## AMORTIZATION SCHEDULE (first 6 months + last 3 months)
| Month | Payment | Principal | Interest | Balance |
Show a properly formatted table.

## TIPS TO REDUCE TOTAL INTEREST
- Paying $X extra/month would save $X in interest
- Refinancing at X% lower rate would save $X total

Show all numbers to 2 decimal places. Be precise.`
  },
  {
    id: 'mortgage-calculator',
    cat: 'finance',
    ico: '🏠',
    name: 'Mortgage Calculator',
    short: 'Home Loan & Refinance',
    tagline: 'Mortgage calculator with PMI, taxes, insurance — full monthly payment breakdown',
    desc: 'Calculate your complete monthly mortgage payment including principal, interest, PMI, property taxes, and homeowners insurance. Compare fixed vs adjustable rates and see full amortization.',
    metaTitle: 'Mortgage Calculator Free — With PMI, Taxes & Insurance | Monthly Payment',
    metaDesc: 'Free mortgage calculator with PMI, property taxes, and insurance. Calculate your complete monthly mortgage payment. Fixed vs ARM comparison, amortization schedule included.',
    keyword: 'mortgage calculator with taxes and insurance',
    color: '#1a5c8b',
    styles: ['30-Year Fixed', '15-Year Fixed', '20-Year Fixed', '5/1 ARM', 'FHA Loan', 'VA Loan'],
    sources: [],
    inputLabel: 'Home & Loan Details',
    inputPlaceholder: 'Enter: Home price, down payment, interest rate, property tax rate, HOI/year. Example: $450,000 home, $90,000 down (20%), 7.2% rate, 1.2% tax, $1,800/yr insurance.',
    relatedTools: ['loan-calculator', 'debt-consolidation-calculator', 'apr-calculator', 'compound-interest-calculator'],
    faqs: [
      { q: 'How much house can I afford with my income?', a: 'The 28/36 rule: your monthly mortgage payment (PITI) should not exceed 28% of gross monthly income, and total debt payments should not exceed 36%. On a $100,000/year income (~$8,333/month), your maximum mortgage payment is ~$2,333/month, qualifying for roughly $320,000–$380,000 at 7% for 30 years with 10% down.' },
      { q: 'What is PMI and when can I remove it?', a: 'PMI (Private Mortgage Insurance) is required when your down payment is less than 20%. It typically costs 0.5%–1.5% of the loan amount annually ($125–$375/month on a $300,000 loan). You can request PMI removal when your equity reaches 20% (loan-to-value ratio drops to 80%). It automatically cancels at 22% equity under the Homeowners Protection Act.' },
      { q: 'Should I choose a 15-year or 30-year mortgage?', a: 'On a $300,000 mortgage: 30-year at 7% = $1,996/month, $418,527 total interest. 15-year at 6.5% = $2,614/month, $170,520 total interest — saving $248,000 but paying $618/month more. Choose 30-year if cash flow matters; choose 15-year if you can afford higher payments and want to build equity faster.' },
    ],
    prompt: `You are a precise mortgage calculator. Calculate the complete mortgage payment details below.

Mortgage type: {style}
Details: {input}

Extract: home price, down payment ($ or %), interest rate (%), loan term, property tax rate (%), annual homeowners insurance ($), and whether PMI applies.

Calculate and show ALL of the following:

## LOAN DETAILS
- Home Price: $X
- Down Payment: $X (X%)
- Loan Amount: $X
- Interest Rate: X% APR
- Loan Term: X years

## MONTHLY PAYMENT BREAKDOWN
| Component | Monthly Amount |
|---|---|
| Principal & Interest | $X |
| Property Tax | $X |
| Homeowners Insurance | $X |
| PMI (if <20% down) | $X |
| **TOTAL MONTHLY PAYMENT** | **$X** |

## FULL COST SUMMARY
- Total of 360 Payments: $X
- Total Interest Paid: $X
- Total Tax + Insurance (30yr): $X
- **Total Housing Cost: $X**

## AMORTIZATION MILESTONES
- Equity reaches 20% (PMI removal): Month X (Year X)
- Loan 50% paid off: Month X (Year X)
- Break-even vs renting at $X/month: Year X

## FIRST 12 MONTHS AMORTIZATION TABLE
Show monthly breakdown of principal vs interest.

## RATE COMPARISON
Show payment comparison for rate ±0.5% from current rate.

Be precise to 2 decimal places.`
  },
  {
    id: 'compound-interest-calculator',
    cat: 'finance',
    ico: '📈',
    name: 'Compound Interest Calculator',
    short: 'Investment & Savings Growth',
    tagline: 'Compound interest calculator — see how investments grow with regular contributions',
    desc: 'Calculate how your savings and investments grow with compound interest. Supports daily, monthly, and annual compounding with regular contributions. Compare investment scenarios.',
    metaTitle: 'Compound Interest Calculator Free — Investment Growth | Savings Calculator',
    metaDesc: 'Free compound interest calculator. Calculate investment growth with regular contributions. Daily, monthly, annual compounding. Compare savings scenarios instantly.',
    keyword: 'compound interest calculator with monthly contributions',
    color: '#2d6a2d',
    styles: ['Savings Account', 'Investment Portfolio', 'Retirement Account (401k/IRA)', 'CD (Certificate of Deposit)', 'High-Yield Savings'],
    sources: [],
    inputLabel: 'Investment Details',
    inputPlaceholder: 'Enter: Initial amount, monthly contribution, annual interest rate, time period. Example: $10,000 initial, $500/month, 8% annual return, 20 years.',
    relatedTools: ['loan-calculator', 'mortgage-calculator', 'apr-calculator', 'debt-consolidation-calculator'],
    faqs: [
      { q: 'What is the Rule of 72 for compound interest?', a: 'Divide 72 by your annual interest rate to estimate how many years it takes to double your money. At 8% return: 72 ÷ 8 = 9 years to double. At 6%: 12 years. At 10%: 7.2 years. This works because compound growth is exponential — the formula is 72/r where r is the annual percentage rate.' },
      { q: 'How much does monthly contribution frequency matter?', a: 'Dramatically. $500/month at 8% for 30 years: final value ≈ $745,000. Investing the same $6,000/year as a lump sum at year-start: ≈ $803,000. Starting 10 years earlier with $250/month at 8% for 40 years: ≈ $878,000. Starting early beats contributing more.' },
      { q: 'What is the average stock market return for compound interest calculations?', a: 'The S&P 500 has historically returned ~10% average annually before inflation, ~7% after inflation. Financial planners typically use 6–8% for conservative projections. For retirement planning, 5–7% real (inflation-adjusted) return is a prudent assumption. Never rely on past performance as a guarantee.' },
    ],
    prompt: `You are a precise investment calculator. Calculate compound interest growth with the details below.

Account type: {style}
Details: {input}

Extract: initial principal ($), monthly contribution ($), annual interest rate (%), compounding frequency, and time period (years).

Calculate and show ALL of the following:

## INVESTMENT SUMMARY
- Initial Investment: $X
- Monthly Contribution: $X
- Annual Interest Rate: X%
- Compounding: Monthly (or as specified)
- Time Period: X years

## FINAL RESULTS
- **Final Balance: $X**
- Total Contributions: $X (initial + all monthly)
- Total Interest Earned: $X
- Interest as % of Final Balance: X%

## YEAR-BY-YEAR GROWTH TABLE
| Year | Balance | Contributions | Interest Earned |
Show every year for first 10 years, then every 5 years.

## MILESTONES
- First $X doubled (2x): Year X
- Balance reaches $100K: Year X
- Balance reaches $500K: Year X (if applicable)

## COMPOUND FREQUENCY COMPARISON
| Compounding | Final Balance |
| Daily | $X |
| Monthly | $X |
| Annually | $X |

## WHAT-IF SCENARIOS
- If rate was 2% higher (X%): Final balance $X (+$X)
- If contributed $100/month more: Final balance $X (+$X)
- If started 5 years earlier: Final balance $X (+$X)

Show all numbers to 2 decimal places.`
  },
  {
    id: 'debt-consolidation-calculator',
    cat: 'finance',
    ico: '💳',
    name: 'Debt Consolidation Calculator',
    short: 'Debt Payoff & Consolidation',
    tagline: 'Debt consolidation calculator — compare strategies, find fastest payoff path',
    desc: 'Calculate if debt consolidation saves you money. Compare your current debts against a consolidation loan. See exact payoff dates, total interest saved, and monthly savings using snowball and avalanche strategies.',
    metaTitle: 'Debt Consolidation Calculator Free — Compare Debt Payoff Strategies',
    metaDesc: 'Free debt consolidation calculator. Compare debt consolidation loan vs snowball vs avalanche payoff strategies. See exact savings, payoff dates, and monthly payment needed.',
    keyword: 'debt consolidation calculator savings',
    color: '#8b1a4a',
    styles: ['Personal Loan Consolidation', 'Balance Transfer', 'Home Equity Loan (HELOC)', 'Debt Snowball', 'Debt Avalanche'],
    sources: [],
    inputLabel: 'Your Debts',
    inputPlaceholder: 'List all debts with balance, interest rate, and minimum payment. Example:\nCredit Card 1: $8,500 at 24.99% APR, $200/month minimum\nCredit Card 2: $3,200 at 19.99% APR, $90/month minimum\nPersonal Loan: $5,000 at 12% APR, $150/month minimum',
    relatedTools: ['loan-calculator', 'apr-calculator', 'mortgage-calculator', 'compound-interest-calculator'],
    faqs: [
      { q: 'When does debt consolidation actually save money?', a: 'Consolidation saves money when your new loan APR is significantly lower than your weighted average APR across all debts. If your credit cards average 22% APR and you qualify for a consolidation loan at 10%, you save 12% on interest. The savings must exceed any origination fees (typically 1–6% of loan amount). Use this calculator to see exact figures before deciding.' },
      { q: 'What is the difference between debt snowball and debt avalanche?', a: 'Snowball (Dave Ramsey method): Pay minimums on all debts, put extra money toward the SMALLEST balance first. Psychological wins keep you motivated. Avalanche (mathematically optimal): Pay minimums on all debts, put extra money toward the HIGHEST interest rate debt first. Saves the most total interest. Studies show snowball has better completion rates; avalanche saves more money. This calculator shows both.' },
      { q: 'Does debt consolidation hurt your credit score?', a: 'Short-term: yes, slightly. Applying for a consolidation loan causes a hard inquiry (-5 to -10 points). Long-term: usually improves credit. Consolidation lowers your credit utilization ratio (major factor), and on-time payments rebuild your score. Most people see net improvement within 3–6 months if they stop adding new debt.' },
    ],
    prompt: `You are a precise debt elimination calculator. Analyze the debts below and calculate consolidation and payoff strategies.

Strategy: {style}
Debts: {input}

Extract all debts with their balance, APR, and minimum payment.

Calculate and show ALL of the following:

## CURRENT DEBT SNAPSHOT
| Debt | Balance | APR | Min Payment |
Show all debts in a table.
- Total Debt: $X
- Weighted Average APR: X%
- Total Minimum Payments: $X/month
- Payoff Date (minimums only): Month/Year
- Total Interest If Only Minimums Paid: $X

## CONSOLIDATION LOAN OPTION
Assuming consolidation loan at X% APR (estimate based on credit profile):
- New Monthly Payment: $X
- Monthly Savings vs Current: $X
- Total Interest Saved: $X
- Payoff Date: Month/Year

## DEBT SNOWBALL STRATEGY
Order of payoff (smallest to largest balance):
| Priority | Debt | Balance | Target Date |
- Extra payment recommended: $X/month
- Total payoff date: Month/Year
- Total interest paid: $X

## DEBT AVALANCHE STRATEGY
Order of payoff (highest to lowest APR):
| Priority | Debt | APR | Target Date |
- Extra payment recommended: $X/month
- Total payoff date: Month/Year
- Total interest paid: $X
- Savings vs Snowball: $X

## RECOMMENDATION
Which strategy is best based on the numbers, and why.

Be precise. Show exact month/year payoff dates.`
  },
  {
    id: 'apr-calculator',
    cat: 'finance',
    ico: '📊',
    name: 'APR Calculator',
    short: 'True Cost of Borrowing',
    tagline: 'APR calculator — find the true cost of any loan including all fees',
    desc: 'Calculate the true APR of any loan including origination fees, closing costs, and points. Compare loan offers by their real cost, not just the advertised interest rate. Essential before signing any loan.',
    metaTitle: 'APR Calculator Free — True Cost of Loan Including All Fees',
    metaDesc: 'Free APR calculator. Find the true annual percentage rate of any loan including origination fees, points, and closing costs. Compare loan offers by real cost.',
    keyword: 'APR calculator loan true cost',
    color: '#5c3a1a',
    styles: ['Personal Loan APR', 'Mortgage APR', 'Auto Loan APR', 'Business Loan APR', 'Credit Card APR'],
    sources: [],
    inputLabel: 'Loan & Fee Details',
    inputPlaceholder: 'Enter loan details including all fees. Example: $200,000 mortgage, 6.75% stated rate, 30 years, $3,500 origination fee, $1,200 closing costs, 1 point ($2,000).',
    relatedTools: ['mortgage-calculator', 'loan-calculator', 'debt-consolidation-calculator', 'compound-interest-calculator'],
    faqs: [
      { q: 'Why is APR always higher than the interest rate?', a: 'The stated interest rate only covers the cost of borrowing the principal. APR includes ALL costs: origination fees, broker fees, mortgage points, closing costs, and required insurance. By law (Truth in Lending Act / Regulation Z), lenders must disclose APR. A mortgage at 6.75% rate with 1 point ($2,000) and $3,500 in fees has an effective APR of roughly 6.98% — that 0.23% difference costs thousands over 30 years.' },
      { q: 'How do mortgage points affect APR?', a: '1 mortgage point = 1% of the loan amount paid upfront to lower the interest rate by ~0.25%. On a $300,000 mortgage: 1 point costs $3,000 and reduces rate from 7% to 6.75%. Over 30 years, you save ~$16,800 in interest. Break-even point: $3,000 cost ÷ ~$46/month savings = 65 months (~5.4 years). Only worth it if you keep the loan past the break-even point.' },
      { q: 'What APR is considered good for different loan types?', a: 'In 2026: Mortgage (excellent credit): 6.5–7.5% APR. Auto loan new car: 5–8% APR. Auto loan used car: 6–12% APR. Personal loan: 8–15% APR (good credit). Business loan (SBA): 6–10% APR. Credit card: 19–29% APR. Any APR above 36% is considered predatory by most consumer advocates.' },
    ],
    prompt: `You are a precise APR calculator. Calculate the true APR and cost comparison for the loan below.

Loan type: {style}
Loan details: {input}

Extract: loan amount, stated interest rate, loan term, and all fees (origination fee, points, closing costs, etc.).

Calculate and show ALL of the following:

## LOAN TERMS
- Loan Amount: $X
- Stated Interest Rate: X%
- Loan Term: X years (X months)
- All Fees: itemized list

## APR CALCULATION
- Total Fees: $X
- Monthly Payment (stated rate): $X
- **True APR: X%** (X% higher than stated rate)
- Method: Newton-Raphson iterative method on net proceeds

## COST COMPARISON
| | Stated Rate (X%) | True APR (X%) | Difference |
|---|---|---|---|
| Monthly Payment | $X | $X | $X |
| Total Interest | $X | $X | $X |
| Total Paid | $X | $X | $X |

## FEE IMPACT ANALYSIS
- Each fee and its APR impact in basis points
- Break-even point for paying points (if applicable): Month X (Year X)
- Fee as % of loan amount: X%

## LOAN COMPARISON TABLE
If comparing 3 loan offers, show which has lowest true cost.

## SHOULD YOU PAY POINTS?
Based on the break-even calculation and typical holding period.

Show all APR calculations to 3 decimal places.`
  },
  {
    id: 'retirement-calculator',
    cat: 'finance',
    ico: '🎯',
    name: 'Retirement Calculator',
    short: '401k, IRA & Pension Planning',
    tagline: 'Retirement calculator — how much you need, how long it lasts, when you can retire',
    desc: 'Calculate exactly how much you need to retire comfortably, when you can retire, and whether your current savings rate is on track. Includes Social Security estimation, inflation adjustment, and 4% safe withdrawal rule analysis.',
    metaTitle: 'Retirement Calculator Free — 401k, IRA Savings & When Can I Retire',
    metaDesc: 'Free retirement calculator. Calculate when you can retire, how much you need, and if your savings are on track. Includes Social Security, inflation, and safe withdrawal rate.',
    keyword: 'retirement calculator how much do I need',
    color: '#4a2d8b',
    styles: ['Retirement Readiness Check', 'When Can I Retire?', '401(k) / IRA Projection', 'Safe Withdrawal Rate', 'Social Security Optimization'],
    sources: [],
    inputLabel: 'Retirement Details',
    inputPlaceholder: 'Enter your details. Example: Age 42, retire at 65, current savings $180,000, saving $1,500/month (401k + IRA), expected 7% return, need $80,000/year in retirement (today\'s dollars), Social Security estimate $2,200/month.',
    relatedTools: ['compound-interest-calculator', 'loan-calculator', 'apr-calculator', 'debt-consolidation-calculator'],
    faqs: [
      { q: 'How much money do I need to retire?', a: 'The most widely used rule: multiply your desired annual retirement income by 25 (the "25x rule," derived from the 4% safe withdrawal rate). If you need $60,000/year: $60,000 × 25 = $1,500,000. Subtract expected Social Security and pension income first. If Social Security pays $24,000/year, you only need $36,000/year from savings: $36,000 × 25 = $900,000.' },
      { q: 'What is the 4% safe withdrawal rule?', a: 'The "4% rule" (from the 1994 Trinity Study) states you can withdraw 4% of your portfolio in year 1, then adjust for inflation each year, and have a 95%+ probability of not running out of money over 30 years. Based on S&P 500 historical data. Some planners now recommend 3.3–3.5% for longer retirements (35+ years) or lower expected returns. This calculator models multiple scenarios.' },
      { q: 'Is it better to max out 401k or Roth IRA first?', a: 'Step 1: Contribute to 401k up to employer match (free money — always do this first). Step 2: Max out Roth IRA ($7,000/year in 2026, $8,000 if 50+) — tax-free growth. Step 3: Return to max 401k ($23,000/year in 2026, $30,500 if 50+) — tax deduction now. High earners above Roth income limits ($161,000 single / $240,000 married) should do backdoor Roth conversion instead.' },
    ],
    prompt: `You are a precise retirement planning calculator. Analyze the retirement scenario below.

Analysis type: {style}
Details: {input}

Extract: current age, retirement age, current savings, monthly contribution, expected annual return (%), desired annual income in retirement, Social Security estimate (if given), and inflation assumption.

Calculate and show ALL of the following:

## RETIREMENT SNAPSHOT
- Current Age: X | Retirement Age: X | Years to Retire: X
- Current Savings: $X
- Monthly Contributions: $X/month
- Expected Annual Return: X% (X% real after inflation)

## THE NUMBER: HOW MUCH YOU NEED
- Desired Annual Income: $X (today's dollars)
- Inflation-Adjusted Annual Income at Retirement: $X
- Social Security Estimate: $X/year
- Income Gap (needed from savings): $X/year
- **Target Retirement Nest Egg (25x rule): $X**
- **Conservative Target (30x rule, 3.33%): $X**

## PROJECTED BALANCE AT RETIREMENT
- Projected Balance at Age X: **$X**
- Gap vs Target: $X [ON TRACK ✓ / SHORTFALL ✗]

## SAVINGS RATE ANALYSIS
- Current monthly savings needed to hit target: $X/month
- Are you saving enough? YES/NO
- If shortfall: need $X/month more, or retire X years later

## RETIREMENT INCOME PROJECTION
At retirement, monthly income breakdown:
| Source | Monthly | Annual |
| Portfolio (4% rule) | $X | $X |
| Social Security | $X | $X |
| **Total** | **$X** | **$X** |
- Portfolio lasts until age: X (worst case) / X (average)

## YEAR-BY-YEAR SAVINGS PROJECTION
Show every 5 years from now to retirement.

## SCENARIOS
- If you retire 5 years earlier (age X): Nest egg = $X, monthly income = $X
- If you retire 5 years later (age X): Nest egg = $X, monthly income = $X
- If return is 2% lower (X%): Nest egg = $X

Be precise. Include inflation at 3% unless specified otherwise.`
  },
];

module.exports = TOOLS;
