// ProScholersTools — Open API Proxy (Testing Mode)
// All users get free unlimited access via owner's API key
// Switch to rate-limited version when ready to monetize

const MAX_INPUT_CHARS = 4000;
const MAX_TOKENS      = 1200;
const MODEL           = 'claude-haiku-4-5-20251001';

exports.handler = async (event) => {

  const origin  = event.headers['origin'] || '';
  const allowed = ['proscholerstools.com', 'localhost', '127.0.0.1', '.netlify.app'];
  const isAllowed = allowed.some(d => origin.includes(d));

  const cors = {
    'Access-Control-Allow-Origin'      : isAllowed ? origin : 'https://proscholerstools.com',
    'Access-Control-Allow-Headers'     : 'Content-Type',
    'Access-Control-Allow-Methods'     : 'POST, OPTIONS',
    'Access-Control-Allow-Credentials' : 'true',
    'Content-Type'                     : 'application/json',
  };

  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers: cors, body: '' };
  if (event.httpMethod !== 'POST')   return { statusCode: 405, headers: cors, body: JSON.stringify({ error: 'Method not allowed' }) };
  if (!isAllowed)                    return { statusCode: 403, headers: cors, body: JSON.stringify({ error: 'Forbidden' }) };

  let body;
  try { body = JSON.parse(event.body || '{}'); }
  catch { return { statusCode: 400, headers: cors, body: JSON.stringify({ error: 'Invalid JSON' }) }; }

  const { messages } = body;

  if (!Array.isArray(messages) || !messages.length) {
    return { statusCode: 400, headers: cors, body: JSON.stringify({ error: 'Missing messages' }) };
  }
  if (messages.length > 6) {
    return { statusCode: 400, headers: cors, body: JSON.stringify({ error: 'Too many messages.' }) };
  }
  for (const m of messages) {
    if (typeof m?.content !== 'string' || !['user', 'assistant'].includes(m?.role)) {
      return { statusCode: 400, headers: cors, body: JSON.stringify({ error: 'Invalid message format.' }) };
    }
  }

  const inputText = messages.map(m => m.content).join('');
  if (inputText.length > MAX_INPUT_CHARS) {
    return { statusCode: 400, headers: cors, body: JSON.stringify({ error: `Input too long (max ${MAX_INPUT_CHARS} characters).` }) };
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return { statusCode: 500, headers: cors, body: JSON.stringify({ error: 'Service temporarily unavailable.' }) };

  try {
    const resp = await fetch('https://api.anthropic.com/v1/messages', {
      method : 'POST',
      headers: {
        'Content-Type'      : 'application/json',
        'x-api-key'         : apiKey,
        'anthropic-version' : '2023-06-01',
      },
      body: JSON.stringify({ model: MODEL, max_tokens: MAX_TOKENS, messages }),
    });

    const data = await resp.json();

    if (!resp.ok) {
      return { statusCode: resp.status, headers: cors, body: JSON.stringify({ error: 'Service error. Please try again.' }) };
    }

    return {
      statusCode: 200,
      headers: cors,
      body: JSON.stringify({
        content: data.content,
        _meta: { model: MODEL, tier: 'free' }
      })
    };

  } catch (err) {
    return { statusCode: 500, headers: cors, body: JSON.stringify({ error: 'Server error. Please try again.' }) };
  }
};
