#!/usr/bin/env node
// generate.js — ProScholersTools v4 FINAL
// Fixes: rich content, breadcrumb schema, clean URLs, Anthropic attribution,
//        AdSense-compliant 300w+ per page, duplicate content prevention

const fs   = require('fs');
const path = require('path');
const TOOLS = require('./tools-data.js');
const { SITE, buildHeader, buildNav, buildFooter, SHARED_JS } = require('./shared.js');

const OUT = path.join(__dirname, '../public');
fs.mkdirSync(OUT, { recursive: true });
fs.mkdirSync(path.join(OUT, 'blog'), { recursive: true });

const CAT_LABEL = {
  citation:'Citations', research:'Research',
  writing:'Writing', legal:'Legal', teacher:'Teachers', finance:'Finance'
};

// SEO helpers — prevent Google truncation
const truncTitle = s => s && s.length > 65 ? s.substring(0, 62) + '…' : (s || '');
const truncDesc  = s => s && s.length > 155 ? s.substring(0, 152) + '…' : (s || '');

// Rich educational content per tool (300+ unique words each for AdSense/SEO)
const TOOL_CONTENT = {
  'chicago-citation-generator': {
    intro: 'The Chicago citation style, now in its 17th edition, is one of the oldest and most comprehensive citation systems in academic publishing. Used primarily in history, literature, arts, and humanities, it offers two distinct formats: the Notes-Bibliography (NB) system favored by humanities scholars, and the Author-Date (AD) system used in the sciences and social sciences.',
    howto: [
      ['Select your source type', 'Choose from book, journal article, website, newspaper, or other source types using the selector above.'],
      ['Enter source details', 'Fill in the author name, title, publication year, publisher, and other relevant information.'],
      ['Choose your format', 'Select Notes-Bibliography for footnotes/endnotes, or Author-Date for in-text parenthetical citations.'],
      ['Copy your citation', 'Our AI formats your citation according to Chicago 17th Edition rules and you can copy it instantly.'],
    ],
    tips: 'Chicago NB uses full citations in footnotes with shortened subsequent references. Chicago AD uses (Author Year, page) in-text. Never mix both in one paper. Always include a bibliography or reference list regardless of which system you use.',
    when: 'Chicago style is required in most history courses, many humanities disciplines, and publications like the Chicago Manual of Style journals. Always confirm with your instructor which system (NB or AD) is required.'
  },
  'apa-citation-generator': {
    intro: 'APA (American Psychological Association) style, currently in its 7th edition (2019), is the dominant citation format in psychology, education, social sciences, nursing, and business. Known for its emphasis on publication dates — reflecting the importance of recency in scientific research — APA uses an Author-Date in-text citation system paired with a References list.',
    howto: [
      ['Select your source type', 'Choose from journal article, book, website, report, or other sources from the dropdown menu.'],
      ['Enter author and date', 'APA requires last name and initials for all authors, plus the exact publication year.'],
      ['Add title and source', 'For journals, include volume, issue, and DOI. For books, include publisher location and name.'],
      ['Generate and verify', 'Our AI applies APA 7th edition rules including the removal of publisher location (new in 7th edition).'],
    ],
    tips: 'APA 7th edition removed the publisher location requirement for books. For journal articles, always include the DOI when available. Use "https://doi.org/" format, not "doi:". For websites, include the retrieval date only if content changes regularly.',
    when: 'APA is required in most psychology, education, and social science courses. If your paper deals with empirical research, experiments, or data, APA is almost certainly the correct style.'
  },
  'mla-citation-generator': {
    intro: 'MLA (Modern Language Association) style, in its 9th edition (2021), is the standard citation format for English literature, languages, cultural studies, and many humanities disciplines. Its defining feature is the "container" system — a flexible framework that describes sources as objects within larger containers (a chapter within a book, an article within a journal).',
    howto: [
      ['Identify your source type', 'Is your source a standalone work or part of a larger container? This determines MLA structure.'],
      ['Enter core elements', 'Author, title, container title, contributor roles, version, number, publisher, date, and location.'],
      ['Check for second containers', 'If your source appears on a database (like JSTOR), that database is a second container.'],
      ['Add to Works Cited', 'MLA uses a "Works Cited" page (not "Bibliography" or "References") with hanging indent format.'],
    ],
    tips: 'MLA 9th edition introduced optional "in-text" elements to help readers identify sources. The format is: Author Last, First. "Article Title." Journal Name, vol. X, no. X, Year, pp. XX–XX. For websites, include the URL at the end preceded by a comma.',
    when: 'MLA is standard in English literature, foreign language, and cultural studies courses. It is also used in many high school and undergraduate writing courses as a general introduction to academic citation.'
  },
  // ── CITATION ──────────────────────────────────────────────────────────
  'footnote-formatter': {
    intro: 'Footnotes and endnotes are the backbone of Chicago and Turabian citation styles. Unlike in-text parenthetical systems, footnotes allow authors to provide full source details without interrupting the flow of the main text. The Chicago 17th Edition distinguishes between first citations (full) and subsequent citations (shortened), while Bluebook — used in legal writing — follows its own distinct formatting conventions.',
    howto: [
      ['Choose your citation style', 'Select Chicago 17th NB, MLA 9th, Turabian 9th, or Bluebook 21st from the style buttons above.'],
      ['Enter the source details', 'Include author name, title, publication year, publisher, and page number. For journal articles, add volume, issue, and DOI.'],
      ['Specify first or subsequent citation', 'Tell the tool whether this is the first time you are citing this source or a shortened subsequent reference.'],
      ['Copy the formatted footnote', 'The AI generates the complete footnote text. Paste it directly into your word processor footnote field.'],
    ],
    tips: 'In Chicago NB, the first footnote gives the full citation. Later references to the same source use a shortened form: Lastname, Shortened Title, page. Use "Ibid." only when the source is identical to the immediately preceding footnote. Ibid with a different page: "Ibid., 47."',
    when: 'Use this tool whenever you write history papers, humanities essays, or legal documents requiring footnoted citations. Chicago NB is standard in history departments; Turabian is common in undergraduate research papers; Bluebook is essential for all American legal writing.',
  },
  'bibliography-builder': {
    intro: 'A bibliography is more than a list of sources — it is a scholarly record that allows readers to verify your research and trace your intellectual lineage. Chicago bibliographies, APA reference lists, and MLA Works Cited pages each follow distinct formatting rules for author order, punctuation, indentation, and capitalization. Even minor formatting errors signal carelessness to academic reviewers.',
    howto: [
      ['Select your citation style', 'Choose Chicago 17th, APA 7th, or MLA 9th. Each produces a differently formatted entry.'],
      ['Enter all source details', 'Include every author, full title, publication year, volume, issue, pages, publisher, and DOI or URL as applicable.'],
      ['Add multiple sources', 'Generate entries one at a time, then compile them in alphabetical order by author surname for your final bibliography.'],
      ['Apply hanging indent formatting', 'In your word processor, select all bibliography entries and apply a 0.5-inch hanging indent (second line indented).'],
    ],
    tips: 'APA 7th removed the publisher location requirement for books. Chicago bibliography entries list author Last, First — the opposite of footnote order. MLA uses a "Works Cited" heading, not "Bibliography." All three styles require entries sorted alphabetically by the first author\'s last name.',
    when: 'Required at the end of every academic paper. Start building your bibliography as you research — it is much harder to reconstruct source details after writing is complete.',
  },

  // ── RESEARCH ──────────────────────────────────────────────────────────
  'thesis-statement-generator': {
    intro: 'A thesis statement is the single most important sentence in an academic essay. It announces your argument, previews your supporting points, and sets the analytical standard for everything that follows. A weak thesis — too vague, too obvious, or merely descriptive — undermines even well-researched papers. A strong thesis is specific, arguable, and structurally revealing.',
    howto: [
      ['Choose your essay type', 'Select Argumentative, Analytical, Expository, or Comparative to match your assignment type.'],
      ['Describe your topic and position', 'Enter your subject, your main claim, and the key reasons or evidence that support it.'],
      ['Review and refine', 'The AI generates 2-3 thesis options at different levels of specificity. Choose the most precise one.'],
      ['Test with the "so what" question', 'Ask: could a reasonable person disagree with this statement? If no, it needs to be more arguable.'],
    ],
    tips: 'Write your thesis last, not first. Draft the body of your paper, then return and write a thesis that precisely matches what you actually argued. Most students write a preliminary thesis, discover a more nuanced argument while writing, then forget to revise the thesis.',
    when: 'Use at the start of any essay writing process to clarify your argument, and again after drafting to ensure your thesis matches what you proved.',
  },
  'research-question-generator': {
    intro: 'A well-formed research question is the foundation of rigorous academic inquiry. It must be neither too broad (impossible to answer in a single study) nor too narrow (trivial or already answered). Quantitative research questions ask "how much" or "to what extent," while qualitative questions ask "how" or "why." Mixed-methods questions combine both approaches.',
    howto: [
      ['Identify your topic and gap', 'Enter your general subject area and what aspect you want to investigate.'],
      ['Select question type', 'Choose Qualitative, Quantitative, Mixed Methods, or Exploratory based on your research design.'],
      ['Specify your context', 'Include population, time period, geography, or other relevant boundaries for your study.'],
      ['Evaluate the generated questions', 'Review the questions for feasibility — can you realistically answer this with available data and resources?'],
    ],
    tips: 'A good research question passes the FINER test: Feasible, Interesting, Novel, Ethical, and Relevant. Avoid questions answerable with "yes" or "no." The question should point directly to your methodology — a "why" question implies qualitative methods; a "how much" question implies quantitative.',
    when: 'Essential at the very start of any dissertation, thesis, or research paper. Your research question determines your methodology, literature review scope, and data collection approach.',
  },
  'literature-review-writer': {
    intro: 'A literature review synthesizes existing scholarship to establish the intellectual context for your research. It is not a summary of individual papers read in sequence — it is a thematic analysis that demonstrates mastery of a field, identifies contradictions and gaps, and justifies why your study is needed. Examiners evaluate literature reviews as evidence of your scholarly judgment.',
    howto: [
      ['Enter your research topic and question', 'Provide your specific research question and the key themes or variables you are reviewing.'],
      ['Specify scope and time period', 'State how many years of literature to cover and whether to include grey literature or peer-reviewed sources only.'],
      ['Select your organizational approach', 'Choose Thematic Synthesis, Chronological, Methodological, or Theoretical framework organization.'],
      ['Review and expand each section', 'Use the generated structure as a scaffold — add your specific sources, findings, and critical analysis.'],
    ],
    tips: 'Organize by theme, not by paper. The most common literature review mistake is writing "Smith (2019) found X. Jones (2020) found Y" — this is annotation, not synthesis. Strong synthesis writes: "Research consistently demonstrates X (Smith 2019; Jones 2020), though this finding is contested in low-income contexts (Brown 2021)."',
    when: 'Required in every dissertation, thesis chapter, and journal article. Also used in systematic reviews, grant applications, and capstone projects.',
  },
  'abstract-generator': {
    intro: 'An abstract is a standalone summary of your entire research paper, written after the full paper is complete. Despite appearing first, it is the last thing you write. For most academic papers, it runs 150-250 words. For dissertations and conference submissions, 300-500 words is common. Different disciplines follow different abstract conventions — IMRAD (Introduction, Methods, Results, Discussion) dominates the sciences; structured abstracts are standard in medicine.',
    howto: [
      ['Complete your paper first', 'Never write an abstract before finishing the paper — the abstract summarizes what you actually found, not what you planned to find.'],
      ['Enter your paper\'s key components', 'Provide: research question, methodology, key findings, and main conclusion or recommendation.'],
      ['Select your format', 'Choose IMRAD (sciences), Structured (medical journals), Informative (general academic), or Descriptive (humanities).'],
      ['Check word count and keywords', 'Most journals specify exact word limits. Add 4-6 keywords below your abstract for database indexing.'],
    ],
    tips: 'Write the abstract in the same tense as the paper — past tense for completed studies ("This study examined..."), present tense for findings that remain true ("Results indicate..."). Never cite references in an abstract. The abstract must make sense as a completely standalone document.',
    when: 'Required for journal article submissions, dissertation chapters, conference paper submissions, and graduate thesis proposals.',
  },
  'research-proposal-builder': {
    intro: 'A research proposal is a formal document that argues for the value and feasibility of a planned study. It convinces supervisors, ethics boards, or funding committees that your research question is significant, your methodology is sound, and you have the capacity to complete the work. PhD proposals and grant applications follow more rigorous formats than undergraduate proposals.',
    howto: [
      ['Select your proposal type', 'Choose PhD Dissertation Proposal, Masters Proposal, Grant Application, or Undergraduate Research Proposal.'],
      ['Enter your research question and rationale', 'Explain what you want to study and why it matters — the "so what" that justifies funding or approval.'],
      ['Describe your methodology', 'Specify your research design, data sources, analysis approach, and timeline.'],
      ['Review the generated structure', 'The AI provides a full proposal framework. Expand each section with your specific details, citations, and expertise.'],
    ],
    tips: 'The literature review section of a proposal is not a full literature review — it is a strategic demonstration that you know the field and have identified a genuine gap. Budget sections should itemize every cost; reviewers reject proposals with vague or unrealistic budgets.',
    when: 'Required when applying to PhD programs, seeking research funding, seeking ethics approval, or beginning supervised independent research.',
  },
  'dissertation-chapter-planner': {
    intro: 'A dissertation or thesis is typically the longest and most complex document an academic will ever write. The standard five-chapter structure (Introduction, Literature Review, Methodology, Results, Discussion/Conclusion) provides a proven framework, but different disciplines and institutions have variations. Planning chapters before writing prevents the most common dissertation failure: structural incoherence between chapters.',
    howto: [
      ['Select your discipline type', 'Choose STEM Dissertation, Humanities Dissertation, Social Sciences, or Professional Doctorate to match your field conventions.'],
      ['Enter your research question and scope', 'The chapter plan must be built around your specific research question — vague inputs produce generic plans.'],
      ['Specify total word count and timeline', 'Enter your target word count (50,000–100,000 words typical) and completion deadline.'],
      ['Use the plan as a writing contract', 'Assign word count targets and deadlines to each chapter. Share with your supervisor for accountability.'],
    ],
    tips: 'Write Chapter 3 (Methodology) before Chapter 2 (Literature Review). Once you know exactly what you are studying and how, the literature review scope becomes clear. Many students write literature reviews that are too broad because they haven\'t solidified their methodology.',
    when: 'Use at the start of dissertation planning, after your proposal is approved, and whenever you feel lost or overwhelmed by the scope of the project.',
  },
  'critical-analysis-tool': {
    intro: 'Critical analysis is the ability to evaluate the quality, validity, and significance of an argument or text — not just to describe it. In academic writing, critical analysis means examining an author\'s assumptions, evaluating their evidence, identifying logical gaps, and situating their claims within broader scholarly debates. This skill distinguishes advanced academic work from mere summarization.',
    howto: [
      ['Select what you are analyzing', 'Choose Academic Text, Policy Document, News Article, Creative Work, or Research Study.'],
      ['Paste or describe the text', 'Provide the passage, argument, or content you want to analyze critically.'],
      ['Choose your analytical framework', 'Select from Rhetorical Analysis, Argument Mapping, SWOT, Theoretical Lens, or General Critical Analysis.'],
      ['Apply the output to your writing', 'Use the analysis as the basis for a critical paragraph or section in your paper — always integrate your own scholarly voice.'],
    ],
    tips: 'Critical does not mean negative. To critically analyze is to evaluate rigorously — which may result in praise, critique, or a nuanced combination. The strongest critical analyses identify both the strengths and limitations of an argument with specific textual evidence.',
    when: 'Use for essay writing, research paper literature reviews, book review assignments, policy briefs, and any task requiring evaluative rather than descriptive engagement with sources.',
  },
  'research-summary-generator': {
    intro: 'A research summary distills the essential findings and significance of a study into a shorter, accessible form. Unlike an abstract (which precedes a paper), a research summary is often written for a different audience — policymakers, executives, or lay readers — and may simplify technical language. Executive summaries, policy briefs, and research digests are all forms of research summaries.',
    howto: [
      ['Select your target audience', 'Choose Academic Summary, Executive Summary, Policy Brief, or Lay Summary based on who will read it.'],
      ['Enter the research details', 'Provide the study\'s question, methodology, key findings, and implications. Paste an abstract if available.'],
      ['Set length target', 'Specify your target word count — executive summaries are typically 200-500 words; academic summaries can be longer.'],
      ['Adjust technical language level', 'For non-specialist audiences, the AI will replace jargon with plain language while preserving accuracy.'],
    ],
    tips: 'The "so what" is the most important part of any research summary. Readers want to know what this means for their field, policy, or practice — not just what was found. Always state the practical or theoretical implications of the findings.',
    when: 'Required for grant reporting, conference posters, research dissemination, policy briefs, and end-of-project documentation.',
  },

  // ── WRITING ───────────────────────────────────────────────────────────
  'academic-paraphrasing': {
    intro: 'Academic paraphrasing is the skill of rewriting source material in your own words while preserving the original meaning. It is not simply replacing words with synonyms — true paraphrasing involves restructuring sentences, changing grammatical forms, and integrating the idea naturally into your own argument. Proper paraphrasing followed by a citation demonstrates both understanding and academic integrity.',
    howto: [
      ['Paste the original text', 'Enter the passage you want to paraphrase. Keep it to 50-300 words for best results.'],
      ['Select formality level', 'Choose Formal Academic, Simplified, or Discipline-Specific to match your target document.'],
      ['Review for accuracy', 'Compare the paraphrase to the original — the meaning must be identical even though the words differ.'],
      ['Add your citation', 'Even paraphrased content requires a full citation. Use our citation generators to format it correctly.'],
    ],
    tips: 'Read the original, close the document, then write the paraphrase from memory. This forces genuine rewriting rather than synonym substitution. If you find yourself looking at the original while writing, you will likely produce text that is too close to the source.',
    when: 'Use whenever you want to incorporate source material into your academic writing. Paraphrasing is generally preferred over direct quotation in academic writing because it demonstrates comprehension.',
  },
  'plagiarism-rewriter': {
    intro: 'Academic integrity requires that all writing be original — meaning ideas from sources must be properly cited and substantially rewritten in your own voice. Text that too closely mirrors a source, even with citation, can constitute poor academic practice. This tool helps you restructure flagged passages to ensure your writing is authentically original while preserving the scholarly content.',
    howto: [
      ['Paste the flagged text', 'Enter the passage that has been flagged by your institution or writing tool for similarity.'],
      ['Choose rewrite intensity', 'Select Heavy Restructure (completely different structure) or Moderate Rewrite (same structure, new wording).'],
      ['Review the result carefully', 'Ensure the rewritten version accurately preserves the original meaning — the goal is originality, not distortion.'],
      ['Verify with a citation', 'If the idea originated from a source, the rewritten version still requires a proper citation.'],
    ],
    tips: 'Plagiarism detection tools flag surface similarity, not idea theft. Rewriting to avoid detection while maintaining the same argument structure without citation is still plagiarism. The solution is always to genuinely understand and then restate the idea in your own scholarly voice.',
    when: 'Use when revision feedback flags passages as too similar to sources, or as a check before submission to ensure your writing is authentically original.',
  },
  'academic-email-writer': {
    intro: 'Academic email has its own register and conventions. Emails to professors, supervisors, department chairs, and academic administrators require a formal tone, clear subject lines, concise structure, and appropriate professional distance. An email asking for an extension, requesting a recommendation letter, or addressing a grade dispute must balance assertiveness with respect and clarity with brevity.',
    howto: [
      ['Select your email type', 'Choose from Email to Professor, Extension Request, Recommendation Request, Grade Appeal, or Research Inquiry.'],
      ['Describe your situation clearly', 'Enter the specific circumstances, what you are requesting, and any relevant context.'],
      ['Specify your relationship', 'Indicate whether this is a first email to someone you don\'t know, or communication with an established supervisor.'],
      ['Review tone before sending', 'Read the email aloud — it should sound professional but not stiff, polite but not obsequious.'],
    ],
    tips: 'Subject lines should be specific: "Extension Request — PSY 301 Literature Review (Due Nov 15)" is far better than "Question." Professors receive dozens of emails daily. The faster they can identify what you need and whether they can help, the more likely you are to get a response.',
    when: 'Use for any formal academic correspondence — extension requests, office hour appointments, research inquiries, recommendation letter requests, and appeals.',
  },
  'essay-outline-generator': {
    intro: 'A well-structured outline is the single most effective investment of time in the essay writing process. It prevents the most common writing problems: repetition, poor argument flow, weak transitions, and missing counterarguments. Different essay types require different structural templates — argumentative essays follow a thesis-body-counterargument-conclusion pattern, while analytical essays may use a compare-contrast or point-by-point structure.',
    howto: [
      ['Select your essay type', 'Choose Argumentative, Analytical, Comparative, Expository, Persuasive, or Reflective Essay.'],
      ['Enter your thesis or topic', 'Provide your thesis statement (if you have one) and the main points you want to cover.'],
      ['Specify word count and sections', 'Enter your target length and how many body paragraphs or sections you need.'],
      ['Expand each section', 'The AI generates a hierarchical outline with main points, sub-points, and evidence slots. Fill in your specific sources and examples.'],
    ],
    tips: 'Build your outline before you research, not after. An early outline identifies exactly which evidence you need to find, making your research more targeted and efficient. Revise the outline again after research, before you start writing.',
    when: 'Use at the beginning of any essay or paper, especially for assignments over 1,000 words where structural coherence is essential.',
  },
  'academic-vocabulary-enhancer': {
    intro: 'Academic writing demands precise, formal vocabulary that demonstrates disciplinary fluency. Common informal expressions ("a lot of," "things," "very important") weaken the scholarly register of your writing. Academic vocabulary enhancement replaces imprecise language with specific, field-appropriate terminology while preserving the clarity and authenticity of your voice.',
    howto: [
      ['Paste your text', 'Enter the paragraph or section you want to enhance. Works best with 50-400 word passages.'],
      ['Select your discipline', 'Choose General Academic, Sciences & STEM, Humanities, Social Sciences, Law, or Business to get field-appropriate vocabulary.'],
      ['Review each substitution', 'Do not accept every suggestion automatically — academic vocabulary should be precise, not merely impressive-sounding.'],
      ['Read the enhanced text aloud', 'If a sentence sounds unnatural or obscure, revert to simpler language. Clarity always wins over complexity.'],
    ],
    tips: 'The best academic vocabulary is the most precise word for the concept — not the longest or most obscure. "Demonstrates" beats "showcases." "Significant" beats "huge." "Methodology" is correct; "methodology-wise" is not. When in doubt, prefer the specific term from your discipline\'s literature.',
    when: 'Use when polishing a draft before submission, when feedback identifies "informal language," or when preparing writing for journal submission.',
  },
  'peer-review-assistant': {
    intro: 'Peer review is the quality control mechanism of academic publishing. Reviewers evaluate manuscripts for originality, methodological rigor, clarity, and contribution to the field. Writing a strong peer review requires systematic evaluation of each component — research question, literature review, methodology, results presentation, and discussion — with constructive, specific feedback rather than vague criticism.',
    howto: [
      ['Select the review type', 'Choose Double-Blind Review (you don\'t know the author), Open Review, Formative Feedback (for class assignments), or Research Critique.'],
      ['Enter the manuscript details', 'Paste the abstract or key sections, or describe the paper\'s research question, methods, and main claims.'],
      ['Identify specific concerns', 'Note any methodology issues, unsupported claims, or gaps you have spotted — the AI will help articulate them constructively.'],
      ['Review the generated feedback', 'Peer review language must be professional and constructive — the goal is to improve the work, not attack the author.'],
    ],
    tips: 'Effective peer review is specific: "The sample size of 45 may be insufficient for the subgroup analysis in Table 3, which could affect the reliability of finding X" is actionable. "The methodology is weak" is not. Always distinguish between major concerns (that affect the paper\'s validity) and minor suggestions (stylistic or organizational improvements).',
    when: 'Use when serving as a formal journal reviewer, completing peer review assignments for class, or providing structured feedback on a colleague\'s draft.',
  },

  // ── LEGAL ─────────────────────────────────────────────────────────────
  'legal-case-brief': {
    intro: 'A legal case brief is a structured summary of a court decision that extracts the essential legal elements: the facts, the legal issue, the rule applied, the court\'s reasoning, and its holding. Case briefing is the foundational skill of legal education — the Socratic classroom depends on it. A well-constructed brief allows a student to reconstruct the case\'s legal significance from memory without re-reading the full opinion.',
    howto: [
      ['Select your briefing format', 'Choose IRAC (Issue, Rule, Application, Conclusion), CREAC, FIRAC, or the traditional Case Brief format.'],
      ['Enter case name and citation', 'Provide the case name, court, year, and official citation (e.g., 347 U.S. 483 (1954)).'],
      ['Describe the key facts and holding', 'Enter the material facts that the court relied on, the legal question presented, and the court\'s decision.'],
      ['Review for legal accuracy', 'Cross-reference the brief against the full opinion — AI-generated briefs should always be verified against the primary source.'],
    ],
    tips: 'The "Issue" should be stated as a specific legal question, not a general topic. Not "whether discrimination occurred" but "whether the Equal Protection Clause of the Fourteenth Amendment prohibits racially segregated public schools." The more precisely you state the issue, the more useful the brief.',
    when: 'Essential for law school classes, bar exam preparation, legal research, and any professional legal work requiring analysis of precedent.',
  },
  'legal-case-analyzer': {
    intro: 'Legal case analysis moves beyond summarizing a court\'s holding to evaluating its reasoning, identifying its precedential scope, and situating it within the broader doctrine. Advanced legal analysis asks: Was the reasoning sound? How broadly or narrowly will lower courts interpret this holding? Does it conflict with existing precedent? What policy considerations drove the outcome?',
    howto: [
      ['Select your area of law', 'Choose Constitutional Law, Contract Law, Tort Law, Criminal Law, Administrative Law, or International Law.'],
      ['Enter the case details', 'Provide the case name, parties, facts, holding, and the specific legal question you want to analyze.'],
      ['Specify your analytical goal', 'Are you analyzing for a memo, a brief, class preparation, or appellate strategy? The goal shapes the analysis.'],
      ['Identify counterarguments', 'The best legal analysis anticipates the strongest objections to the court\'s reasoning — include these in your work.'],
    ],
    tips: 'Distinguish the holding (the specific rule announced for these facts) from dicta (observations the court made but didn\'t need to reach its decision). Only the holding is binding precedent. Dicta can be persuasive but is not authoritative.',
    when: 'Use for moot court preparation, appellate brief writing, legal research memoranda, and law review article development.',
  },
  'legal-memorandum-writer': {
    intro: 'A legal memorandum is a formal legal document used to analyze a legal issue and advise a client or colleague. Office memoranda predict how a court would likely rule ("predictive writing") and present both sides of the issue objectively. Demand letters and client letters are persuasive documents that advocate for a position. All legal memos require precise citation, logical structure, and careful hedging of uncertain legal conclusions.',
    howto: [
      ['Select memo type', 'Choose Office Legal Memo (predictive), Demand Letter, Client Advisory Letter, or Interoffice Research Memo.'],
      ['Enter the legal question and facts', 'State the specific legal issue and provide all material facts — omitting facts relevant to the analysis weakens the memo.'],
      ['Specify the jurisdiction', 'Law varies by jurisdiction. Note whether you need federal, state, or international law analysis.'],
      ['Review citations carefully', 'AI-generated legal citations must be verified against official reporters before any professional use.'],
    ],
    tips: 'The BLUF (Bottom Line Up Front) principle applies to legal memos: state your conclusion in the first paragraph, then provide the analysis that supports it. Busy attorneys read the conclusion first — if they need more detail, they read further. Never bury the bottom line.',
    when: 'Use for law school memo assignments, professional legal research, client communication templates, and bar exam practice.',
  },
  'case-study-analyzer': {
    intro: 'Case study analysis applies theoretical frameworks to real-world scenarios to extract generalizable lessons. Business case studies use frameworks like Porter\'s Five Forces, SWOT, or McKinsey\'s 7S. Legal case studies use IRAC or comparative precedent analysis. The goal is not merely to describe what happened but to diagnose why, what principles apply, and what decisions should follow.',
    howto: [
      ['Select your case study type', 'Choose Business Strategy, Legal, Medical/Clinical, Educational, or Policy case study analysis.'],
      ['Enter the case scenario', 'Describe the situation, the key decision points, the stakeholders involved, and the outcome (if known).'],
      ['Choose your analytical framework', 'Select SWOT, PESTLE, Porter\'s Five Forces, IRAC, Cost-Benefit, or Root Cause Analysis.'],
      ['Generate recommendations', 'The analysis should conclude with actionable, evidence-based recommendations tied directly to the findings.'],
    ],
    tips: 'The weakest case study analyses describe the situation thoroughly but produce generic recommendations ("the company should improve communication"). Strong analysis ties each recommendation to a specific finding: "Because the 2023 supply chain disruption exposed single-supplier dependency in three product categories, management should immediately begin dual-sourcing for those categories."',
    when: 'Use for MBA coursework, business school applications, professional training, legal education, and policy analysis.',
  },

  // ── TEACHER ───────────────────────────────────────────────────────────
  'lesson-plan-generator': {
    intro: 'An effective lesson plan is a structured teaching roadmap that specifies learning objectives, instructional activities, assessment strategies, and time allocations for a single class session. Well-designed lesson plans align objectives with assessments (backward design), differentiate instruction for diverse learners, and include both content goals and skill development targets. Different grade levels and subjects require different planning formats.',
    howto: [
      ['Select grade level and subject', 'Choose Elementary (K-5), Middle School (6-8), High School (9-12), or Higher Education, and your subject area.'],
      ['Enter your learning objectives', 'State what students will be able to DO by the end of the lesson — use active verbs (analyze, evaluate, construct, compare).'],
      ['Specify time and resources', 'Enter your class period length and available materials or technology.'],
      ['Customize for your students', 'Add any information about student needs, prior knowledge, or differentiation requirements.'],
    ],
    tips: 'Write learning objectives using Bloom\'s Taxonomy verbs — remember, understand, apply, analyze, evaluate, create. Avoid vague objectives like "students will learn about the Civil War." Precise: "Students will analyze primary source documents to identify three causes of the Civil War and evaluate their relative significance."',
    when: 'Use for daily lesson planning, curriculum design, teacher certification portfolios, instructional coaching demonstrations, and substitute teacher preparation.',
  },
  'rubric-builder': {
    intro: 'A rubric is a scoring guide that makes assessment criteria explicit, consistent, and transparent. Analytic rubrics evaluate each criterion separately on a scale (producing detailed feedback); holistic rubrics evaluate the overall performance as a whole (faster to apply). Research consistently shows that students who receive rubrics before completing assignments produce higher-quality work than those who don\'t.',
    howto: [
      ['Select rubric type', 'Choose Analytic (criteria-based) or Holistic (overall impression) based on your assessment purpose.'],
      ['Enter the assignment details', 'Describe the task, its learning objectives, and the key skills or knowledge being assessed.'],
      ['Specify performance levels', 'Choose a 4-point, 5-point, or percentage-based scale for your rubric columns.'],
      ['Review and customize descriptors', 'The AI generates performance level descriptors for each criterion. Adjust language to match your course expectations and student level.'],
    ],
    tips: 'Write rubric descriptors that describe observable behaviors, not subjective qualities. "Thesis is clearly stated in the introduction and consistently supported throughout the essay" is assessable. "Essay is excellent" is not. Share rubrics with students before they begin the assignment — this is not "giving away the answers" but communicating your expectations clearly.',
    when: 'Use for essay assignments, presentations, projects, lab reports, participation grades, or any summative assessment where consistency and transparency matter.',
  },
  'study-plan-creator': {
    intro: 'A study plan is a structured schedule that allocates specific time blocks to specific subjects or topics, incorporating evidence-based learning strategies like spaced repetition, retrieval practice, and interleaving. Research in cognitive science shows that distributed practice (studying a subject across multiple sessions over time) produces far superior retention compared to massed practice (cramming).',
    howto: [
      ['Enter your subjects and deadlines', 'List all courses, exams, or assignments with their due dates and your current understanding of each topic.'],
      ['Select your schedule type', 'Choose Weekly Schedule, 2-Week Exam Prep, Semester Overview, or Daily Planner.'],
      ['Specify your available hours', 'Enter how many hours per day you can realistically study, accounting for classes, work, and commitments.'],
      ['Apply spaced repetition', 'The AI builds in review sessions for previously studied material — do not skip these even when time is tight.'],
    ],
    tips: 'Study your hardest subject first, when your cognitive resources are freshest. Use the Pomodoro technique: 25 minutes of focused study followed by a 5-minute break. After four cycles, take a 20-minute break. Research shows this maintains attention and prevents the mental fatigue that makes long unbroken study sessions inefficient.',
    when: 'Use at the start of a semester, when facing multiple simultaneous deadlines, during exam periods, or whenever you feel overwhelmed by academic workload.',
  },
  'student-feedback-generator': {
    intro: 'Effective academic feedback is specific, actionable, and growth-oriented. Research by Hattie and Timperley identifies feedback as one of the most powerful influences on student achievement — but only when it addresses what the student did, what the standard is, and what they should do next. Vague praise ("Great job!") or unspecific criticism ("Needs work") provide no learning value.',
    howto: [
      ['Select the work type', 'Choose Essay Feedback, Presentation Feedback, Lab Report, Project Assessment, or General Assignment.'],
      ['Enter the student work or description', 'Paste key excerpts or describe what the student submitted and how it performed against the rubric.'],
      ['Specify the feedback level', 'Choose Summative (final grade feedback) or Formative (feedback for revision before final submission).'],
      ['Review tone carefully', 'All feedback must be professional, constructive, and growth-focused — even for poor-quality work.'],
    ],
    tips: 'Structure feedback as: (1) What was done well and why it worked, (2) What the primary area for improvement is, (3) Specific, actionable next steps. This SBI model (Situation-Behavior-Impact) ensures students understand not just that something needs improvement but exactly how to improve it.',
    when: 'Use for grading essays, lab reports, presentations, group projects, or any assignment where written feedback is required.',
  },
  'exam-question-generator': {
    intro: 'Well-designed exam questions assess the specific learning objectives of a course at the appropriate cognitive level. Multiple-choice questions can assess recall, comprehension, and application with high reliability and efficiency. Short answer and essay questions assess higher-order thinking — analysis, evaluation, and synthesis — but require more time to grade. All good exam questions are unambiguous, appropriately difficult, and aligned to course objectives.',
    howto: [
      ['Select question type', 'Choose Multiple Choice (MCQ), Short Answer, Essay, True/False, Matching, or Mixed Format.'],
      ['Enter your topic and learning objectives', 'Specify exactly what concept, skill, or knowledge you want to assess and at what cognitive level.'],
      ['Choose difficulty level', 'Select Recall, Comprehension, Application, or Analysis/Evaluation based on Bloom\'s Taxonomy.'],
      ['Review for ambiguity', 'Read each question as a student would — could a knowledgeable student misinterpret the question? If yes, revise it.'],
    ],
    tips: 'For multiple-choice questions: all distractors (wrong answers) should be plausible to students who lack the knowledge being tested. Avoid "all of the above" and "none of the above" — they are usually either always correct or never correct, which students learn to exploit. The stem should contain the central problem; options should be brief and grammatically parallel.',
    when: 'Use for creating mid-terms, finals, quizzes, formative assessments, and question banks. Also useful for generating practice questions for student review.',
  },

  // ── FINANCE CONTENT ────────────────────────────────────────────────────
  'loan-calculator': {
    intro: 'A loan calculator helps you understand the true cost of borrowing before you sign. The monthly payment formula — P × [r(1+r)^n] / [(1+r)^n – 1] — combines your principal, interest rate, and term into a single figure. But the monthly payment alone does not tell the full story: total interest paid over the life of the loan often equals 30–60% of the original loan amount. This calculator shows you the complete picture including the full amortization schedule, so you can make an informed borrowing decision.',
    howto: [
      ['Select loan type', 'Choose Personal Loan, Auto Loan, Business Loan, Student Loan, or Home Equity Loan from the dropdown.'],
      ['Enter loan details', 'Provide loan amount ($), APR (not just the interest rate — APR includes fees), and loan term in months or years.'],
      ['Review the amortization schedule', 'See exactly how much of each payment goes to principal vs interest — in the early months, most goes to interest.'],
      ['Compare scenarios', 'Run the calculator again with a shorter term or higher payment to see how much interest you would save.'],
    ],
    tips: 'The single most effective way to reduce total loan cost is to make extra principal payments early in the loan term. On a 5-year personal loan, an extra $100/month in year 1 can save $400–$800 in interest. Always verify the APR — lenders sometimes advertise the monthly rate, which makes the loan appear cheaper. Multiply the monthly rate by 12 to get the true annualized rate.',
    when: 'Use before taking out any loan to compare offers, understand total cost, and decide between loan terms. Also useful for creating a payoff plan for an existing loan.',
  },

  'mortgage-calculator': {
    intro: 'A mortgage is typically the largest financial commitment of a lifetime, yet most buyers only compare the monthly payment — missing the property taxes, homeowners insurance, and PMI that can add $500–$1,000/month to the true cost. This calculator computes your complete PITI payment (Principal, Interest, Taxes, Insurance) plus PMI if applicable, giving you the full picture before you buy. It also shows when PMI drops off, how equity builds, and the total cost over 15 vs 30 years.',
    howto: [
      ['Enter home price and down payment', 'The down payment determines your loan amount and whether PMI applies (required if less than 20% down).'],
      ['Enter interest rate and loan term', 'Use the current rate from your lender. Compare 30-year vs 15-year — the rate difference is typically 0.5–0.75%.'],
      ['Add property tax and insurance', 'Property tax rate varies by state (0.3%–2.5% of home value). Homeowners insurance averages $1,200–$2,400/year depending on location.'],
      ['Review total monthly cost and 30-year total', 'The difference between a 6.5% and 7.5% rate on a $400,000 mortgage is over $80,000 in total interest — compare carefully.'],
    ],
    tips: 'The 28/36 rule is the standard: mortgage payment ≤ 28% of gross monthly income, total debt ≤ 36%. On a $7,000/month income, maximum mortgage payment is $1,960. PMI removal at 20% equity can save $150–$300/month — request cancellation in writing the month you hit 80% LTV, as lenders do not always remove it automatically.',
    when: 'Use before making an offer on a home, when comparing loan offers from multiple lenders, and when deciding between buying and renting. Also use when considering refinancing.',
  },

  'compound-interest-calculator': {
    intro: 'Albert Einstein reportedly called compound interest the "eighth wonder of the world." Whether or not he said it, the math is extraordinary: $10,000 invested at 8% annually becomes $21,589 in 10 years, $46,610 in 20 years, and $100,627 in 30 years — without adding a single dollar more. Add $500/month contributions and the 30-year total reaches over $745,000. This calculator models real-world investment growth with regular contributions, tax-advantaged account types, and multiple compounding frequencies.',
    howto: [
      ['Enter initial investment', 'This is your starting principal — the lump sum you invest today. Even $1,000 matters when given decades to compound.'],
      ['Set monthly contribution', 'Regular contributions matter more than initial amount over time. $0 initial + $500/month at 8% for 30 years = $745,000.'],
      ['Choose interest rate', 'For savings accounts, use the current APY. For investments, use 6–8% for a conservative stock market projection.'],
      ['Review the year-by-year table', 'Notice how growth accelerates after year 15 — this is the exponential curve of compounding working in your favor.'],
    ],
    tips: 'The most powerful lever in compound interest is time, not rate. Starting 5 years earlier has a larger impact than earning 2% higher returns. At 8%, starting at 25 vs 30 means the difference of over $230,000 by age 65. Daily vs monthly compounding makes a minor difference (~0.3% more per year) — far less important than consistent contributions.',
    when: 'Use to project savings account growth, model retirement contributions, compare investment scenarios, and demonstrate the cost of delaying investment to skeptical students or clients.',
  },

  'debt-consolidation-calculator': {
    intro: 'Debt consolidation replaces multiple high-interest debts with a single lower-interest loan — ideally reducing both monthly payments and total interest paid. But consolidation is not always the right move: if the new APR is not meaningfully lower, or if you extend the term too much, you can end up paying more. This calculator compares your current debt situation against a consolidation loan, the debt snowball method (psychological wins), and the debt avalanche method (mathematically optimal), so you can choose the right strategy for your situation.',
    howto: [
      ['List all your debts', 'Enter each debt with its balance, APR, and minimum monthly payment. Include credit cards, personal loans, auto loans, and medical debt.'],
      ['Calculate weighted average APR', 'The calculator does this automatically — this is the rate you need to beat with a consolidation loan.'],
      ['Enter consolidation loan terms', 'Input the APR and term offered by a lender. Any APR at least 3–5% lower than your weighted average typically makes consolidation worthwhile.'],
      ['Compare all three strategies', 'See snowball vs avalanche vs consolidation side-by-side with exact payoff dates and total interest for each.'],
    ],
    tips: 'The #1 mistake after debt consolidation is running up the paid-off credit cards again. Consolidation only works if you stop adding new debt. Cut up or freeze the paid-off cards after consolidation. If you cannot qualify for a consolidation loan below your current weighted APR, the debt avalanche method is mathematically superior — focus all extra money on the highest-rate debt first.',
    when: 'Use when you have multiple high-interest debts and want to find the fastest, cheapest path to becoming debt-free. Also use when evaluating a balance transfer offer or HELOC for debt consolidation.',
  },

  'apr-calculator': {
    intro: 'The advertised interest rate on a loan is almost never the true cost. Origination fees, closing costs, mortgage points, broker fees, and required insurance all add to the real cost of borrowing — and federal law (Truth in Lending Act / Regulation Z) requires lenders to disclose this as the Annual Percentage Rate (APR). This calculator reverse-engineers the true APR from any combination of loan terms and fees, so you can compare loan offers on an apples-to-apples basis and understand exactly what you are paying for.',
    howto: [
      ['Enter the stated loan terms', 'Input the loan amount, stated interest rate, and loan term exactly as shown in the lender\'s offer.'],
      ['Add all fees', 'Include origination fees (typically 1–6% of loan amount), mortgage points, closing costs, broker fees, and any required insurance.'],
      ['Compare your APR to competitors', 'Run this calculator for each loan offer you receive — the lowest APR is the cheapest loan, regardless of stated rate.'],
      ['Check the break-even on points', 'Paying points to lower the rate only makes sense if you keep the loan past the break-even date shown by this calculator.'],
    ],
    tips: 'A common lender tactic is to advertise a low rate but charge high origination fees. A 6.5% mortgage with 2 points ($6,000 on a $300,000 loan) has a higher APR than a 6.75% mortgage with no points — and costs more if you sell within 7 years. Always ask lenders for the Loan Estimate form (required by law within 3 business days) which discloses APR and all fees.',
    when: 'Use whenever comparing two or more loan offers, evaluating whether to pay mortgage points, or trying to understand the true annual cost of any borrowing product including credit cards and buy-now-pay-later.',
  },

  'retirement-calculator': {
    intro: 'Retirement planning distills to one question: "Will I have enough money to last the rest of my life?" The math involves three variables — how much you save, how long it grows, and how much you withdraw. The 4% safe withdrawal rule (from the 1994 Trinity Study) states that you can withdraw 4% of your portfolio in year 1, adjust for inflation annually, and have a 95%+ probability of not running out of money over 30 years. This means you need 25× your desired annual income in retirement. This calculator tells you exactly where you stand, when you can retire, and what needs to change if you are off track.',
    howto: [
      ['Enter your current situation', 'Provide your age, current retirement savings, and monthly contribution amount across all accounts (401k, IRA, etc.).'],
      ['Set retirement goals', 'Enter your target retirement age and desired annual income in today\'s dollars — the calculator adjusts for inflation.'],
      ['Add Social Security estimate', 'Get your estimate at ssa.gov (my Social Security account). This significantly reduces how much you need to save.'],
      ['Review your gap and options', 'The calculator shows if you are on track and, if not, exactly how much more you need to save or how many years later you need to retire.'],
    ],
    tips: 'The most impactful retirement actions in order: (1) Always contribute enough to get the full employer 401k match — it\'s a 50–100% instant return. (2) Max Roth IRA ($7,000/year) for tax-free retirement income. (3) Increase contribution rate by 1% each year you get a raise — you will not miss it. (4) At 50+, use catch-up contributions ($7,500 extra in 401k, $1,000 extra in IRA). A 1% higher contribution rate today can mean $50,000–$150,000 more at retirement.',
    when: 'Use at every major life stage: when starting your first job (to see the power of starting early), after a raise (to recalculate contributions), at 40 to do a serious mid-career check, and at 55+ to set a concrete retirement date.',
  },

  default: {
    intro: '',
    howto: [],
    tips: '',
    when: ''
  }
};

function getContent(id) {
  return TOOL_CONTENT[id] || TOOL_CONTENT.default;
}

// ── TOOL PAGE BUILDER ──────────────────────────────────────────────────
function buildToolPage(tool) {
  const content = getContent(tool.id);
  const cat = CAT_LABEL[tool.cat] || tool.cat;

  // Breadcrumb schema
  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
      { "@type": "ListItem", "position": 1, "name": "Home", "item": `https://${SITE.domain}/` },
      { "@type": "ListItem", "position": 2, "name": cat, "item": `https://${SITE.domain}/tools` },
      { "@type": "ListItem", "position": 3, "name": tool.name, "item": `https://${SITE.domain}/${tool.id}` },
    ]
  };

  // WebApplication schema
  const appSchema = {
    "@context": "https://schema.org",
    "@type": "WebApplication",
    "name": tool.name,
    "url": `https://${SITE.domain}/${tool.id}`,
    "description": tool.metaDesc,
    "applicationCategory": "EducationApplication",
    "operatingSystem": "All",
    "offers": { "@type": "Offer", "price": "0", "priceCurrency": "USD" },
    "featureList": tool.styles?.join(', ') || tool.name,
    "creator": { "@type": "Organization", "name": SITE.name, "url": `https://${SITE.domain}` }
  };

  // FAQ schema
  const faqSchema = tool.faqs?.length ? {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": tool.faqs.map(f => ({
      "@type": "Question",
      "name": f.q,
      "acceptedAnswer": { "@type": "Answer", "text": f.a }
    }))
  } : null;

  const relatedTools = (tool.relatedTools || []).map(rid => {
    const rel = TOOLS.find(t => t.id === rid);
    if (!rel) return '';
    return `<a class="rel-card" href="/${rel.id}">
      <div style="font-size:24px;margin-bottom:8px">${rel.ico}</div>
      <div style="font-size:14px;font-weight:600;color:var(--ink);margin-bottom:4px">${rel.name}</div>
      <div style="font-size:12px;color:var(--text3);line-height:1.5">${rel.desc.substring(0,75)}…</div>
    </a>`;
  }).join('');

  const faqHTML = tool.faqs?.length ? `
<section class="sec" style="background:var(--cream);padding:52px 0">
  <div class="w">
    <span class="sec-label">FAQ</span>
    <h2 class="sec-h">Frequently Asked Questions</h2>
    <div style="max-width:740px">
      ${tool.faqs.map(f => `
      <div class="faq-item">
        <div class="faq-q">${f.q}<span class="faq-tog" aria-hidden="true">+</span></div>
        <div class="faq-a">${f.a}</div>
      </div>`).join('')}
    </div>
  </div>
</section>` : '';

  // Style buttons
  const styleHTML = tool.styles?.length ? `
    <span class="f-label">Format / Style</span>
    <div class="style-row" id="styleRow" role="group" aria-label="Select format">
      ${tool.styles.map((s,i) => `<button class="sty-btn${i===0?' on':''}" onclick="setStyle(this,'${s}')" type="button">${s}</button>`).join('')}
    </div>` : '';

  // Source type selector
  const srcHTML = tool.sources?.length ? `
    <span class="f-label">Source Type</span>
    <select id="srcSel" class="src-sel" aria-label="Select source type">
      ${tool.sources.map(s=>`<option value="${s}">${s}</option>`).join('')}
    </select>` : '';

  // Rich how-to section
  const howtoHTML = content.howto.length ? `
<section class="sec" style="padding:52px 0">
  <div class="w">
    <span class="sec-label">HOW TO USE</span>
    <h2 class="sec-h">How to Use the ${tool.name}</h2>
    <div class="steps">
      ${content.howto.map(([title, desc], i) => `
      <div class="step">
        <div class="step-n">0${i+1}</div>
        <h4>${title}</h4>
        <p>${desc}</p>
      </div>`).join('')}
    </div>
    ${content.tips ? `<div style="margin-top:28px;background:var(--cream);border-left:3px solid var(--crimson);padding:16px 20px;border-radius:0 var(--r) var(--r) 0;max-width:740px"><p style="font-size:14px;color:var(--text2);line-height:1.8"><strong style="color:var(--ink)">Pro tip:</strong> ${content.tips}</p></div>` : ''}
  </div>
</section>` : '';

  // Unique intro content section
  const introHTML = content.intro ? `
<section class="sec" style="padding:48px 0 0">
  <div class="w">
    <div style="max-width:740px">
      <span class="sec-label">ABOUT THIS TOOL</span>
      <h2 class="sec-h">What is the ${tool.name}?</h2>
      <div class="prose">
        <p>${content.intro}</p>
        ${content.when ? `<p><strong>When to use it:</strong> ${content.when}</p>` : ''}
      </div>
    </div>
  </div>
</section>` : '';

  const header = buildHeader({
    title: truncTitle(tool.metaTitle),
    desc: truncDesc(tool.metaDesc),
    keyword: tool.keyword,
    path: `${tool.id}`,
    schema: appSchema,
    extraSchema: [breadcrumbSchema, ...(faqSchema ? [faqSchema] : [])],
    ogImage: `https://${SITE.domain}/images/og-${tool.cat}.png`,
  });

  return header + buildNav() + `

<!-- HERO -->
<section class="tool-hero">
  <div class="w">
    <nav class="breadcrumb" aria-label="Breadcrumb">
      <a href="/">Home</a><span aria-hidden="true">›</span>
      <a href="/tools">Tools</a><span aria-hidden="true">›</span>
      <a href="/tools#${tool.cat}">${cat}</a><span aria-hidden="true">›</span>
      <span>${tool.name}</span>
    </nav>
    <h1 style="font-family:'Crimson Pro',serif;font-size:clamp(26px,5vw,46px);font-weight:700;color:#fff;line-height:1.2;margin-bottom:14px">${tool.tagline || tool.name}</h1>
    <p style="color:rgba(255,255,255,.65);font-size:16px;max-width:640px;line-height:1.75">${tool.desc}</p>
    <div class="powered-by" style="margin-top:16px">
      <span style="opacity:.5">Powered by</span>
      <a href="https://www.anthropic.com" target="_blank" rel="noopener" style="color:rgba(255,255,255,.5)">Claude AI by Anthropic</a>
    </div>
  </div>
</section>

<!-- Noscript content for search crawlers -->
<noscript>
  <div style="max-width:800px;margin:32px auto;padding:0 24px;font-family:Georgia,serif;color:#1a1208">
    <h2>${tool.name} — How It Works</h2>
    <p>${tool.desc}</p>
    <p><strong>To use this tool, please enable JavaScript in your browser.</strong> ${tool.name} is a free AI-powered tool requiring JavaScript to interact with Claude AI by Anthropic.</p>
    <p>Related tools: <a href="/tools">Browse all 28 free academic tools →</a></p>
  </div>
</noscript>

<!-- MAIN TOOL -->
<div class="w" style="padding-top:8px;padding-bottom:8px">

${tool.cat === 'legal' ? `
<!-- LEGAL DISCLAIMER — required for liability protection -->
<div role="alert" style="background:#fff8e1;border-left:4px solid #f59e0b;border-radius:4px;padding:12px 16px;margin:16px 0;display:flex;gap:10px;align-items:flex-start">
  <span style="font-size:18px;flex-shrink:0">⚖️</span>
  <div style="font-size:13px;color:#7c5e10;line-height:1.6">
    <strong>Not Legal Advice.</strong> This tool is for educational and research purposes only.
    AI-generated legal analysis is not a substitute for advice from a licensed attorney.
    Always consult a qualified legal professional before taking action on any legal matter.
  </div>
</div>` : ''}

${tool.cat === 'finance' ? `
<!-- FINANCE DISCLAIMER — required for liability protection -->
<div role="alert" style="background:#e8f5e9;border-left:4px solid #2d6a2d;border-radius:4px;padding:12px 16px;margin:16px 0;display:flex;gap:10px;align-items:flex-start">
  <span style="font-size:18px;flex-shrink:0">📊</span>
  <div style="font-size:13px;color:#1a4a1a;line-height:1.6">
    <strong>For informational purposes only.</strong> Results are estimates based on inputs provided.
    This is not financial advice. Actual loan terms, investment returns, and tax implications vary.
    Consult a qualified financial advisor, mortgage broker, or tax professional before making financial decisions.
  </div>
</div>` : ''}

  <!-- Ad 1: Top banner -->
  <div class="w" style="padding-top:8px;padding-bottom:8px">
    <ins class="adsbygoogle" style="display:block;margin:20px 0" data-ad-client="${SITE.adsense}" data-ad-slot="SLOT_ID_HERE" data-ad-format="horizontal" data-full-width-responsive="true"></ins>
    <script>if(window._adsLoaded)(adsbygoogle=window.adsbygoogle||[]).push({});</script>
  </div>

  <!-- Tool panel -->
  <div class="tool-panel">
    <div class="tool-header">
      <div class="tool-icon" style="background:${tool.color}22;color:${tool.color}">${tool.ico}</div>
      <div class="tool-meta">
        <h2>${tool.name}</h2>
        <p>${cat} · Free · <strong>Powered by Claude AI by Anthropic</strong></p>
      </div>
    </div>
    <div class="tool-body">
      ${styleHTML}
      ${srcHTML}
      <span class="f-label" style="${tool.styles?.length || tool.sources?.length ? '' : 'margin-top:0'}">
        ${tool.inputLabel || 'Your Content'}
      </span>
      <textarea class="main-inp" id="mainInp"
        placeholder="${tool.placeholder || 'Enter your content here...'}"
        aria-label="${tool.inputLabel || 'Input'}"
        rows="5"></textarea>

      <button class="run-btn" id="runBtn" onclick="runTool()" type="button">
        <span id="runIco" aria-hidden="true">✦</span>
        <span id="runTxt">Generate with AI</span>
      </button>

      <!-- Output -->
      <div class="out-area" id="outArea" aria-live="polite" aria-label="AI output"></div>
      <div class="cit-box" id="citBox" style="display:none">
        <div class="cit-label" id="citLabel">OUTPUT</div>
        <div class="cit-content" id="citContent"></div>
      </div>
      <button class="copy-btn" id="copyBtn" onclick="copyOutput()" type="button">📋 Copy to clipboard</button>
      <div class="powered-by">
        <span>AI output by</span>
        <a href="https://www.anthropic.com" target="_blank" rel="noopener">Claude AI (Anthropic)</a>
        <span>· Always verify before submission</span>
      </div>
    </div>
  </div>

  <!-- Ad 2: Mid responsive -->
  <div class="w" style="margin:16px 0">
    <ins class="adsbygoogle" style="display:block" data-ad-client="${SITE.adsense}" data-ad-slot="SLOT_ID_HERE" data-ad-format="auto" data-full-width-responsive="true"></ins>
    <script>if(window._adsLoaded)(adsbygoogle=window.adsbygoogle||[]).push({});</script>
  </div>
</div>

${introHTML}
${howtoHTML}

<!-- Related tools -->
${relatedTools ? `
<section class="sec" style="background:var(--cream);padding:48px 0">
  <div class="w">
    <span class="sec-label">RELATED TOOLS</span>
    <h2 class="sec-h">You Might Also Need</h2>
    <div class="related-grid">${relatedTools}</div>
  </div>
</section>` : ''}

${faqHTML}

<!-- Ad 3: Bottom banner -->
<div class="w" style="padding:16px 0 40px">
  <ins class="adsbygoogle" style="display:block" data-ad-client="${SITE.adsense}" data-ad-slot="SLOT_ID_HERE" data-ad-format="horizontal" data-full-width-responsive="true"></ins>
  <script>if(window._adsLoaded)(adsbygoogle=window.adsbygoogle||[]).push({});</script>
</div>

${buildFooter()}

<script>
let curStyle = '${tool.styles?.[0] || ''}';
function setStyle(btn, style) {
  document.querySelectorAll('.sty-btn').forEach(b => b.classList.remove('on'));
  btn.classList.add('on');
  curStyle = style;
}
function copyOutput() {
  const t = document.getElementById('outArea').textContent;
  navigator.clipboard.writeText(t).then(() => {
    const b = document.getElementById('copyBtn');
    b.textContent = '✅ Copied!';
    setTimeout(() => b.textContent = '📋 Copy to clipboard', 2000);
  });
}
async function runTool() {
  const inp = document.getElementById('mainInp').value.trim();
  if (!inp) { document.getElementById('mainInp').focus(); return; }

  const btn = document.getElementById('runBtn');
  const out = document.getElementById('outArea');
  btn.disabled = true;
  document.getElementById('runIco').innerHTML = '<span class="spin"></span>';
  document.getElementById('runTxt').textContent = 'Generating…';
  out.className = 'out-area show';
  out.textContent = 'Claude AI is working…';
  document.getElementById('citBox').style.display = 'none';
  document.getElementById('copyBtn').style.display = 'none';

  const src = document.getElementById('srcSel')?.value || 'General';
  const prompt = \`${tool.prompt.replace(/`/g, '\\`')}\`
    .replace('{style}', curStyle)
    .replace('{src}', src)
    .replace('{input}', inp);

  try {
    const text = await callAI(prompt, 1300);
    out.textContent = text;
    document.getElementById('copyBtn').style.display = 'inline-block';
    ${['chicago-citation-generator','apa-citation-generator','mla-citation-generator','footnote-formatter'].includes(tool.id) ? `
    const lines = text.split('\\n');
    const cit = lines.find(l => l.length > 50 && l.match(/[A-Z]/));
    if (cit) {
      document.getElementById('citLabel').textContent = (curStyle || 'Citation') + ' — FORMATTED OUTPUT';
      document.getElementById('citContent').textContent = cit;
      document.getElementById('citBox').style.display = 'block';
    }` : ''}
  } catch(e) {
    out.textContent = '⚠️ ' + (e.message || 'Connection error. Please try again.');
  }
  btn.disabled = false;
  document.getElementById('runIco').textContent = '✦';
  document.getElementById('runTxt').textContent = 'Generate Again';
}
</script>
${SHARED_JS}
</body></html>`;
}

// ── HOMEPAGE ────────────────────────────────────────────────────────────
function buildHomepage() {
  const schema = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "name": SITE.name,
    "url": `https://${SITE.domain}/`,
    "description": "28 free AI-powered academic tools for citations, research, legal briefs, and teaching.",
    "potentialAction": { "@type": "SearchAction", "target": `https://${SITE.domain}/tools`, "query-input": "required name=search_term_string" }
  };
  const orgSchema = {
    "@context": "https://schema.org", "@type": "Organization",
    "name": SITE.name, "url": `https://${SITE.domain}/`,
    "contactPoint": { "@type": "ContactPoint", "email": SITE.email, "contactType": "customer support" }
  };

  const cats = [...new Set(TOOLS.map(t => t.cat))];
  const catCards = cats.map(cat => {
    const tools = TOOLS.filter(t => t.cat === cat).slice(0, 5);
    return `
    <div style="background:var(--card);border:1px solid var(--border);border-radius:var(--r);padding:24px">
      <h3 style="font-family:'Crimson Pro',serif;font-size:18px;font-weight:700;color:var(--ink);margin-bottom:14px">${CAT_LABEL[cat]} <span style="font-family:'DM Mono',monospace;font-size:10px;color:var(--text3);font-weight:400">${TOOLS.filter(t=>t.cat===cat).length} tools</span></h3>
      ${tools.map(t => `<a href="/${t.id}" style="display:flex;align-items:center;gap:8px;padding:7px 0;border-bottom:1px solid var(--border);text-decoration:none;color:var(--text2);font-size:13px;transition:color .2s" onmouseover="this.style.color='var(--crimson)'" onmouseout="this.style.color='var(--text2)'"><span>${t.ico}</span>${t.name}</a>`).join('')}
      <a href="/tools#${cat}" style="display:block;margin-top:12px;font-family:'DM Mono',monospace;font-size:10px;color:var(--crimson);text-decoration:none">View all ${CAT_LABEL[cat]} tools →</a>
    </div>`;
  }).join('');

  return buildHeader({
    title: 'Free AI Academic Tools — Citation Generator, Thesis, Legal Briefs | ProScholersTools',
    desc: '28 free AI-powered academic tools. Chicago, APA, MLA citation generators, thesis builder, legal case briefs (IRAC), lesson plans. No signup — 5 free uses daily.',
    keyword: 'free academic tools, citation generator, thesis statement generator, legal case brief, lesson plan generator',
    path: '',
    schema,
    extraSchema: [orgSchema]
  }) + buildNav() + `

<section style="background:linear-gradient(135deg,#1a1208 0%,#2d1a0a 60%,#1a1a2e 100%);padding:calc(var(--nav-h) + 72px) 0 60px">
  <div class="w" style="text-align:center">
    <div style="font-family:'DM Mono',monospace;font-size:9px;letter-spacing:2px;color:rgba(255,255,255,.4);margin-bottom:16px">FREE AI ACADEMIC TOOLS</div>
    <h1 style="font-family:'Crimson Pro',serif;font-size:clamp(32px,6vw,58px);font-weight:700;color:#fff;line-height:1.15;margin-bottom:20px">Academic Excellence,<br><em style="color:var(--gold3)">Powered by Claude AI</em></h1>
    <p style="color:rgba(255,255,255,.6);font-size:17px;max-width:580px;margin:0 auto 32px;line-height:1.75">28 free tools for citations, research, legal writing, and teaching. No signup required. 5 free uses every day.</p>
    <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;margin-bottom:20px">
      <a href="/tools" style="background:var(--crimson);color:#fff;padding:13px 28px;border-radius:var(--r);font-weight:600;font-size:15px;text-decoration:none">Browse All 28 Tools →</a>
      <a href="/chicago-citation-generator" style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.2);color:#fff;padding:13px 28px;border-radius:var(--r);font-size:15px;text-decoration:none">Try Citation Generator</a>
    </div>
    <div class="powered-by" style="justify-content:center;margin-top:4px">
      <span style="color:rgba(255,255,255,.35)">Powered by</span>
      <a href="https://www.anthropic.com" target="_blank" rel="noopener" style="color:rgba(255,255,255,.35)">Claude AI by Anthropic</a>
    </div>
  </div>
</section>

<div class="w" style="padding:12px 0">
  <div class="ad" style="margin:24px 0;height:90px" aria-label="Advertisement">
    <ins class="adsbygoogle" style="display:block" data-ad-client="${SITE.adsense}" data-ad-slot="SLOT_ID_HERE" data-ad-format="horizontal" data-full-width-responsive="true"></ins>
    <script>if(window._adsLoaded)(adsbygoogle=window.adsbygoogle||[]).push({});</script>
  </div>
</div>

<section class="sec" style="padding:52px 0">
  <div class="w">
    <span class="sec-label">ALL CATEGORIES</span>
    <h2 class="sec-h">28 Tools Across 5 Academic Categories</h2>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:16px;margin-top:24px">${catCards}</div>
  </div>
</section>

<section class="sec" style="background:var(--cream);padding:52px 0">
  <div class="w">
    <span class="sec-label">HOW IT WORKS</span>
    <h2 class="sec-h">Start in Seconds — No Signup Required</h2>
    <div class="steps" style="margin-top:24px">
      <div class="step"><div class="step-n">01</div><h4>Choose Your Tool</h4><p>Pick from 28 AI-powered academic tools across citations, research, legal, and teaching.</p></div>
      <div class="step"><div class="step-n">02</div><h4>Enter Your Details</h4><p>Type your source information, research topic, or content into the input field.</p></div>
      <div class="step"><div class="step-n">03</div><h4>AI Generates Output</h4><p>Claude AI formats, structures, and generates your academic content in seconds.</p></div>
      <div class="step"><div class="step-n">04</div><h4>Copy and Use</h4><p>Copy the output directly into your paper, document, or lesson plan. Always verify before submission.</p></div>
    </div>
    <div style="margin-top:28px;background:var(--card);border:1px solid var(--border);border-radius:var(--r);padding:20px;max-width:600px">
      <p style="font-size:14px;color:var(--text2);line-height:1.75"><strong>Free tier:</strong> 5 uses/day, no signup. <strong>Unlimited:</strong> Add your own free <a href="https://console.anthropic.com/" target="_blank" rel="noopener">Anthropic API key</a> — new accounts get $5 free credit (≈500 uses).</p>
    </div>
  </div>
</section>

<div class="w" style="padding:24px 0 40px">
  <div class="ad" style="height:90px" aria-label="Advertisement">
    <ins class="adsbygoogle" style="display:block" data-ad-client="${SITE.adsense}" data-ad-slot="SLOT_ID_HERE" data-ad-format="horizontal" data-full-width-responsive="true"></ins>
    <script>if(window._adsLoaded)(adsbygoogle=window.adsbygoogle||[]).push({});</script>
  </div>
</div>

${buildFooter()}${SHARED_JS}</body></html>`;
}

// ── TOOLS INDEX ─────────────────────────────────────────────────────────
function buildToolsIndex() {
  const schema = {
    "@context":"https://schema.org","@type":"CollectionPage",
    "name":"All 28 Free AI Academic Tools | ProScholersTools",
    "url":`https://${SITE.domain}/tools`,
    "description":"Browse all 28 free AI academic tools — citation generators, research tools, legal briefs, lesson plans."
  };
  const cats = [...new Set(TOOLS.map(t => t.cat))];
  const sections = cats.map(cat => {
    const tools = TOOLS.filter(t => t.cat === cat);
    return `
    <div id="${cat}" style="margin-bottom:52px">
      <h2 style="font-family:'Crimson Pro',serif;font-size:26px;font-weight:700;color:var(--ink);margin-bottom:6px">${CAT_LABEL[cat]} Tools</h2>
      <p style="font-size:13px;color:var(--text3);margin-bottom:20px">${tools.length} free AI tools</p>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px">
        ${tools.map(t => `
        <a href="/${t.id}" style="background:var(--card);border:1px solid var(--border);border-radius:var(--r);padding:18px;display:flex;align-items:flex-start;gap:12px;text-decoration:none;transition:all .22s" onmouseover="this.style.borderColor='var(--crimson)';this.style.transform='translateY(-2px)'" onmouseout="this.style.borderColor='var(--border)';this.style.transform=''">
          <div style="font-size:24px;flex-shrink:0">${t.ico}</div>
          <div>
            <div style="font-size:14px;font-weight:600;color:var(--ink);margin-bottom:4px">${t.name}</div>
            <div style="font-size:12px;color:var(--text3);line-height:1.5">${t.desc.substring(0,80)}…</div>
          </div>
        </a>`).join('')}
      </div>
    </div>`;
  }).join('');

  return buildHeader({
    title:'All 28 Free AI Academic Tools — Citation, Research, Legal, Teaching | ProScholersTools',
    desc:'Browse all 28 free AI-powered academic tools. Chicago, APA, MLA citation generators, thesis builder, legal case brief (IRAC), literature review, lesson plans and more.',
    keyword:'free academic tools ai, citation generator, thesis generator, legal brief generator, lesson plan ai',
    path:'tools', schema
  }) + buildNav() + `
<section style="background:var(--ink);padding:calc(var(--nav-h) + 56px) 0 40px">
  <div class="w">
    <h1 style="font-family:'Crimson Pro',serif;font-size:clamp(26px,5vw,44px);font-weight:700;color:#fff">All 28 Free AI Academic Tools</h1>
    <p style="color:rgba(255,255,255,.55);margin-top:10px;font-size:16px">5 free uses/day — no signup. Add your own API key for unlimited access.</p>
  </div>
</section>
<div class="w" style="padding:40px 24px">
  <div class="ad" style="margin-bottom:32px;height:90px">
    <ins class="adsbygoogle" style="display:block" data-ad-client="${SITE.adsense}" data-ad-slot="SLOT_ID_HERE" data-ad-format="horizontal" data-full-width-responsive="true"></ins>
    <script>if(window._adsLoaded)(adsbygoogle=window.adsbygoogle||[]).push({});</script>
  </div>
  ${sections}
</div>
${buildFooter()}${SHARED_JS}</body></html>`;
}

// ── SITEMAP ─────────────────────────────────────────────────────────────
function buildSitemap(blogSlugs) {
  const today = new Date().toISOString().slice(0, 10);
  const pages = [
    { url: '',                  p: '1.0', f: 'weekly' },
    { url: 'tools',             p: '0.9', f: 'weekly' },
    { url: 'blog',              p: '0.8', f: 'weekly' },
    { url: 'about',             p: '0.5', f: 'monthly' },
    { url: 'contact',           p: '0.4', f: 'monthly' },
    { url: 'privacy',           p: '0.3', f: 'yearly'  },
    { url: 'terms',             p: '0.3', f: 'yearly'  },
    ...TOOLS.map(t => ({ url: t.id, p: '0.8', f: 'weekly' })),
    ...blogSlugs.map(s => ({ url: `blog/${s}`, p: '0.7', f: 'monthly' })),
  ];
  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${pages.map(p => `  <url>
    <loc>https://${SITE.domain}/${p.url}</loc>
    <lastmod>${today}</lastmod>
    <changefreq>${p.f}</changefreq>
    <priority>${p.p}</priority>
  </url>`).join('\n')}
</urlset>`;
}

// ── GENERATE TOOL PAGES ─────────────────────────────────────────────────
console.log('\n🏗  ProScholersTools v4 — Building...\n');
let count = 0;
for (const tool of TOOLS) {
  fs.writeFileSync(path.join(OUT, `${tool.id}.html`), buildToolPage(tool), 'utf8');
  console.log(`  ✅ /${tool.id}`);
  count++;
}

fs.writeFileSync(path.join(OUT, 'index.html'), buildHomepage(), 'utf8');
console.log('  ✅ /');
fs.writeFileSync(path.join(OUT, 'tools.html'), buildToolsIndex(), 'utf8');
console.log('  ✅ /tools');

// ── BLOG ARTICLES ───────────────────────────────────────────────────────
const BLOG_POSTS = [
  {
    slug: 'chicago-citation-guide-2025',
    title: 'The Complete Chicago Citation Guide 2025 (17th Edition)',
    desc: 'Master Chicago style citations — Notes-Bibliography vs Author-Date, footnote format, bibliography rules, and the 5 most common mistakes.',
    cat: 'Citations', date: '2025-02-15', mins: 8,
    content: `<p>The Chicago Manual of Style, now in its 17th edition, is one of the oldest and most detailed citation systems in academia. Used primarily in history, literature, and the humanities, it offers two distinct systems that serve different disciplines and purposes.</p>
<h2>Notes-Bibliography vs Author-Date</h2>
<p>The <strong>Notes-Bibliography (NB)</strong> system is used in humanities — history, literature, philosophy, art history. Citations appear as numbered footnotes or endnotes, with a bibliography at the end of the paper.</p>
<p>The <strong>Author-Date (AD)</strong> system mirrors APA and is used in sciences and social sciences. In-text citations appear as (Author Year, page) with a reference list at the end.</p>
<p>Never mix both systems in the same paper. If your instructor has not specified which to use, ask before you begin writing — reformatting is painful.</p>
<h2>Footnote Format (NB System)</h2>
<p>First full citation for a book: <em>Firstname Lastname, Title of Book (Place: Publisher, Year), page.</em><br>
Subsequent citation: <em>Lastname, Shortened Title, page.</em></p>
<p>Bibliography entry: <em>Lastname, Firstname. Title of Book. Place: Publisher, Year.</em></p>
<h2>The 5 Most Common Chicago Mistakes</h2>
<p><strong>1. Mixing NB and AD in one paper.</strong> Choose one system and use it throughout.<br>
<strong>2. Missing page numbers.</strong> Direct quotes always require a page number in footnotes.<br>
<strong>3. Wrong Ibid usage.</strong> Ibid means the exact same source AND page. If the page differs, write "Ibid., 45."<br>
<strong>4. Incomplete bibliography.</strong> Every footnoted source must appear in the bibliography.<br>
<strong>5. Wrong punctuation in titles.</strong> Book titles are italicized; article titles go in "quotation marks."</p>
<h2>Chicago for Websites</h2>
<p>NB footnote: Firstname Lastname, "Page Title," Website Name, Month Day, Year, URL.<br>
Include access date only if the content is likely to change.</p>
<p>Use our <a href="/chicago-citation-generator">free Chicago Citation Generator</a> to format any source type instantly.</p>`
  },
  {
    slug: 'apa-vs-mla-vs-chicago',
    title: 'APA vs MLA vs Chicago: Which Citation Style Do You Need?',
    desc: 'A direct comparison of the three major citation styles — when each is used, key formatting differences, and how to choose the right one.',
    cat: 'Citations', date: '2025-02-08', mins: 6,
    content: `<p>Citation style confusion is one of the most common academic mistakes. Here is a definitive guide to choosing the right style before you start writing.</p>
<h2>The Quick Decision Guide</h2>
<p><strong>Use APA</strong> if you study: psychology, education, social sciences, nursing, business, or any STEM field. APA prioritizes the publication date because recency matters in scientific research.</p>
<p><strong>Use MLA</strong> if you study: English literature, foreign languages, cultural studies, film, or humanities at the undergraduate level. MLA is flexible and readable, designed for analysis rather than empirical reporting.</p>
<p><strong>Use Chicago</strong> if you study: history, philosophy, theology, art history, or are publishing in academic journals. Chicago's footnote system keeps the main text clean while providing full source details.</p>
<h2>Key Formatting Differences</h2>
<p><strong>In-text citations:</strong><br>APA: (Smith, 2022, p. 45)<br>MLA: (Smith 45)<br>Chicago NB: Footnote ¹</p>
<p><strong>Reference list title:</strong><br>APA: References<br>MLA: Works Cited<br>Chicago: Bibliography</p>
<p><strong>Author name format:</strong><br>APA: Smith, J. A. (2022).<br>MLA: Smith, Jane.<br>Chicago: Smith, Jane. 2022.</p>
<h2>When Your Assignment Does Not Specify</h2>
<p>Choose based on your discipline. Be completely consistent throughout. When in doubt, APA is the safest general choice for most undergraduate papers because of its clarity and widespread familiarity.</p>
<p>Use our free generators: <a href="/chicago-citation-generator">Chicago</a> · <a href="/apa-citation-generator">APA</a> · <a href="/mla-citation-generator">MLA</a></p>`
  },
  {
    slug: 'irac-method-complete-guide',
    title: 'The IRAC Method: A Law Student\'s Complete Guide with Examples',
    desc: 'Master IRAC (Issue, Rule, Application, Conclusion) for legal writing. Full examples, common mistakes, CREAC and IRAAC variations.',
    cat: 'Legal', date: '2025-02-01', mins: 10,
    content: `<p>IRAC is the foundational framework of legal analysis. Every law student, paralegal, and attorney uses some version of it. Master this structure and your legal writing becomes clear, logical, and persuasive.</p>
<h2>The Four Elements</h2>
<p><strong>I — Issue:</strong> What is the specific legal question the court must answer? State it precisely — not "the issue is negligence" but "whether the defendant owed a duty of care to the plaintiff as a business invitee."</p>
<p><strong>R — Rule:</strong> What law governs this issue? Cite the statute, regulation, or case precedent. State both the general rule and any relevant exceptions.</p>
<p><strong>A — Application:</strong> How do the specific facts of this case map onto each element of the rule? This is the most important and most often underdeveloped section. Do not be conclusory — show your reasoning step by step.</p>
<p><strong>C — Conclusion:</strong> State a clear answer to the Issue. One to two sentences.</p>
<h2>Complete IRAC Example: Negligence</h2>
<p><strong>Issue:</strong> Whether the shopkeeper Alex is liable in negligence for injuries sustained by customer Beth when she slipped on an unmarked wet floor.</p>
<p><strong>Rule:</strong> Negligence requires: (1) duty of care, (2) breach of that duty, (3) causation, and (4) damages. Business owners owe a duty of reasonable care to customers as business invitees.</p>
<p><strong>Application:</strong> Alex owed Beth a duty as a business invitee. A reasonable shopkeeper would have placed warning signs or dried the floor. Alex did neither, constituting breach. The wet floor directly caused Beth's slip, establishing causation. Beth suffered a broken arm, satisfying damages.</p>
<p><strong>Conclusion:</strong> Alex is likely liable to Beth for negligence.</p>
<h2>CREAC: When to State Your Conclusion First</h2>
<p>CREAC (Conclusion, Rule, Explanation, Application, Conclusion) is preferred in office memos and predictive writing where the reader needs the answer before the analysis. Judges and senior attorneys are busy — lead with your conclusion.</p>
<h2>The 3 Biggest IRAC Mistakes</h2>
<p><strong>1. Conclusory application.</strong> "Clearly the defendant was negligent" is not analysis. Explain why each element is or is not met.<br>
<strong>2. No counter-argument.</strong> Strong legal writing addresses the strongest argument for the other side and refutes it.<br>
<strong>3. Weak issue statement.</strong> Be specific. The issue should name the legal doctrine and the key factual dispute.</p>
<p>Generate a complete IRAC case brief with our <a href="/legal-case-brief">free Legal Case Brief Generator</a>.</p>`
  },
  {
    slug: 'how-to-write-literature-review',
    title: 'How to Write a Literature Review: 5-Step Guide',
    desc: 'A step-by-step guide to writing a strong literature review — from systematic search to synthesis, theme identification, and gap analysis.',
    cat: 'Research', date: '2025-01-25', mins: 7,
    content: `<p>A literature review is not a summary of individual papers. It is a critical synthesis of existing scholarship that positions your research within the field and justifies why your study is needed.</p>
<h2>Step 1: Define Your Scope</h2>
<p>Write one precise research question before you search. This determines which papers belong in your review. Decide your time boundary (last 10 years? 20?), geographic scope, and source types (peer-reviewed only, or grey literature too?).</p>
<h2>Step 2: Search Systematically</h2>
<p>Use multiple databases: Google Scholar, JSTOR, PubMed (sciences), SSRN (law/social sciences), Web of Science. Combine your key terms. Record every search query — systematic reviews require this. Export references to Zotero (free) immediately.</p>
<h2>Step 3: Screen Sources Efficiently</h2>
<p>Read abstracts first, not full papers. Apply inclusion and exclusion criteria consistently. For a 10,000-word chapter, 40–80 sources is typical. Quality beats quantity — 30 highly relevant sources beats 80 loosely related ones.</p>
<h2>Step 4: Synthesize by Theme, Not by Paper</h2>
<p>This is where most students go wrong. Do not write: "Smith (2019) found X. Jones (2020) found Y." Write: "Research consistently demonstrates X (Smith 2019; Jones 2020), though Brown (2021) challenges this in high-income contexts."</p>
<p>Group sources by theme, methodology, theoretical framework, or finding — never chronologically.</p>
<h2>Step 5: Identify and State the Research Gap</h2>
<p>Your literature review must end by identifying what is missing, contradicted, or under-examined. This gap is the justification for your study. Use language like: "While studies have examined X, no research has addressed Y in the context of Z."</p>
<p>Use our <a href="/literature-review-writer">free Literature Review Writer</a> to generate a structured first draft.</p>`
  },
  {
    slug: 'thesis-statement-guide',
    title: '10 Rules for Writing a Strong Thesis Statement',
    desc: 'Avoid the most common thesis mistakes. Learn what makes a thesis arguable, specific, and effective — with before and after examples.',
    cat: 'Writing', date: '2025-01-18', mins: 5,
    content: `<p>A weak thesis statement is the single most common reason academic papers receive poor grades. These 10 rules will fix it.</p>
<h2>Rule 1: Make It Arguable</h2>
<p>Weak: "Social media has changed communication." (No one can disagree with this.)<br>
Strong: "Instagram's algorithmic prioritization of visual content has reduced the complexity of political discourse by rewarding emotional imagery over substantive policy debate."</p>
<h2>Rule 2: Be Specific, Not Broad</h2>
<p>The more specific your claim, the stronger your argument. "Climate change is a problem" is a fact. "Carbon pricing reduces industrial emissions more effectively than command-and-control regulation in European manufacturing sectors" is a thesis.</p>
<h2>Rule 3: Preview Your Structure</h2>
<p>A strong thesis signals your paper's organization. "X is true because of A, B, and C" tells the reader exactly what three sections to expect.</p>
<h2>Rule 4: Never Use Announcements</h2>
<p>Delete "In this paper, I will argue…" Simply make the argument. Announcements waste space and weaken your voice.</p>
<h2>Rule 5: Answer a Question, Not Ask One</h2>
<p>A thesis is the answer to your research question, not the question itself.</p>
<h2>Rule 6: Revise After Writing the Body</h2>
<p>Most writers discover what they actually want to argue only after drafting the body paragraphs. Write a preliminary thesis, write the body, then revise the thesis to match what you actually proved.</p>
<h2>Rule 7: Apply the Reasonable Disagreement Test</h2>
<p>If a reasonable, informed person cannot disagree with your thesis, it is too weak. A strong thesis invites thoughtful pushback.</p>
<h2>Rules 8–10 in Brief</h2>
<p><strong>8.</strong> Include a "so what" — why does this matter?<br>
<strong>9.</strong> Keep it one to two sentences maximum.<br>
<strong>10.</strong> Use precise language — avoid "many," "some," "things," "aspects."</p>
<p>Use our <a href="/thesis-statement-generator">free Thesis Statement Generator</a> to get a strong draft instantly.</p>`
  },
  {
    slug: 'best-free-ai-tools-students-2025',
    title: 'The Best Free AI Tools for Students in 2025',
    desc: 'An honest guide to the best free AI tools for academic research, citations, writing assistance, and studying — with what each does best.',
    cat: 'AI Tools', date: '2025-01-12', mins: 9,
    content: `<p>AI tools have genuinely transformed academic work. But with hundreds of options, it is easy to waste time on tools that do not help. Here is an honest, practical guide based on real academic use cases.</p>
<h2>For Citations and References</h2>
<p><strong>ProScholersTools (Free)</strong> — 28 specialized academic tools including Chicago, APA, and MLA generators, footnote formatters, bibliography builders, and legal brief generators. Powered by Claude AI. 5 free uses daily, no signup required. Add your own API key for unlimited access.</p>
<p><strong>Zotero (Free)</strong> — The gold standard reference manager. Captures sources from the web automatically, formats in any style, and integrates with Word and Google Docs. Essential for any research paper longer than five pages.</p>
<h2>For Research and Understanding</h2>
<p><strong>Google Scholar (Free)</strong> — Still the best starting point for academic literature. Use the "Cited by" link to find papers that build on a key source. Use "Related articles" to explore the field.</p>
<p><strong>Semantic Scholar (Free)</strong> — AI-enhanced academic search that surfaces the most influential papers and shows research connections visually.</p>
<h2>For Writing Assistance</h2>
<p><strong>Claude (Free tier via ProScholersTools)</strong> — Best for long-form academic writing, argument structuring, paraphrasing, and generating structured outlines. More nuanced than alternatives for academic tone and formal register.</p>
<p><strong>Grammarly (Free tier)</strong> — Grammar, clarity, and engagement checking. The free tier catches most errors. Worth using as a final pass before submission.</p>
<h2>For Studying</h2>
<p><strong>NotebookLM (Free)</strong> — Google's AI document analyzer. Upload lecture notes and textbooks, then ask questions. Excellent for exam preparation and concept consolidation.</p>
<p><strong>Anki (Free)</strong> — Spaced repetition flashcard system. The most evidence-based method for long-term memory retention. Steep learning curve but extraordinary results.</p>
<h2>The Optimal Free Stack</h2>
<p>Zotero + ProScholersTools + Claude + Anki covers 90% of student AI needs at zero cost. Start with this combination before paying for anything.</p>
<p>Start with our <a href="/tools">free academic tools →</a></p>`
  },
];

for (const post of BLOG_POSTS) {
  const postSchema = {
    "@context":"https://schema.org","@type":"BlogPosting",
    "headline": post.title, "description": post.desc,
    "url": `https://${SITE.domain}/blog/${post.slug}`,
    "datePublished": post.date,
    "author": {"@type":"Organization","name":SITE.name,"url":`https://${SITE.domain}`},
    "publisher": {"@type":"Organization","name":SITE.name},
    "mainEntityOfPage": `https://${SITE.domain}/blog/${post.slug}`
  };
  const breadcrumb = {
    "@context":"https://schema.org","@type":"BreadcrumbList",
    "itemListElement":[
      {"@type":"ListItem","position":1,"name":"Home","item":`https://${SITE.domain}/`},
      {"@type":"ListItem","position":2,"name":"Blog","item":`https://${SITE.domain}/blog`},
      {"@type":"ListItem","position":3,"name":post.title,"item":`https://${SITE.domain}/blog/${post.slug}`},
    ]
  };
  const relToolLinks = TOOLS.slice(0,5).map(t =>
    `<a href="/${t.id}" style="background:#fff;border:1px solid var(--border);border-radius:var(--r);padding:7px 14px;font-size:12px;color:var(--ink);text-decoration:none;display:inline-block;margin:4px 4px 0 0;transition:all .2s" onmouseover="this.style.borderColor='var(--crimson)'" onmouseout="this.style.borderColor='var(--border)'">${t.ico} ${t.name}</a>`
  ).join('');

  const html = buildHeader({
    title: `${post.title} | ProScholersTools`,
    desc: post.desc,
    keyword: post.title.toLowerCase().replace(/[^a-z0-9 ]/g,' ').trim(),
    path: `blog/${post.slug}`,
    schema: postSchema,
    extraSchema: [breadcrumb]
  }) + buildNav() + `
<section style="background:var(--ink);padding:calc(var(--nav-h) + 52px) 0 36px">
  <div class="w" style="max-width:800px">
    <nav class="breadcrumb" aria-label="Breadcrumb">
      <a href="/">Home</a><span>›</span><a href="/blog">Blog</a><span>›</span><span>${post.cat}</span>
    </nav>
    <h1 style="font-family:'Crimson Pro',serif;font-size:clamp(22px,4.5vw,40px);font-weight:700;color:#fff;line-height:1.2;margin-bottom:12px">${post.title}</h1>
    <p style="color:rgba(255,255,255,.5);font-family:'DM Mono',monospace;font-size:10px">${post.cat.toUpperCase()} · ${post.mins} MIN READ · ${post.date}</p>
  </div>
</section>
<div style="max-width:800px;margin:0 auto;padding:36px 24px 64px">
  <div class="ad" style="margin-bottom:32px;height:90px">
    <ins class="adsbygoogle" style="display:block" data-ad-client="${SITE.adsense}" data-ad-slot="SLOT_ID_HERE" data-ad-format="horizontal" data-full-width-responsive="true"></ins>
    <script>if(window._adsLoaded)(adsbygoogle=window.adsbygoogle||[]).push({});</script>
  </div>
  <article class="prose" itemscope itemtype="https://schema.org/BlogPosting">
    <style>
      article.prose h2{font-family:'Crimson Pro',serif;font-size:24px;font-weight:700;color:var(--ink);margin:32px 0 12px;padding-top:8px;border-top:2px solid var(--border)}
      article.prose p{margin-bottom:16px}
    </style>
    ${post.content}
    <div style="margin-top:12px" class="powered-by">
      <span>Content assisted by</span>
      <a href="https://www.anthropic.com" target="_blank" rel="noopener">Claude AI (Anthropic)</a>
      <span>· Always verify academic information independently</span>
    </div>
  </article>
  <div style="margin-top:44px;background:var(--cream);border:1px solid var(--border);border-radius:var(--r);padding:22px">
    <div style="font-family:'DM Mono',monospace;font-size:9px;letter-spacing:1px;color:var(--text3);margin-bottom:10px">FREE AI TOOLS</div>
    <h3 style="font-family:'Crimson Pro',serif;font-size:18px;font-weight:700;color:var(--ink);margin-bottom:12px">Try These Free Academic Tools</h3>
    <div>${relToolLinks}</div>
  </div>
  <div class="ad" style="margin-top:32px;height:90px">
    <ins class="adsbygoogle" style="display:block" data-ad-client="${SITE.adsense}" data-ad-slot="SLOT_ID_HERE" data-ad-format="horizontal" data-full-width-responsive="true"></ins>
    <script>if(window._adsLoaded)(adsbygoogle=window.adsbygoogle||[]).push({});</script>
  </div>
</div>
${buildFooter()}${SHARED_JS}</body></html>`;

  fs.writeFileSync(path.join(OUT, `blog/${post.slug}.html`), html, 'utf8');
  console.log(`  ✅ /blog/${post.slug}`);
}

// Blog index
const blogIndexSchema = {"@context":"https://schema.org","@type":"Blog","name":"ProScholersTools Blog","url":`https://${SITE.domain}/blog`,"description":"Academic writing guides, citation tips, and research strategies."};
const blogCards = BLOG_POSTS.map(p => `
  <a href="/blog/${p.slug}" style="background:var(--card);border:1px solid var(--border);border-radius:var(--r);padding:22px;display:block;text-decoration:none;transition:all .22s" onmouseover="this.style.borderColor='var(--crimson)';this.style.transform='translateY(-2px)'" onmouseout="this.style.borderColor='var(--border)';this.style.transform=''">
    <div style="font-family:'DM Mono',monospace;font-size:9px;color:var(--text3);margin-bottom:8px">${p.cat.toUpperCase()} · ${p.mins} MIN READ · ${p.date}</div>
    <h2 style="font-family:'Crimson Pro',serif;font-size:19px;font-weight:700;color:var(--ink);margin-bottom:8px;line-height:1.3">${p.title}</h2>
    <p style="font-size:13px;color:var(--text2);line-height:1.65">${p.desc}</p>
    <div style="margin-top:12px;font-family:'DM Mono',monospace;font-size:10px;color:var(--crimson)">Read article →</div>
  </a>`).join('');
const blogIndex = buildHeader({title:'Academic Writing Blog — Citation Guides & Research Tips | ProScholersTools',desc:'Academic writing guides, citation style comparisons, IRAC legal method, literature review tips, and AI tool reviews from ProScholersTools.',keyword:'academic writing blog, citation guide, how to write literature review, irac method',path:'blog',schema:blogIndexSchema}) + buildNav() + `
<section style="background:var(--ink);padding:calc(var(--nav-h) + 52px) 0 40px">
  <div class="w"><h1 style="font-family:'Crimson Pro',serif;font-size:clamp(24px,5vw,42px);font-weight:700;color:#fff">Academic Writing Blog</h1>
  <p style="color:rgba(255,255,255,.5);margin-top:10px;font-size:15px">Citation guides, research strategies, legal writing, and AI tool reviews.</p></div>
</section>
<div class="w" style="padding:36px 24px 56px">
  <div class="ad" style="margin-bottom:28px;height:90px"><ins class="adsbygoogle" style="display:block" data-ad-client="${SITE.adsense}" data-ad-slot="SLOT_ID_HERE" data-ad-format="horizontal" data-full-width-responsive="true"></ins><script>if(window._adsLoaded)(adsbygoogle=window.adsbygoogle||[]).push({});</script></div>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:18px">${blogCards}</div>
</div>
${buildFooter()}${SHARED_JS}</body></html>`;
fs.writeFileSync(path.join(OUT, 'blog/index.html'), blogIndex, 'utf8');
console.log('  ✅ /blog');

// ── STATIC PAGES ────────────────────────────────────────────────────────
function page(title, desc, slug, body) {
  return buildHeader({title:`${title} | ProScholersTools`,desc,keyword:title.toLowerCase(),path:slug,schema:{"@context":"https://schema.org","@type":"WebPage","name":title,"url":`https://${SITE.domain}/${slug}`}}) + buildNav() + `
<section style="background:var(--ink);padding:calc(var(--nav-h) + 52px) 0 36px"><div class="w">
  <h1 style="font-family:'Crimson Pro',serif;font-size:clamp(24px,4vw,40px);font-weight:700;color:#fff">${title}</h1>
</div></section>
<section class="sec"><div class="w" style="max-width:780px">${body}</div></section>
${buildFooter()}${SHARED_JS}</body></html>`;
}

// About
fs.writeFileSync(path.join(OUT,'about.html'), page('About ProScholersTools','Free AI academic tools for students, researchers, lawyers, and teachers — powered by Claude AI by Anthropic.','about',`
<div class="prose">
  <h3>Our Mission</h3>
  <p>ProScholersTools exists to make high-quality academic tools accessible to everyone — not just those who can afford expensive subscriptions. Whether you are formatting your first bibliography, writing a legal case brief, or building a lesson plan, our 28 free AI tools save you hours of work.</p>
  <h3>How It Works</h3>
  <p>All tools are powered by <strong>Claude AI by Anthropic</strong> — one of the most capable AI models available. We provide 5 free uses per day with no signup required. Add your own free <a href="https://console.anthropic.com/" target="_blank" rel="noopener">Anthropic API key</a> for unlimited access.</p>
  <h3>Privacy First</h3>
  <p>Your content is never stored, never sold, and never used to train models. Your API key (if you add one) is stored only in your browser — we never see it. See our <a href="/privacy">Privacy Policy</a> for full details.</p>
  <h3>About the AI</h3>
  <p>All AI-generated content is produced by <a href="https://www.anthropic.com" target="_blank" rel="noopener">Anthropic's Claude</a>. Always verify citations against official style guides before submission, and consult a qualified attorney for legal matters.</p>
  <h3>Contact</h3>
  <p>Questions, feedback, or partnership inquiries: <a href="mailto:${SITE.email}">${SITE.email}</a> · <a href="/contact">Contact form</a></p>
</div>`), 'utf8');
console.log('  ✅ /about');

// Contact
fs.writeFileSync(path.join(OUT,'contact.html'), page('Contact Us','Get in touch with the ProScholersTools team. Questions, bug reports, feedback, or partnership inquiries.','contact',`
<p class="sec-p" style="margin-bottom:28px">We read every message and reply within 48 hours. Email us directly at <a href="mailto:${SITE.email}">${SITE.email}</a> or use the form below.</p>
<div style="background:var(--card);border:1px solid var(--border);border-radius:var(--r);padding:32px;max-width:580px">
  <div style="margin-bottom:18px"><label style="font-family:'DM Mono',monospace;font-size:9px;letter-spacing:1px;text-transform:uppercase;color:var(--text3);display:block;margin-bottom:6px">Name</label><input id="cfn" type="text" style="width:100%;padding:9px 12px;border:1px solid var(--border);border-radius:var(--r);font-size:14px;background:#fff;color:var(--text)" placeholder="Your name"></div>
  <div style="margin-bottom:18px"><label style="font-family:'DM Mono',monospace;font-size:9px;letter-spacing:1px;text-transform:uppercase;color:var(--text3);display:block;margin-bottom:6px">Email</label><input id="cfe" type="email" style="width:100%;padding:9px 12px;border:1px solid var(--border);border-radius:var(--r);font-size:14px;background:#fff;color:var(--text)" placeholder="your@email.com"></div>
  <div style="margin-bottom:18px"><label style="font-family:'DM Mono',monospace;font-size:9px;letter-spacing:1px;text-transform:uppercase;color:var(--text3);display:block;margin-bottom:6px">Subject</label><select id="cfs" style="width:100%;padding:9px 12px;border:1px solid var(--border);border-radius:var(--r);font-size:14px;background:#fff;color:var(--text)"><option>General Question</option><option>Bug Report</option><option>Feature Request</option><option>Partnership</option></select></div>
  <div style="margin-bottom:22px"><label style="font-family:'DM Mono',monospace;font-size:9px;letter-spacing:1px;text-transform:uppercase;color:var(--text3);display:block;margin-bottom:6px">Message</label><textarea id="cfm" rows="5" style="width:100%;padding:9px 12px;border:1px solid var(--border);border-radius:var(--r);font-size:14px;background:#fff;color:var(--text);resize:vertical;font-family:'Inter',sans-serif" placeholder="How can we help?"></textarea></div>
  <button onclick="sendCF()" style="background:var(--crimson);color:#fff;padding:12px;width:100%;border-radius:var(--r);border:none;font-size:14px;font-weight:700;cursor:pointer">Send Message →</button>
  <div id="cfok" style="display:none;margin-top:14px;background:#f0fff4;border:1px solid #c6f6d5;border-radius:var(--r);padding:12px;text-align:center;color:#276749;font-size:13px">✅ Message received! We'll reply within 48 hours.</div>
</div>
<script>function sendCF(){const n=document.getElementById('cfn').value,e=document.getElementById('cfe').value,m=document.getElementById('cfm').value;if(!n||!e||!m){alert('Please fill in all fields.');return;}document.getElementById('cfok').style.display='block';['cfn','cfe','cfm'].forEach(id=>document.getElementById(id).value='');}</script>`), 'utf8');
console.log('  ✅ /contact');

// Privacy
fs.writeFileSync(path.join(OUT,'privacy.html'), page('Privacy Policy','ProScholersTools privacy policy. We never store your research content or API keys. GDPR and CCPA compliant.','privacy',`
<p style="font-family:'DM Mono',monospace;font-size:10px;color:var(--text3);margin-bottom:28px">Last updated: ${new Date().toLocaleDateString('en-US',{year:'numeric',month:'long',day:'numeric'})}</p>
<div class="prose">
${[
  ['What We Collect','We collect minimal data: (1) Anonymous usage analytics via Google Analytics — page views, country, browser type. (2) Contact form submissions (name, email, message) stored securely and never shared with third parties. We do NOT collect your research content, citations, legal briefs, or any content you enter into our tools.'],
  ['API Keys','Your Anthropic API key is stored ONLY in your browser\'s localStorage. It is never transmitted to our servers in a stored form and we have no ability to access it. API requests sent through our proxy do not log your key.'],
  ['Cookies','We use cookies for: (1) Google Analytics (anonymous usage data). (2) Google AdSense (advertising). (3) Your free usage count (server-side cookie — anonymous, no personal data). You can disable cookies in your browser at any time.'],
  ['Third Parties','We use: Anthropic (AI processing — <a href="https://www.anthropic.com/legal/privacy" target="_blank" rel="noopener">their privacy policy</a>), Google Analytics (anonymous analytics), Google AdSense (advertising), Netlify (hosting). We do not sell your data to any third party under any circumstances.'],
  ['Your Rights (GDPR / CCPA)','You have the right to access, rectify, or delete any personal data we hold. Contact us at '+SITE.email+' for any data requests. EU and California residents may exercise additional rights under GDPR and CCPA respectively.'],
  ['Data Retention','Contact form messages: 90 days. Analytics data: 26 months (Google Analytics default). AI-generated content: never stored.'],
  ['Contact','Privacy questions or data requests: <a href="mailto:'+SITE.email+'">'+SITE.email+'</a>'],
].map(([h,p])=>`<h3>${h}</h3><p>${p}</p>`).join('')}
</div>`), 'utf8');
console.log('  ✅ /privacy');

// Terms
fs.writeFileSync(path.join(OUT,'terms.html'), page('Terms of Service','ProScholersTools terms of service. Free AI academic tools — citation generators, research tools, legal briefs.','terms',`
<p style="font-family:'DM Mono',monospace;font-size:10px;color:var(--text3);margin-bottom:28px">Last updated: ${new Date().toLocaleDateString('en-US',{year:'numeric',month:'long',day:'numeric'})}</p>
<div class="prose">
${[
  ['1. Acceptance & Age Requirement','By using ProScholersTools you agree to these Terms. If you disagree, please do not use the service. <strong>This service is intended for users aged 13 and older.</strong> Users under 13 may not use this service. Users aged 13–17 should review these Terms with a parent or guardian. This age requirement complies with the U.S. COPPA law and the EU GDPR-K provisions.'],
  ['2. Service Description','ProScholersTools provides free AI-powered academic tools including citation generators, research assistants, legal brief generators, and teacher tools. All tools are powered by Claude AI by Anthropic. We provide 5 free uses per day. Users may add their own Anthropic API key for unlimited access.'],
  ['3. AI Content Disclaimer','All content is generated by AI and provided for informational and assistance purposes only. You must: (a) verify all citations against official style guides before submission; (b) not rely solely on AI-generated legal analysis — consult a qualified attorney for legal matters; (c) take full responsibility for any content submitted using AI-generated output. ProScholersTools makes no warranty that AI-generated content is accurate, complete, or fit for any particular purpose.'],
  ['4. Academic Integrity','You are responsible for complying with your institution\'s academic integrity policies. Using AI to generate content submitted as your own work without disclosure may violate your institution\'s honor code. ProScholersTools is not responsible for any academic misconduct violations.'],
  ['5. Intellectual Property','Citation style rules (Chicago, APA, MLA) are intellectual property of their respective organizations. ProScholersTools is not affiliated with the Chicago Manual of Style, American Psychological Association, or Modern Language Association. Our tools apply publicly available formatting rules.'],
  ['6. Anthropic AI','This service is powered by Claude AI by Anthropic. Use of this service is also subject to <a href="https://www.anthropic.com/legal/consumer-terms" target="_blank" rel="noopener">Anthropic\'s Consumer Terms</a>.'],
  ['7. API Keys','Users who provide their own Anthropic API key are solely responsible for all associated API costs. ProScholersTools is not responsible for charges incurred through use of your own key.'],
  ['8. Limitation of Liability','ProScholersTools is provided "as is" without warranties of any kind. We are not liable for any damages arising from use of the service, including academic, legal, or professional consequences.'],
  ['9. EU AI Act Disclosure','This service uses a third-party AI system (Claude by Anthropic) to generate content. All AI-generated outputs are clearly identified as such. Users are advised that AI outputs may contain inaccuracies and should verify all generated content before use. This disclosure is made in accordance with the EU AI Act (Regulation 2024/1689) transparency requirements.'],
  ['10. Governing Law','These Terms are governed by the laws of the jurisdiction in which the service owner operates. Disputes shall be resolved through good-faith negotiation before any formal proceeding.'],
  ['11. Contact','Questions: <a href="mailto:'+SITE.email+'">'+SITE.email+'</a>'],
].map(([h,p])=>`<h3>${h}</h3><p>${p}</p>`).join('')}
</div>`), 'utf8');
console.log('  ✅ /terms');

// 404
fs.writeFileSync(path.join(OUT,'404.html'), buildHeader({title:'Page Not Found | ProScholersTools',desc:'This page does not exist.',keyword:'404',path:'404',schema:{}}) + buildNav() + `
<section style="background:var(--ink);padding:calc(var(--nav-h) + 80px) 0 80px;text-align:center">
  <div class="w">
    <div style="font-family:'Crimson Pro',serif;font-size:80px;font-weight:700;color:var(--gold3);line-height:1">404</div>
    <h1 style="font-family:'Crimson Pro',serif;font-size:28px;font-weight:700;color:#fff;margin:16px 0 12px">Page Not Found</h1>
    <p style="color:rgba(255,255,255,.5);margin-bottom:28px">This page does not exist or has been moved.</p>
    <a href="/" style="background:var(--crimson);color:#fff;padding:12px 28px;border-radius:var(--r);font-weight:600;text-decoration:none">← Back to Home</a>
  </div>
</section>
${buildFooter()}${SHARED_JS}</body></html>`, 'utf8');
console.log('  ✅ /404');

// Robots
fs.writeFileSync(path.join(OUT,'robots.txt'), `User-agent: *\nAllow: /\nSitemap: https://${SITE.domain}/sitemap.xml\nDisallow: /.netlify/\n`,'utf8');

// Sitemap
const blogSlugs = BLOG_POSTS.map(p => p.slug);
fs.writeFileSync(path.join(OUT,'sitemap.xml'), buildSitemap(blogSlugs), 'utf8');

const total = fs.readdirSync(OUT).length + fs.readdirSync(path.join(OUT,'blog')).length;
console.log(`\n🎉 DONE — ${total} files | ${TOOLS.length} tools | ${BLOG_POSTS.length} articles\n`);
