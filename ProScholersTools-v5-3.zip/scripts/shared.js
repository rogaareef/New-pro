// shared.js — ProScholersTools complete shared system

const SITE = {
  name: 'ProScholersTools',
  tagline: 'Free AI Academic Tools',
  domain: 'proscholerstools.com',
  email: 'gogo24173@gmail.com',
  adsense: 'ca-pub-6119422909390809',
  year: new Date().getFullYear(),
  anthropicUrl: 'https://www.anthropic.com',
};

// ── CSS ─────────────────────────────────────────────────────────────────
const SHARED_CSS = `
<!-- Preconnect for performance -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Crimson+Pro:ital,wght@0,400;0,600;0,700;1,400;1,600&family=DM+Mono:wght@400;500&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --ink:#1a1208;--bg:#f7f3eb;--card:#fff;--cream:#faf7f2;
  --crimson:#8b1a1a;--crimson2:#a52020;--gold:#b8860b;--gold3:#e8b84b;
  --teal:#1a5c7a;--border:#e8e0d0;--text:#3a2e1c;--text2:#6b5d4a;--text3:#9a8a72;
  --r:6px;--nav-h:64px;--w:1140px;
  --shadow:0 2px 14px rgba(26,18,8,.09);
}
html{scroll-behavior:smooth}
body{font-family:'Inter',sans-serif;background:var(--bg);color:var(--text);line-height:1.65;-webkit-font-smoothing:antialiased}
a{color:var(--crimson);text-decoration:none}
a:hover{text-decoration:underline}
.w{max-width:var(--w);margin:0 auto;padding:0 24px}
img{max-width:100%;height:auto}

/* ── NAV ── */
#nav{position:fixed;top:0;left:0;right:0;z-index:900;height:var(--nav-h);background:rgba(247,243,235,.97);backdrop-filter:blur(14px);border-bottom:1px solid var(--border)}
.n-inner{max-width:var(--w);margin:0 auto;padding:0 24px;display:flex;align-items:center;justify-content:space-between;height:100%}
.n-logo{display:flex;align-items:center;gap:10px;text-decoration:none}
.n-logo:hover{text-decoration:none}
.n-crest{width:36px;height:36px;background:var(--crimson);color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-family:'Crimson Pro',serif;font-size:18px;font-weight:700;flex-shrink:0}
.n-brand{font-family:'Crimson Pro',serif;font-size:18px;font-weight:700;color:var(--ink);line-height:1}
.n-tagline{font-family:'DM Mono',monospace;font-size:9px;color:var(--text3);letter-spacing:.5px;margin-top:2px}
.n-links{display:flex;align-items:center;gap:6px}
.n-link{color:var(--text2);font-size:13px;padding:6px 10px;border-radius:var(--r);transition:all .2s}
.n-link:hover{background:var(--cream);color:var(--ink);text-decoration:none}


.n-cta{background:var(--crimson);color:#fff;padding:8px 18px;border-radius:var(--r);font-size:13px;font-weight:600;border:none;cursor:pointer;transition:all .2s}
.n-cta:hover{background:var(--crimson2)}

/* ── USAGE BAR (top) ── */

/* ── HERO ── */
.tool-hero{padding:calc(var(--nav-h) + 80px) 0 44px;background:linear-gradient(135deg,#1a1208 0%,#2d1a0a 60%,#1a1a2e 100%)}

/* ── TOOL PANEL ── */
.tool-panel{background:var(--card);border:1px solid var(--border);border-radius:10px;overflow:hidden;box-shadow:var(--shadow);margin:32px 0}
.tool-header{padding:18px 24px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:14px;background:var(--cream)}
.tool-icon{width:44px;height:44px;border-radius:var(--r);display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0}
.tool-meta h2{font-family:'Crimson Pro',serif;font-size:20px;font-weight:700;color:var(--ink)}
.tool-meta p{font-size:12px;color:var(--text3);margin-top:3px}
.tool-body{padding:24px}
.f-label{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:1px;text-transform:uppercase;color:var(--text3);margin-bottom:7px;margin-top:18px;display:block}
.f-label:first-child{margin-top:0}
.style-row{display:flex;gap:6px;flex-wrap:wrap}
.sty-btn{padding:6px 13px;border-radius:20px;border:1px solid var(--border);background:var(--cream);color:var(--text2);font-size:11px;cursor:pointer;transition:all .18s;font-family:'DM Mono',monospace;white-space:nowrap}
.sty-btn:hover,.sty-btn.on{background:var(--crimson);border-color:var(--crimson);color:#fff}
select.src-sel{width:100%;padding:9px 12px;border:1px solid var(--border);border-radius:var(--r);background:var(--cream);color:var(--text);font-size:13px;cursor:pointer;appearance:none}
textarea.main-inp{width:100%;min-height:130px;padding:12px;border:1px solid var(--border);border-radius:var(--r);background:#fff;font-size:14px;color:var(--text);resize:vertical;font-family:'Inter',sans-serif;line-height:1.65;outline:none;transition:border .2s}
textarea.main-inp:focus{border-color:var(--crimson)}
.run-btn{margin-top:16px;width:100%;padding:13px;background:var(--crimson);color:#fff;border:none;border-radius:var(--r);font-size:14px;font-weight:600;cursor:pointer;transition:all .22s;display:flex;align-items:center;justify-content:center;gap:9px}
.run-btn:hover:not(:disabled){background:var(--crimson2);transform:translateY(-1px);box-shadow:0 4px 16px rgba(139,26,26,.28)}
.run-btn:disabled{opacity:.55;cursor:not-allowed;transform:none}
.out-area{margin-top:18px;background:var(--cream);border:1px solid var(--border);border-radius:var(--r);padding:16px;min-height:80px;font-size:14px;line-height:1.85;color:var(--text);white-space:pre-wrap;display:none}
.out-area.show{display:block}
.cit-box{margin-top:12px;background:#fff;border:2px solid var(--crimson);border-radius:var(--r);padding:14px 16px;display:none}
.cit-box.show{display:block}
.cit-label{font-family:'DM Mono',monospace;font-size:8px;letter-spacing:1.5px;text-transform:uppercase;color:var(--crimson);margin-bottom:8px}
.cit-content{font-family:'DM Mono',monospace;font-size:12px;line-height:1.8;color:var(--ink)}
.copy-btn{margin-top:10px;padding:7px 16px;background:var(--cream);border:1px solid var(--border);border-radius:var(--r);font-size:11px;color:var(--text2);cursor:pointer;transition:all .18s;font-family:'DM Mono',monospace;display:none}
.copy-btn:hover{background:var(--border)}
@keyframes spin{to{transform:rotate(360deg)}}
.spin{display:inline-block;width:13px;height:13px;border:2px solid rgba(255,255,255,.3);border-top-color:#fff;border-radius:50%;animation:spin .7s linear infinite}

/* ── POWERED BY (Anthropic compliance) ── */
.powered-by{display:inline-flex;align-items:center;gap:6px;font-family:'DM Mono',monospace;font-size:9px;color:var(--text3);letter-spacing:.3px;margin-top:10px}
.powered-by a{color:var(--text3);text-decoration:none}
.powered-by a:hover{color:var(--crimson)}

/* ── AD SLOTS ── */
.ad{background:var(--cream);border:1px dashed var(--border);border-radius:var(--r);display:flex;align-items:center;justify-content:center;font-family:'DM Mono',monospace;font-size:10px;color:var(--text3);text-align:center;min-height:90px}

/* ── CONTENT SECTIONS ── */
.sec{padding:60px 0}
.sec-label{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:2px;text-transform:uppercase;color:var(--text3);margin-bottom:10px;display:block}
.sec-h{font-family:'Crimson Pro',serif;font-size:clamp(22px,3.5vw,34px);font-weight:700;color:var(--ink);margin-bottom:18px;line-height:1.25}
.sec-p{font-size:15px;color:var(--text2);line-height:1.8;max-width:740px}
.prose{font-size:15px;color:var(--text2);line-height:1.85}
.prose h3{font-family:'Crimson Pro',serif;font-size:20px;font-weight:700;color:var(--ink);margin:28px 0 10px}
.prose p{margin-bottom:14px}
.prose ul{padding-left:20px;margin-bottom:14px}
.prose ul li{margin-bottom:6px}
.prose strong{color:var(--ink)}

/* ── STEP BOXES ── */
.steps{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:14px;margin-top:24px}
.step{background:var(--card);border:1px solid var(--border);border-radius:var(--r);padding:20px}
.step-n{font-family:'Crimson Pro',serif;font-size:28px;font-weight:700;color:var(--crimson);line-height:1;margin-bottom:10px}
.step h4{font-size:14px;font-weight:600;color:var(--ink);margin-bottom:6px}
.step p{font-size:12px;color:var(--text3);line-height:1.5}

/* ── RELATED ── */
.related-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:14px;margin-top:20px}
.rel-card{background:var(--card);border:1px solid var(--border);border-radius:var(--r);padding:18px;display:block;text-decoration:none;transition:all .22s}
.rel-card:hover{border-color:var(--crimson);transform:translateY(-2px);box-shadow:var(--shadow);text-decoration:none}

/* ── FAQ ── */
.faq-item{border:1px solid var(--border);border-radius:var(--r);margin-bottom:10px;overflow:hidden;cursor:pointer}
.faq-q{padding:16px 18px;display:flex;align-items:center;justify-content:space-between;font-weight:600;font-size:15px;color:var(--ink);background:var(--card)}
.faq-tog{font-size:18px;color:var(--text3);transition:transform .2s;flex-shrink:0;margin-left:12px}
.faq-a{padding:0 18px;max-height:0;overflow:hidden;transition:all .3s;font-size:14px;color:var(--text2);line-height:1.75}
.faq-item.open .faq-a{max-height:400px;padding:0 18px 16px}
.faq-item.open .faq-tog{transform:rotate(45deg)}

/* ── COOKIE BANNER ── */
#cookieBanner{display:none;position:fixed;bottom:0;left:0;right:0;z-index:850;background:#1a1208;border-top:2px solid var(--gold);padding:13px 24px;box-shadow:0 -4px 20px rgba(0,0,0,.3)}

/* ── BREADCRUMB ── */
.breadcrumb{font-family:'DM Mono',monospace;font-size:10px;color:rgba(255,255,255,.4);margin-bottom:12px;display:flex;align-items:center;gap:6px;flex-wrap:wrap}
.breadcrumb a{color:rgba(255,255,255,.4);text-decoration:none}
.breadcrumb a:hover{color:rgba(255,255,255,.7)}
.breadcrumb span{color:rgba(255,255,255,.25)}

/* ── FOOTER ── */
footer{background:var(--ink);color:rgba(255,255,255,.5);padding:52px 0 24px}
.footer-inner{max-width:var(--w);margin:0 auto;padding:0 24px}
.footer-top{display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:44px;margin-bottom:44px}
.footer-brand{font-family:'Crimson Pro',serif;font-size:20px;font-weight:700;color:#fff;margin-bottom:8px}
.footer-desc{font-size:13px;line-height:1.7;color:rgba(255,255,255,.4);margin-bottom:12px}
.footer-col h4{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:1.5px;text-transform:uppercase;color:rgba(255,255,255,.35);margin-bottom:14px}
.footer-col a{display:block;font-size:13px;color:rgba(255,255,255,.5);margin-bottom:8px;text-decoration:none;transition:color .2s}
.footer-col a:hover{color:#fff}
.footer-bottom{border-top:1px solid rgba(255,255,255,.08);padding-top:20px;display:flex;justify-content:space-between;align-items:center;font-family:'DM Mono',monospace;font-size:10px;color:rgba(255,255,255,.3);flex-wrap:wrap;gap:10px}
.powered-badge{display:inline-flex;align-items:center;gap:6px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);padding:5px 12px;border-radius:20px;font-family:'DM Mono',monospace;font-size:9px;color:rgba(255,255,255,.45);margin-top:10px}
.powered-badge a{color:rgba(255,255,255,.55);text-decoration:none}
.powered-badge a:hover{color:#fff}

/* ── MOBILE ── */
@media(max-width:900px){
  .n-links .n-link{display:none}
  .footer-top{grid-template-columns:1fr 1fr}
}
@media(max-width:540px){
  .footer-top{grid-template-columns:1fr}
  .related-grid{grid-template-columns:1fr}
  .steps{grid-template-columns:1fr 1fr}
}
</style>`;

// ── HEADER ───────────────────────────────────────────────────────────────
function buildHeader({ title, desc, keyword, path: canonPath, schema, extraSchema = [], ogImage = null }) {
  const finalOgImage = ogImage || `https://${SITE.domain}/images/og-default.png`;
  const allSchemas = [schema, ...extraSchema].map(s =>
    `<script type="application/ld+json">${JSON.stringify(s)}</script>`
  ).join('\n');

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="index, follow">
<title>${title}</title>
<meta name="description" content="${desc}">
<meta name="keywords" content="${keyword}">
<link rel="canonical" href="https://${SITE.domain}/${canonPath}">
<meta property="og:title" content="${title}">
<meta property="og:description" content="${desc}">
<meta property="og:type" content="website">
<meta property="og:url" content="https://${SITE.domain}/${canonPath}">
<meta property="og:site_name" content="${SITE.name}">
<meta property="og:image" content="${finalOgImage}">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="${title}">
<meta name="twitter:description" content="${desc}">
<meta name="twitter:image" content="${finalOgImage}">
${allSchemas}
<!-- AdSense loaded after cookie consent only (GDPR compliant) -->
${SHARED_CSS}
</head>
<body>`;
}

// ── NAV ──────────────────────────────────────────────────────────────────
function buildNav() {
  return `
<nav id="nav">
  <div class="n-inner">
    <a href="/" class="n-logo" aria-label="${SITE.name} Home">
      <div class="n-crest" aria-hidden="true">S</div>
      <div>
        <div class="n-brand"><em>Scholers</em>Tools</div>
        <div class="n-tagline">28 Free AI Academic Tools</div>
      </div>
    </a>
    <div class="n-links">
      <a class="n-link" href="/tools">All Tools</a>
      <a class="n-link" href="/blog">Blog</a>
      <a class="n-link" href="/about">About</a>
      <a class="n-link" href="/contact">Contact</a>
      <button class="n-cta" onclick="location.href='/tools'" aria-label="Browse all tools">Browse Tools →</button>
    </div>
  </div>
</nav>

<!-- COOKIE CONSENT (GDPR / CCPA) -->
<div id="cookieBanner" role="dialog" aria-label="Cookie consent">
  <div style="max-width:1140px;margin:0 auto;display:flex;align-items:center;gap:14px;flex-wrap:wrap">
    <p style="font-size:12px;color:rgba(255,255,255,.7);line-height:1.6;margin:0;flex:1;min-width:200px">
      🍪 We use cookies for analytics and advertising to keep ProScholersTools free.
      Your research content is <strong style="color:#fff">never stored</strong>.
      <a href="/privacy" style="color:var(--gold3)">Privacy Policy</a>
    </p>
    <div style="display:flex;gap:8px;flex-shrink:0">
      <button onclick="acceptCookies('essential')" style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);color:rgba(255,255,255,.65);padding:7px 14px;border-radius:4px;font-size:11px;cursor:pointer">Essential Only</button>
      <button onclick="acceptCookies('all')" style="background:var(--gold);border:none;color:#000;padding:7px 18px;border-radius:4px;font-size:11px;font-weight:700;cursor:pointer">Accept All</button>
    </div>
  </div>
</div>`;
}

// ── FOOTER ───────────────────────────────────────────────────────────────
function buildFooter() {
  return `
<footer>
  <div class="footer-inner">
    <div class="footer-top">
      <div>
        <div class="footer-brand">ProScholersTools</div>
        <p class="footer-desc">Free AI-powered academic tools for students, researchers, lawyers, and teachers. Cite correctly, write stronger, research smarter.</p>
        <div class="powered-badge">
          Powered by <a href="${SITE.anthropicUrl}" target="_blank" rel="noopener">Claude AI by Anthropic</a>
        </div>
      </div>
      <div class="footer-col">
        <h4>Citations</h4>
        <a href="/chicago-citation-generator">Chicago</a>
        <a href="/apa-citation-generator">APA 7th</a>
        <a href="/mla-citation-generator">MLA 9th</a>
        <a href="/footnote-formatter">Footnotes</a>
        <a href="/bibliography-builder">Bibliography</a>
      </div>
      <div class="footer-col">
        <h4>Research & Legal</h4>
        <a href="/thesis-statement-generator">Thesis Generator</a>
        <a href="/literature-review-writer">Lit Review</a>
        <a href="/legal-case-brief">Legal Case Brief</a>
        <a href="/legal-memorandum-writer">Legal Memo</a>
        <a href="/lesson-plan-generator">Lesson Plans</a>
      </div>
      <div class="footer-col">
        <h4>Finance Calculators</h4>
        <a href="/loan-calculator">Loan Calculator</a>
        <a href="/mortgage-calculator">Mortgage Calculator</a>
        <a href="/compound-interest-calculator">Compound Interest</a>
        <a href="/debt-consolidation-calculator">Debt Consolidation</a>
        <a href="/retirement-calculator">Retirement Calculator</a>
      </div>
      <div class="footer-col">
        <h4>Company</h4>
        <a href="/about">About Us</a>
        <a href="/blog">Blog</a>
        <a href="/contact">Contact</a>
        <a href="/privacy">Privacy Policy</a>
        <a href="/terms">Terms of Service</a>
        <a href="/tools">All 34 Tools</a>
      </div>
    </div>
    <div class="footer-bottom">
      <span>© ${SITE.year} ProScholersTools. Free academic tools powered by <a href="${SITE.anthropicUrl}" target="_blank" rel="noopener" style="color:rgba(255,255,255,.4)">Claude AI (Anthropic)</a>.</span>
      <span>Not affiliated with Chicago Manual of Style, APA, or MLA.</span>
    </div>
  </div>
</footer>`;
}

// ── SHARED JS ─────────────────────────────────────────────────────────────
const SHARED_JS = `
<script>
/* ── CALL AI (via backend proxy — fully free, no limits) ── */
async function callAI(prompt, _maxTokens) {
  const r = await fetch('/api', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ messages: [{ role: 'user', content: prompt }] }),
  });
  const d = await r.json();
  if (!r.ok || d.error) throw { type: 'api_error', message: d.error || 'API error. Please try again.' };
  return d.content?.map(c => c.text || '').join('\n') || 'No response received.';
}

/* ── GDPR-COMPLIANT ADSENSE LOADER ── */
const PST_PUB = 'ca-pub-6119422909390809';
function loadAdSense() {
  try {
    if (window._adsLoaded) return;
    window._adsLoaded = true;
    const s = document.createElement('script');
    s.async = true;
    s.crossOrigin = 'anonymous';
    s.src = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' + PST_PUB;
    document.head.appendChild(s);
    s.onload = () => {
      document.querySelectorAll('.adsbygoogle:not([data-adsbygoogle-status])').forEach(() => {
        try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch(e) {}
      });
    };
  } catch(e) {}
}

function initCookies() {
  try {
    const consent = localStorage.getItem('pst_cookie');
    if (!consent) {
      const b = document.getElementById('cookieBanner');
      if (b) b.style.display = 'block';
    } else if (consent === 'all') {
      loadAdSense();
    }
  } catch {}
}
function acceptCookies(level) {
  try { localStorage.setItem('pst_cookie', level); } catch {}
  const b = document.getElementById('cookieBanner');
  if (b) { b.style.transition = 'transform .3s'; b.style.transform = 'translateY(110%)'; }
  if (level === 'all') loadAdSense();
}

/* ── FAQ TOGGLE ── */
document.addEventListener('click', e => {
  const f = e.target.closest('.faq-item');
  if (f) f.classList.toggle('open');
});

/* ── INIT ── */
document.addEventListener('DOMContentLoaded', initCookies);
</script>`;

module.exports = { SITE, SHARED_CSS, buildHeader, buildNav, buildFooter, SHARED_JS };
